<?php

// Test de connexion autonome à PostgreSQL
// Ce fichier peut être exécuté directement via http://localhost:8080/TestConnexion.php

// Configuration de la base de données
$db_config = [
    'host' => 'woody.iut.univ-lehavre.fr',
    'port' => 5432, // Port PostgreSQL standard
    'dbname' => 'cn230854',
    'user' => 'cn230854',
    'password' => '28022005'
];

function testDatabaseConnection($config) {
    try {
        $dsn = "pgsql:host={$config['host']};port={$config['port']};dbname={$config['dbname']}";
        $pdo = new PDO($dsn, $config['user'], $config['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
        
        $html = '<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test de Connexion PostgreSQL</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            border-bottom: 3px solid #007bff;
            padding-bottom: 10px;
        }
        .success {
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .error {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .info {
            background-color: #d1ecf1;
            border: 1px solid #bee5eb;
            color: #0c5460;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: white;
            font-weight: bold;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        .icon {
            font-size: 24px;
            margin-right: 10px;
        }
        .success-icon { color: #28a745; }
        .error-icon { color: #dc3545; }
        .info-icon { color: #17a2b8; }
        code {
            background-color: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔌 Test de Connexion à la Base de Données PostgreSQL</h1>';
        
        try {
            // Tester la connexion PDO (déjà créée en paramètre de fonction)
            
            $html .= '
        <div class="success">
            <span class="icon success-icon">✅</span>
            <strong>Connexion réussie !</strong><br>
            La connexion à la base de données PostgreSQL a été établie avec succès.
        </div>';
            
            // Récupérer les informations de configuration
            $config = $db->getConnectString();
            $dbConfig = config('Database')->default;
            
            $html .= '
        <h2>📋 Informations de Configuration</h2>
        <table>
            <tr>
                <th>Paramètre</th>
                <th>Valeur</th>
            </tr>
            <tr>
                <td><strong>Hostname</strong></td>
                <td><code>' . esc($dbConfig['hostname']) . '</code></td>
            </tr>
            <tr>
                <td><strong>Port</strong></td>
                <td><code>' . esc($dbConfig['port']) . '</code></td>
            </tr>
            <tr>
                <td><strong>Database</strong></td>
                <td><code>' . esc($dbConfig['database']) . '</code></td>
            </tr>
            <tr>
                <td><strong>Username</strong></td>
                <td><code>' . esc($dbConfig['username']) . '</code></td>
            </tr>
            <tr>
                <td><strong>Driver</strong></td>
                <td><code>' . esc($dbConfig['DBDriver']) . '</code></td>
            </tr>
            <tr>
                <td><strong>Charset</strong></td>
                <td><code>' . esc($dbConfig['charset']) . '</code></td>
            </tr>
        </table>';
            
            // Tester une requête simple
            $html .= '
        <h2>� Informations de Configuration</h2>
        <table>
            <tr>
                <th>Paramètre</th>
                <th>Valeur</th>
            </tr>
            <tr>
                <td><strong>Hostname</strong></td>
                <td><code>' . htmlspecialchars($config['host']) . '</code></td>
            </tr>
            <tr>
                <td><strong>Port</strong></td>
                <td><code>' . htmlspecialchars($config['port']) . '</code></td>
            </tr>
            <tr>
                <td><strong>Database</strong></td>
                <td><code>' . htmlspecialchars($config['dbname']) . '</code></td>
            </tr>
            <tr>
                <td><strong>Username</strong></td>
                <td><code>' . htmlspecialchars($config['user']) . '</code></td>
            </tr>
            <tr>
                <td><strong>DSN</strong></td>
                <td><code>' . htmlspecialchars($dsn) . '</code></td>
            </tr>
        </table>';
            
        // Tester une requête simple
        $html .= '
        <h2>�🔍 Test de Requête SQL</h2>';
            
            try {
                $stmt = $pdo->query("SELECT version() as version, current_database() as database, current_user as \"user\"");
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $html .= '
        <div class="success">
            <span class="icon success-icon">✅</span>
            <strong>Requête SQL exécutée avec succès !</strong>
        </div>
        <table>
            <tr>
                <th>Information</th>
                <th>Valeur</th>
            </tr>
            <tr>
                <td><strong>Version PostgreSQL</strong></td>
                <td><code>' . htmlspecialchars($result['version']) . '</code></td>
            </tr>
            <tr>
                <td><strong>Base de données active</strong></td>
                <td><code>' . htmlspecialchars($result['database']) . '</code></td>
            </tr>
            <tr>
                <td><strong>Utilisateur connecté</strong></td>
                <td><code>' . htmlspecialchars($result['user']) . '</code></td>
            </tr>
        </table>';
                
            } catch (Exception $e) {
                $html .= '
        <div class="error">
            <span class="icon error-icon">❌</span>
            <strong>Erreur lors de l\'exécution de la requête :</strong><br>
            <code>' . htmlspecialchars($e->getMessage()) . '</code>
        </div>';
            }
            
            // Lister les tables
            $html .= '
        <h2>📊 Tables dans la Base de Données</h2>';
            
            try {
                $stmt = $pdo->query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
                $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                if (!empty($tables)) {
                    $html .= '
        <div class="info">
            <span class="icon info-icon">ℹ️</span>
            <strong>' . count($tables) . ' table(s) trouvée(s)</strong>
        </div>
        <table>
            <tr>
                <th>#</th>
                <th>Nom de la table</th>
            </tr>';
                    
                    foreach ($tables as $index => $table) {
                        $html .= '
            <tr>
                <td>' . ($index + 1) . '</td>
                <td><code>' . htmlspecialchars($table) . '</code></td>
            </tr>';
                    }
                    
                    $html .= '
        </table>';
                } else {
                    $html .= '
        <div class="info">
            <span class="icon info-icon">ℹ️</span>
            Aucune table trouvée dans la base de données.
        </div>';
                }
                
            } catch (Exception $e) {
                $html .= '
        <div class="error">
            <span class="icon error-icon">❌</span>
            <strong>Erreur lors de la récupération des tables :</strong><br>
            <code>' . htmlspecialchars($e->getMessage()) . '</code>
        </div>';
            }
            
        } catch (Exception $e) {
            $html .= '
        <div class="error">
            <span class="icon error-icon">❌</span>
            <strong>Échec de la connexion à la base de données</strong><br><br>
            <strong>Message d\'erreur :</strong><br>
            <code>' . htmlspecialchars($e->getMessage()) . '</code>
        </div>
        
        <h2>📋 Configuration Utilisée</h2>
        <div class="info">
            <span class="icon info-icon">ℹ️</span>
            Configuration utilisée pour le test de connexion
        </div>
        <table>
            <tr>
                <th>Paramètre</th>
                <th>Valeur</th>
            </tr>
            <tr>
                <td><strong>Hostname</strong></td>
                <td><code>' . htmlspecialchars($config['host']) . '</code></td>
            </tr>
            <tr>
                <td><strong>Port</strong></td>
                <td><code>' . htmlspecialchars($config['port']) . '</code></td>
            </tr>
            <tr>
                <td><strong>Database</strong></td>
                <td><code>' . htmlspecialchars($config['dbname']) . '</code></td>
            </tr>
            <tr>
                <td><strong>Username</strong></td>
                <td><code>' . htmlspecialchars($config['user']) . '</code></td>
            </tr>
            <tr>
                <td><strong>DSN</strong></td>
                <td><code>' . htmlspecialchars($dsn) . '</code></td>
            </tr>
        </table>
        
        <h2>💡 Points à vérifier</h2>
        <ul>
            <li>Le serveur PostgreSQL est-il accessible depuis votre réseau ?</li>
            <li>Les identifiants (username/password) sont-ils corrects ?</li>
            <li>L\'extension PHP <code>pdo_pgsql</code> est-elle installée et activée ?</li>
            <li>Le firewall autorise-t-il les connexions au port configuré ?</li>
            <li>La base de données existe-t-elle sur le serveur ?</li>
        </ul>';
        }
        
        $html .= '
    </div>
</body>
</html>';
        
        return $html;
    } catch (Exception $e) {
        return 'Erreur fatale : ' . htmlspecialchars($e->getMessage());
    }
}

// Exécution du test
echo testDatabaseConnection($db_config);
?>
