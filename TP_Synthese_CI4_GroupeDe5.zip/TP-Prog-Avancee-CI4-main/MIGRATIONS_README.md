# Guide d'utilisation des Migrations et Seeders - Projet Rattrapage

## 🚀 Commandes d'exécution

### 1. Exécuter toutes les migrations
```bash
php spark migrate
```

### 2. Voir l'état des migrations
```bash
php spark migrate:status
```

### 3. Exécuter les seeders
```bash
# Seeder principal (recommandé)
php spark db:seed DatabaseSeeder

# Ou seeders individuels
php spark db:seed RessourceSeeder
php spark db:seed UtilisateurSeeder
php spark db:seed EleveSeeder
```

### 4. Rollback (si nécessaire)
```bash
# Annuler la dernière migration
php spark migrate:rollback

# Annuler toutes les migrations
php spark migrate:rollback -all

# Reset complet (supprime tout et recrée)
php spark migrate:refresh
```

## 📋 Ordre des migrations créées

1. **2024-11-28-100000_CreateUtilisateurTable.php** - Table utilisateur
2. **2024-11-28-101000_CreateRessourceTable.php** - Table ressource
3. **2024-11-28-102000_CreateEleveTable.php** - Table eleve
4. **2024-11-28-103000_CreateRattrapageTable.php** - Table rattrapage
5. **2024-11-28-104000_CreateDsTable.php** - Table ds
6. **2024-11-28-105000_CreateAbsenceTable.php** - Table absence
7. **2024-11-28-106000_CreatePlanificationTable.php** - Table planification
8. **2024-11-28-107000_CreateNotificationTable.php** - Table notification
9. **2024-11-28-108000_CreateTokenVerificationTable.php** - Table token_verification
10. **2024-11-28-109000_CreateNotificationTrigger.php** - Trigger PostgreSQL

## 🗂️ Seeders disponibles

- **RessourceSeeder** - Popule toutes les ressources de S1 à S6
- **UtilisateurSeeder** - Créé les enseignants et directeurs de test
- **EleveSeeder** - Créé les étudiants de test
- **DatabaseSeeder** - Exécute tous les seeders dans le bon ordre

## 🔧 Personnalisation

### Ajouter de nouvelles migrations
```bash
php spark make:migration NomDeLaMigration
```

### Ajouter de nouveaux seeders
```bash
php spark make:seeder NomDuSeeder
```

## ⚠️ Points importants

1. **Ordre des migrations** : Respecte les dépendances entre tables
2. **Contraintes PostgreSQL** : Ajoutées via des requêtes SQL directes
3. **Clés étrangères** : Configurées avec les bonnes actions (CASCADE/RESTRICT)
4. **Trigger automatique** : Crée automatiquement les préférences de notification
5. **Données de test** : Les mots de passe sont hashés en SHA256

## 🎯 Avantages de cette approche

- ✅ Versionning complet de la base de données
- ✅ Déploiement facilité
- ✅ Rollback possible en cas de problème
- ✅ Cohérence entre environnements
- ✅ Collaboration en équipe simplifiée
- ✅ Données de test intégrées

## 📝 Comptes de test créés

### Enseignants
- alice.dupont@example.edu (mot de passe: AlicePass2025!)
- bruno.martin@example.edu (mot de passe: BrunoPass2025!)
- celine.lefevre@example.edu (mot de passe: CelinePass2025!)
- damien.roche@example.edu (mot de passe: DamienPass2025!)
- emma.moreau@example.edu (mot de passe: EmmaPass2025!)
- fabrice.girard@example.edu (mot de passe: FabricePass2025!)
- gaelle.perrin@example.edu (mot de passe: GaellePass2025!)
- hugo.leblanc@example.edu (mot de passe: HugoPass2025!)

### Directeur
- directeur@example.edu (mot de passe: DirecteurPass2025!)