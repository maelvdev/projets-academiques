#!/bin/bash

echo "Installation des dépendances NPM..."
npm install

echo "Lancement de php spark serve..."
php spark serve &

echo "Lancement de npm run watch..."
npm run watch &

