# 🚀 Installation du projet

Pour installer et lancer correctement ce projet, vous devez exécuter le script automatique **`run.sh`**.
Ce script se charge d’installer les dépendances nécessaires et de démarrer les services requis (serveur PHP et watcher front-end).

---

## 📦 Prérequis

Avant de commencer, assurez-vous d’avoir installé :

* **PHP 8+**
* **Node.js + npm**
* Un terminal compatible Bash (Linux, macOS ou Git Bash sous Windows)

---

## ▶️ Installation et démarrage

1. Ouvrez un terminal à la racine du projet.

2. Rendez le script exécutable si nécessaire :
   chmod +x run.sh
   
3. Exécutez simplement :
   ./run.sh

---

## 📁 Ce que fait automatiquement `run.sh`

* Installe les dépendances JavaScript (`npm install`)

* Lance le serveur PHP :
  php spark serve

* Lance le watcher front-end :
  npm run watch

Ces deux services seront démarrés en parallèle.

---

## 🛠 Développement

Une fois le script exécuté :

* Le serveur backend est disponible sur :
  **[http://localhost:8080](http://localhost:8080)**
* Les fichiers front-end sont reconstruits automatiquement à chaque modification.


