<?php

namespace App\Models;

use CodeIgniter\Model;

class NotificationModel extends Model
{
	protected $table            = 'notification';
	protected $primaryKey       = 'id_notif';
	
	protected $allowedFields    = ['email_ens', 'notif1', 'notif2'];
	
	protected $returnType       = 'array';
	protected $useTimestamps    = false; // Pas de created_at/updated_at dans ton SQL
}