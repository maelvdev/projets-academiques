<?php
namespace App\Models;

use CodeIgniter\Model;

class RattrapageModel extends Model {
    protected $table = 'rattrapage';
    protected $primaryKey = 'id_rattrapage';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = ['mail_enseignant', 'id_ressource', 'date', 'semestre'];

    // Dates
    protected $useTimestamps = false;

    // Validation
    protected $validationRules = [
        'mail_enseignant' => 'required|valid_email|max_length[100]',
        'id_ressource' => 'required|integer',
        'date' => 'required|valid_date',
        'semestre' => 'required|integer|greater_than[0]|less_than[7]'
    ];
    
    protected $validationMessages = [
        'mail_enseignant' => [
            'required' => 'L\'email de l\'enseignant est requis',
            'valid_email' => 'L\'email doit être valide'
        ],
        'id_ressource' => [
            'required' => 'La ressource est requise',
            'integer' => 'L\'ID de la ressource doit être un nombre entier'
        ],
        'date' => [
            'required' => 'La date est requise',
            'valid_date' => 'La date doit être valide'
        ],
        'semestre' => [
            'required' => 'Le semestre est requis',
            'integer' => 'Le semestre doit être un nombre entier'
        ]
    ];

    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    /**
     * Récupère tous les rattrapages
     */
    public function getAll() {
        return $this->findAll();
    }

    /**
     * Récupère un rattrapage par son identifiant
     */
    public function getById(int $id) {
        return $this->find($id);
    }

    /**
     * Crée un nouveau rattrapage
     */
    public function createRattrapage(array $data) {
        return $this->insert($data);
    }

    /**
     * Met à jour un rattrapage existant
     */
    public function updateRattrapage(int $id, array $data) {
        return $this->update($id, $data);
    }

    /**
     * Supprime un rattrapage
     */
    public function deleteRattrapage(int $id) {
        return $this->delete($id);
    }

    /**
     * Récupère les rattrapages d'un enseignant
     */
    public function getRattrapagesByEnseignant(string $email) {
        return $this->where('mail_enseignant', $email)
                    ->orderBy('date', 'DESC')
                    ->findAll();
    }

    /**
     * Récupère les rattrapages d'un semestre
     */
    public function getRattrapagesBySemestre(int $semestre) {
        return $this->where('semestre', $semestre)
                    ->orderBy('date', 'DESC')
                    ->findAll();
    }

    /**
     * Récupère tous les rattrapages avec leurs informations détaillées
     * (ressource, enseignant, DS, étudiants)
     */
    public function getAllWithDetails() {
        $db = \Config\Database::connect();
        
        // Récupérer tous les rattrapages avec leurs infos liées
        $builder = $db->table('rattrapage R');
        $builder->select('
            R.id_rattrapage,
            R.date as date_rattrapage,
            R.semestre,
            R.mail_enseignant,
            R.id_ressource,
            Res.nom as ressource_nom,
            U.nom as enseignant_nom,
            U.prenom as enseignant_prenom,
            DS.id_ds,
            DS.date as date_ds,
            DS.type_ds,
            DS.duree,
            P.date as date_planification,
            P.salle as salle_planification
        ');
        $builder->join('ressource Res', 'Res.id_ressource = R.id_ressource', 'left');
        $builder->join('utilisateur U', 'U.email = R.mail_enseignant', 'left');
        $builder->join('ds DS', 'DS.id_ressource = R.id_ressource AND DS.semestre = R.semestre AND DS.mail_enseignant = R.mail_enseignant AND DS.date = R.date', 'left');
        $builder->join('planification P', 'P.id_rattrapage = R.id_rattrapage', 'left');
        $builder->orderBy('R.date', 'DESC');
        
        $rattrapages = $builder->get()->getResultArray();
        
        // Pour chaque rattrapage, récupérer les étudiants
        foreach ($rattrapages as &$rattrapage) {
            $absenceBuilder = $db->table('absence A');
            $absenceBuilder->select('E.email, E.nom, E.prenom, E.semestre as semestre_etudiant, A.justifie');
            $absenceBuilder->join('eleve E', 'E.email = A.email_etud', 'left');
            $absenceBuilder->where('A.id_rattrapage', $rattrapage['id_rattrapage']);
            
            $rattrapage['etudiants'] = $absenceBuilder->get()->getResultArray();
        }
        
        return $rattrapages;
    }

    /**
     * Récupère les rattrapages récents (Pour le Directeur)
     * Utilise des JOINS pour avoir les noms, salles, statuts et compte d'étudiants
     */
    public function getRattrapagesRecents(int $limit = 3) {
        return $this->select('
                rattrapage.id_rattrapage,
                ressource.nom AS ressource,
                rattrapage.semestre,
                rattrapage.date as date_rattrapage,
                rattrapage.mail_enseignant,
                utilisateur.nom as enseignant_nom,
                utilisateur.prenom as enseignant_prenom,
                planification.date as date_planification,
                planification.salle,
                planification.type as statut,
                COUNT(DISTINCT absence.email_etud) as nb_etudiants
            ')
            ->join('ressource', 'rattrapage.id_ressource = ressource.id_ressource', 'left')
            ->join('utilisateur', 'rattrapage.mail_enseignant = utilisateur.email', 'left')
            ->join('planification', 'rattrapage.id_rattrapage = planification.id_rattrapage', 'left')
            ->join('absence', 'rattrapage.id_rattrapage = absence.id_rattrapage', 'left')
            ->groupBy('rattrapage.id_rattrapage, ressource.nom, rattrapage.semestre, rattrapage.date, rattrapage.mail_enseignant, utilisateur.nom, utilisateur.prenom, planification.date, planification.salle, planification.type')
            ->orderBy('rattrapage.date', 'DESC')
            ->findAll($limit);
    }

    /**
     * Récupère les rattrapages spécifiques d'un enseignant
     */
    public function getMesRattrapages(string $email, int $limit = 3) {
        return $this->select('
        rattrapage.id_rattrapage,
        ressource.nom AS ressource,
        rattrapage.semestre,
        
        rattrapage.date as date_ds_original,
        planification.date as date_rattrapage,
        
        planification.salle,
        planification.type as statut,
        planification.commentaire,
        
        ds.duree,
       
        COUNT(DISTINCT absence.email_etud) as nb_etudiants
    ')
            ->join('ressource', 'rattrapage.id_ressource = ressource.id_ressource', 'left')
            ->join('ds', 'rattrapage.id_ressource = ds.id_ressource AND rattrapage.semestre = ds.semestre AND rattrapage.mail_enseignant = ds.mail_enseignant AND rattrapage.date = ds.date', 'left')
            ->join('planification', 'rattrapage.id_rattrapage = planification.id_rattrapage', 'left')
            ->join('absence', 'rattrapage.id_rattrapage = absence.id_rattrapage', 'left')
            ->where('rattrapage.mail_enseignant', $email)
            ->groupBy('
        rattrapage.id_rattrapage, 
        ressource.nom, 
        rattrapage.semestre, 
        rattrapage.date, 
        ds.date, 
        planification.date, 
        planification.salle, 
        planification.type, 
        planification.commentaire,
        ds.duree
    ')
            ->orderBy('rattrapage.date', 'DESC')
            ->findAll($limit);
    }
}
