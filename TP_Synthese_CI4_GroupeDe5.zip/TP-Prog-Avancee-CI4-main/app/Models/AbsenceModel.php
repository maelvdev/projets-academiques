<?php
namespace App\Models;

use CodeIgniter\Model;

class AbsenceModel extends Model {
    protected $table = 'absence';
    // Clé primaire composée (email_etud, id_rattrapage)
    protected $primaryKey = ['email_etud', 'id_rattrapage'];
    protected $useAutoIncrement = false;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = ['email_etud', 'id_rattrapage', 'justifie'];

    // Dates
    protected $useTimestamps = false;

    // Validation
    protected $validationRules = [
        'email_etud' => 'required|valid_email|max_length[100]',
        'id_rattrapage' => 'required|integer',
        'justifie' => 'required'
    ];

    protected $validationMessages = [
        'email_etud' => [
            'required' => 'L\'email de l\'étudiant est requis',
            'valid_email' => 'L\'email doit être valide'
        ],
        'id_rattrapage' => [
            'required' => 'L\'ID du rattrapage est requis',
            'integer' => 'L\'ID du rattrapage doit être un nombre entier'
        ],
        'justifie' => [
            'required' => 'Le statut de justification est requis'
        ]
    ];

    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    /**
     * Récupère toutes les absences
     */
    public function getAll() {
        return $this->findAll();
    }

    /**
     * Recherche selon des conditions fournies
     */
    public function findBy(array $where) {
        return $this->where($where)->findAll();
    }

    /**
     * Insère une absence
     */
    public function insertAbsence(array $data) {
        return $this->insert($data);
    }

    /**
     * Insère plusieurs absences en batch
     */
    public function insertMultipleAbsences(array $absences): bool
    {
        if (empty($absences)) {
            return true;
        }
        
        // Utilise directement le Query Builder pour éviter les problèmes avec les clés primaires composées
        $db = \Config\Database::connect();
        $builder = $db->table($this->table);
        
        try {
            $result = $builder->insertBatch($absences);
            return $result !== false && $result > 0;
        } catch (\Exception $e) {
            log_message('error', 'Erreur insertBatch Absence: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Récupère toutes les absences d'un rattrapage
     */
    public function getAbsencesByRattrapage(int $id_rattrapage): array
    {
        return $this->where('id_rattrapage', $id_rattrapage)->findAll();
    }

    /**
     * Récupère toutes les absences d'un étudiant
     */
    public function getAbsencesByEtudiant(string $email_etud): array
    {
        return $this->where('email_etud', $email_etud)->findAll();
    }

    /**
     * Supprime selon des conditions
     */
    public function deleteBy(array $where) {
        return $this->where($where)->delete();
    }
}
