<?php
namespace App\Models;

use CodeIgniter\Model;

class PlanificationModel extends Model {
    protected $table = 'planification';
    protected $primaryKey = 'id_rattrapage';
    protected $returnType = 'array';
    protected $allowedFields = ['id_rattrapage', 'type', 'date', 'salle', 'commentaire'];

    // Conteneur interne pour les setters
    protected $data = [];

    // Récupère toutes les planifications
    public function getAll() {
        return $this->findAll();
    }

    // Récupère une planification par l'identifiant du rattrapage
    public function getById(int $id) {
        return $this->asArray()->where('id_rattrapage', $id)->first();
    }

    // Crée une nouvelle planification
    public function createPlanification(array $data) {
        return $this->insert($data);
    }

    // Met à jour une planification existante
    public function updatePlanification(int $id, array $data) {
        return $this->update($id, $data);
    }

    // Supprime une planification
    public function deletePlanification(int $id) {
        return $this->delete($id);
    }

    // Getters et setters
    public function setIdRattrapage(int $id) {
        $this->data['id_rattrapage'] = $id;
        return $this;
    }
    public function getIdRattrapage() {
        return $this->data['id_rattrapage'] ?? null;
    }

    public function setType(string $type) {
        $this->data['type'] = $type;
        return $this;
    }
    public function getType() {
        return $this->data['type'] ?? null;
    }

    public function setDate(string $date) {
        $this->data['date'] = $date;
        return $this;
    }
    public function getDate() {
        return $this->data['date'] ?? null;
    }

    public function setSalle(string $salle) {
        $this->data['salle'] = $salle;
        return $this;
    }
    public function getSalle() {
        return $this->data['salle'] ?? null;
    }

    public function setCommentaire(string $c) {
        $this->data['commentaire'] = $c;
        return $this;
    }
    public function getCommentaire() {
        return $this->data['commentaire'] ?? null;
    }

    public function saveData() {
        if (isset($this->data['id_rattrapage']) && $this->getById($this->data['id_rattrapage'])) {
            $id = $this->data['id_rattrapage'];
            $data = $this->data;
            unset($data['id_rattrapage']);
            return $this->update($id, $data);
        }
        return $this->insert($this->data);
    }
}
