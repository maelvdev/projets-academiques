<?php
namespace App\Models;

use CodeIgniter\Model;

class DSModel extends Model {
    protected $table = 'ds';
    protected $primaryKey = 'id_ds';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $allowedFields = ['date', 'id_ressource', 'semestre', 'mail_enseignant', 'type_ds', 'duree'];

    // Validation
    protected $validationRules = [
        'date' => 'required|valid_date',
        'id_ressource' => 'required|integer',
        'semestre' => 'required|integer|greater_than[0]|less_than[7]',
        'mail_enseignant' => 'required|valid_email|max_length[100]',
        'type_ds' => 'required|in_list[DS Table,DS Machine]',
        'duree' => 'required|integer|greater_than[0]'
    ];

    /**
     * Crée un nouveau DS
     *
     * @param array $data Les données du DS
     * @return int|false L'ID du DS créé ou false
     */
    public function createDS(array $data)
    {
        return $this->insert($data);
    }

    /**
     * Récupère un DS par son ID
     *
     * @param int $id L'ID du DS
     * @return array|null Les données du DS ou null
     */
    public function getDSById(int $id): ?array
    {
        return $this->find($id);
    }

    /**
     * Récupère tous les DS d'un enseignant
     *
     * @param string $mail_enseignant Email de l'enseignant
     * @return array Liste des DS
     */
    public function getDSByEnseignant(string $mail_enseignant): array
    {
        return $this->where('mail_enseignant', $mail_enseignant)
                    ->orderBy('date', 'DESC')
                    ->findAll();
    }

    /**
     * Récupère tous les DS d'un semestre
     *
     * @param int $semestre Le numéro du semestre
     * @return array Liste des DS
     */
    public function getDSBySemestre(int $semestre): array
    {
        return $this->where('semestre', $semestre)
                    ->orderBy('date', 'DESC')
                    ->findAll();
    }

    /**
     * Récupère tous les DS d'une ressource
     *
     * @param int $id_ressource L'ID de la ressource
     * @return array Liste des DS
     */
    public function getDSByRessource(int $id_ressource): array
    {
        return $this->where('id_ressource', $id_ressource)
                    ->orderBy('date', 'DESC')
                    ->findAll();
    }

    /**
     * Met à jour un DS
     *
     * @param int $id L'ID du DS
     * @param array $data Les nouvelles données
     * @return bool Succès ou échec
     */
    public function updateDS(int $id, array $data): bool
    {
        return $this->update($id, $data);
    }

    /**
     * Supprime un DS
     *
     * @param int $id L'ID du DS
     * @return bool Succès ou échec
     */
    public function deleteDS(int $id): bool
    {
        return $this->delete($id);
    }
}
