<?php
namespace App\Models;

use CodeIgniter\Model;

class TokenVerificationModel extends Model {
    protected $table = 'token_verification';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $allowedFields = ['token_hash', 'email_utilisateur', 'date_creation', 'date_expiration', 'type'];

    // Insère un token (hash) pour un utilisateur
    public function createToken(array $data) {
        return $this->insert($data);
    }

    // Recherche un token par son hash (renvoie la ligne ou null)
    public function findByHash(string $hash) {
        return $this->asArray()->where('token_hash', $hash)->first();
    }

    // Supprime un token par id
    public function deleteById(int $id) {
        return $this->delete($id);
    }

    // Supprime les tokens expirés (utile en tâche cron)
    public function purgeExpired() {
        return $this->where('date_expiration <', date('Y-m-d H:i:s'))->delete();
    }
}
