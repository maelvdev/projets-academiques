<?php

namespace App\Models;

use CodeIgniter\Model;

class RessourceModel extends Model
{
    protected $table = 'ressource';
    protected $primaryKey = 'id_ressource';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = ['nom', 'semestre'];

    // Dates
    protected $useTimestamps = false;

    // Validation
    protected $validationRules = [
        'nom' => 'required|max_length[100]|is_unique[Ressource.nom]',
        'semestre' => 'required|integer|greater_than[0]|less_than[7]'
    ];
    protected $validationMessages = [
        'nom' => [
            'required' => 'Le nom de la ressource est requis',
            'max_length' => 'Le nom de la ressource ne doit pas dépasser 100 caractères',
            'is_unique' => 'Cette ressource existe déjà'
        ],
        'semestre' => [
            'required' => 'Le semestre est requis',
            'integer' => 'Le semestre doit être un nombre entier',
            'greater_than' => 'Le semestre doit être entre 1 et 6',
            'less_than' => 'Le semestre doit être entre 1 et 6'
        ]
    ];
    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    /**
     * Récupère toutes les ressources d'un semestre donné
     *
     * @param int $semestre Le numéro du semestre (1-6)
     * @return array Liste des ressources
     */
    public function getRessourcesBySemestre(int $semestre): array
    {
        return $this->where('semestre', $semestre)
                    ->orderBy('nom', 'ASC')
                    ->findAll();
    }

    /**
     * Récupère toutes les ressources groupées par semestre
     *
     * @return array Ressources groupées par semestre
     */
    public function getAllRessourcesGrouped(): array
    {
        $ressources = $this->orderBy('semestre', 'ASC')
                          ->orderBy('nom', 'ASC')
                          ->findAll();
        
        $grouped = [];
        foreach ($ressources as $ressource) {
            $sem = $ressource['semestre'];
            if (!isset($grouped[$sem])) {
                $grouped[$sem] = [];
            }
            $grouped[$sem][] = $ressource;
        }
        
        return $grouped;
    }

    /**
     * Récupère une ressource par son ID
     *
     * @param int $id L'ID de la ressource
     * @return array|null Les données de la ressource ou null
     */
    public function getRessourceById(int $id): ?array
    {
        return $this->find($id);
    }

    /**
     * Crée une nouvelle ressource
     *
     * @param array $data Les données de la ressource
     * @return int|false L'ID de la ressource créée ou false
     */
    public function createRessource(array $data)
    {
        return $this->insert($data);
    }

    /**
     * Met à jour une ressource
     *
     * @param int $id L'ID de la ressource
     * @param array $data Les nouvelles données
     * @return bool Succès ou échec
     */
    public function updateRessource(int $id, array $data): bool
    {
        return $this->update($id, $data);
    }

    /**
     * Supprime une ressource
     *
     * @param int $id L'ID de la ressource
     * @return bool Succès ou échec
     */
    public function deleteRessource(int $id): bool
    {
        return $this->delete($id);
    }
}
