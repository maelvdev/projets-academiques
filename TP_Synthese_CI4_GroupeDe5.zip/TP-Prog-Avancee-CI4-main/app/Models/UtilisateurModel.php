<?php
namespace App\Models;

use CodeIgniter\Model;

class UtilisateurModel extends Model {
    protected $table = 'utilisateur';
    protected $primaryKey = 'email';

    protected $useAutoIncrement = false;

    protected $returnType = 'array';
    protected $allowedFields = ['email', 'mot_de_passe', 'role', 'nom', 'prenom', 'compte_valide'];

    // Conteneur interne pour les setters
    protected $data = [];

    // Méthodes utilitaires CRUD
    public function getAll() {
        return $this->findAll();
    }

    public function getByEmail(string $email) {
        return $this->asArray()->where('email', $email)->first();
    }

    // Vérifie si un utilisateur existe par email
    public function existsByEmail(string $email): bool {
        return (bool) $this->asArray()->where('email', $email)->countAllResults();
    }

    public function createUtilisateur(array $data) {
        return $this->insert($data);
    }

    public function updateUtilisateur(string $email, array $data) {
        return $this->update($email, $data);
    }

    /**
     * Récupère tous les utilisateurs d'un rôle spécifique
     *
     * @param string $role Le rôle recherché
     * @return array Liste des utilisateurs
     */
    public function getUtilisateursByRole(string $role): array
    {
        return $this->where('role', $role)
                    ->where('compte_valide', true)
                    ->orderBy('nom', 'ASC')
                    ->orderBy('prenom', 'ASC')
                    ->findAll();
    }

    public function deleteUtilisateur(string $email) {
        return $this->delete($email);
    }

    // Getters and setters for fields (chainable setters)
    public function setEmail(string $email) {
        $this->data['email'] = $email;
        return $this;
    }
    public function getEmail() {
        return $this->data['email'] ?? null;
    }

    public function setMotDePasse(string $mdp) {
        $this->data['mot_de_passe'] = $mdp;
        return $this;
    }
    public function getMotDePasse() {
        return $this->data['mot_de_passe'] ?? null;
    }

    public function setRole(string $role) {
        $this->data['role'] = $role;
        return $this;
    }
    public function getRole() {
        return $this->data['role'] ?? null;
    }

    public function setNom(string $nom) {
        $this->data['nom'] = $nom;
        return $this;
    }
    public function getNom() {
        return $this->data['nom'] ?? null;
    }

    public function setPrenom(string $prenom) {
        $this->data['prenom'] = $prenom;
        return $this;
    }
    public function getPrenom() {
        return $this->data['prenom'] ?? null;
    }

    public function setCompteValide(bool $valide) {
        $this->data['compte_valide'] = $valide;
        return $this;
    }
    public function getCompteValide() {
        return $this->data['compte_valide'] ?? null;
    }

    /**
     * Save the internal data (insert or update depending on primary key presence)
     */
    public function saveData() {
        if (isset($this->data['email']) && $this->getByEmail($this->data['email'])) {
            $email = $this->data['email'];
            $data = $this->data;
            unset($data['email']);
            return $this->update($email, $data);
        }
        return $this->insert($this->data);
    }
}
