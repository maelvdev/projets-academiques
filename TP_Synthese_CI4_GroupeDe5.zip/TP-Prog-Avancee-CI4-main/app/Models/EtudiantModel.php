<?php
namespace App\Models;

use CodeIgniter\Model;

class EtudiantModel extends Model {
    protected $table = 'eleve';
    protected $primaryKey = 'email';
    protected $useAutoIncrement = false;
    protected $returnType = 'array';
    protected $allowedFields = ['email','nom','prenom','semestre'];

    // Conteneur interne pour les setters
    protected $data = [];

    // Récupère tous les élèves
    public function getAll() {
        return $this->findAll();
    }

    public function getByEmail(string $email) {
        return $this->asArray()->where('email', $email)->first();
    }

    public function createEleve(array $data) {
        return $this->insert($data);
    }

    public function updateEleve(string $email, array $data) {
        return $this->update($email, $data);
    }

    public function deleteEleve(string $email) {
        return $this->delete($email);
    }

    public function setEmail(string $email) {
        $this->data['email'] = $email;
        return $this;
    }
    public function getEmail() {
        return $this->data['email'] ?? null;
    }

    public function setNom(string $nom) {
        $this->data['nom'] = $nom;
        return $this;
    }
    public function getNom() {
        return $this->data['nom'] ?? null;
    }

    public function setPrenom(string $prenom) {
        $this->data['prenom'] = $prenom;
        return $this;
    }
    public function getPrenom() {
        return $this->data['prenom'] ?? null;
    }

    public function setSemestre(int $sem) {
        $this->data['semestre'] = $sem;
        return $this;
    }
    public function getSemestre() {
        return $this->data['semestre'] ?? null;
    }

    /**
     * Recherche/filtrage paginé des élèves.
     * Accepts keys: q (search in nom/prenom/email), semestre, annee, limit, offset
     * Returns an array of matching rows.
     */
    public function findWithFilters(array $opts = []) {
        $qb = $this->builder();

        if (!empty($opts['q'])) {
            $q = trim($opts['q']);
            $qb->groupStart()->like('nom', $q)->orLike('prenom', $q)->orLike('email', $q)->groupEnd();
        }

        if (!empty($opts['semestre'])) {
            $qb->where('semestre', $opts['semestre']);
        }

        $qb->orderBy('nom', 'ASC');

        if (isset($opts['limit'])) {
            $limit = (int) $opts['limit'];
            $offset = (int) ($opts['offset'] ?? 0);
            $result = $qb->get($limit, $offset)->getResultArray();
            return $result;
        }

        return $qb->get()->getResultArray();
    }

    /**
     * Count total matching students (for pagination)
     * More efficient than fetching all rows
     */
    public function countWithFilters(array $opts = []) {
        $qb = $this->builder();

        if (!empty($opts['q'])) {
            $q = trim($opts['q']);
            $qb->groupStart()->like('nom', $q)->orLike('prenom', $q)->orLike('email', $q)->groupEnd();
        }

        if (!empty($opts['semestre'])) {
            $qb->where('semestre', $opts['semestre']);
        }

        return $qb->countAllResults();
    }

    public function saveData() {
        if (isset($this->data['email']) && $this->getByEmail($this->data['email'])) {
            $email = $this->data['email'];
            $data = $this->data;
            unset($data['email']);
            return $this->update($email, $data);
        }
        return $this->insert($this->data);
    }
}
