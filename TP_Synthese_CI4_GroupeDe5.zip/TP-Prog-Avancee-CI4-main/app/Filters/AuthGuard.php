<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\UtilisateurModel;

class AuthGuard implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();

        if (! $session->get('isLoggedIn')) {
            return redirect()->to('/auth/connexion');
        }

        $model = new UtilisateurModel();
        $user = $model->find($session->get('email'));

        if (!$user) {
            $session->destroy();
            return redirect()->to('/auth/connexion')->with('error', 'Compte introuvable.');
        }

        $sessionRole = $session->get('role');
        $dbRole = $user['role'];
        $sessionValide = $session->get('compte_valide');
        $dbValide = $user['compte_valide'];

        if (strcasecmp($sessionRole, $dbRole) !== 0 || $sessionValide != $dbValide) {
            $session->destroy();
            return redirect()->to('/auth/connexion')->with('error', 'Vos droits ou votre statut ont été modifiés. Veuillez vous reconnecter.');
        }


        if (! $session->get('compte_valide')) {
            return redirect()->to('/auth/verif')->with('error', 'Votre compte n\'est pas encore vérifié.');
        }

        $role = $session->get('role');
        $uri = $request->getUri()->getPath();

        $uri = trim($uri, '/');

        $routesDirecteur = [
            'gestion_rattrapage',
            'gestion_utilisateur',
            'etudiants',
            'etudiants/create',
            'etudiants/update',
            'etudiants/delete',
            'visualisation_rattrapage',
            'modifier_rattrapage',
            'gestion_utilisateur/voir',
            'gestion_utilisateur/modifier'
        ];


        if ($role === 'enseignant') {
            foreach ($routesDirecteur as $routeInterdite) {
                if (strpos($uri, $routeInterdite) === 0) {
                    return redirect()->to('/accueil')->with('error', 'Accès non autorisé.');
                }
            }
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Rien à faire ici
    }
}
