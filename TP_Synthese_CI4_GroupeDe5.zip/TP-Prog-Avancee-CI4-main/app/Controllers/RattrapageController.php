<?php

namespace App\Controllers;

use App\Models\RessourceModel;
use App\Models\EtudiantModel;
use App\Models\UtilisateurModel;
use App\Models\RattrapageModel;
use App\Models\DSModel;
use App\Models\AbsenceModel;
use App\Models\NotificationModel;

class RattrapageController extends BaseController {

    /**
     * Affiche la page de gestion des rattrapages
     */
    public function index() {
        $rattrapageModel = new RattrapageModel();
        $rattrapages = $rattrapageModel->getAllWithDetails();

        // Récupérer les filtres depuis la requête GET
        $filters = [
            'search' => $this->request->getGet('search') ?? '',
            'semestre' => $this->request->getGet('semestre') ?? '',
            'annee' => $this->request->getGet('annee') ?? ''
        ];

        // Formater les données pour la vue
        $formattedRattrapages = [];
        foreach ($rattrapages as $rattrapage) {
            // Déterminer l'état du rattrapage
            $etat = 'En attente';
            if ($rattrapage['date_planification']) {
                $etat = 'Programmé';
            }

            // Calculer l'année BUT basée sur le semestre
            $anneeBut = ceil($rattrapage['semestre'] / 2);

            $formattedRattrapages[] = [
                'id_rattrapage' => $rattrapage['id_rattrapage'],
                'ressource' => $rattrapage['ressource_nom'],
                'enseignant' => [
                    'nom' => $rattrapage['enseignant_nom'],
                    'prenom' => $rattrapage['enseignant_prenom'],
                ],
                'date_ds_original' => $rattrapage['date_ds'],
                'date_rattrapage' => $rattrapage['date_planification'],
                'semestre' => $rattrapage['semestre'],
                'annee_but' => $anneeBut,
                'type' => $rattrapage['type_ds'] ?? 'Devoir surveillé',
                'duree' => $rattrapage['duree'] ?? 0,
                'etat' => $etat,
                'etudiants' => $rattrapage['etudiants'],
                'salle' => $rattrapage['salle_planification']
            ];
        }

        // Appliquer les filtres
        $filteredRattrapages = $this->applyFilters($formattedRattrapages, $filters);

        $data = [
            'role' => session()->get('role') ?? 'Directeur',
            'active_page' => 'gestion_rattrapage',
            'rattrapages' => $filteredRattrapages,
            'filters' => $filters
        ];

        return view('modeDirecteur/gestion_rattrapage', $data);
    }

    /**
     * Applique les filtres aux rattrapages
     */
    private function applyFilters(array $rattrapages, array $filters): array
    {
        $filtered = $rattrapages;

        // Filtre par recherche (ressource, enseignant, étudiant)
        if (!empty($filters['search'])) {
            $search = strtolower($filters['search']);
            $filtered = array_filter($filtered, function($rattrapage) use ($search) {
                // Recherche dans la ressource
                if (stripos($rattrapage['ressource'], $search) !== false) {
                    return true;
                }
                
                // Recherche dans le nom de l'enseignant
                $enseignant = strtolower($rattrapage['enseignant']['nom'] . ' ' . $rattrapage['enseignant']['prenom']);
                if (stripos($enseignant, $search) !== false) {
                    return true;
                }
                
                // Recherche dans les étudiants
                foreach ($rattrapage['etudiants'] as $etudiant) {
                    $etudiantNom = strtolower($etudiant['nom'] . ' ' . $etudiant['prenom']);
                    if (stripos($etudiantNom, $search) !== false) {
                        return true;
                    }
                }
                
                return false;
            });
        }

        // Filtre par semestre
        if (!empty($filters['semestre'])) {
            $semestreNum = (int) str_replace('S', '', $filters['semestre']);
            $filtered = array_filter($filtered, function($rattrapage) use ($semestreNum) {
                return $rattrapage['semestre'] == $semestreNum;
            });
        }

        // Filtre par année BUT
        if (!empty($filters['annee'])) {
            $anneeNum = (int) str_replace('BUT', '', $filters['annee']);
            $filtered = array_filter($filtered, function($rattrapage) use ($anneeNum) {
                return $rattrapage['annee_but'] == $anneeNum;
            });
        }

        return array_values($filtered); // Réindexer le tableau
    }

    /**
     * Affiche le formulaire de création de rattrapage
     */
    public function creer() {
        $data = [
            'role' => session()->get('role') ?? 'Directeur',
            'active_page' => 'gestion_rattrapage',
        ];

        return view('rattrapage/nouveauRattrapage', $data);
    }

    /**
     * Récupère les ressources d'un semestre (AJAX endpoint)
     */
    public function getRessources()
    {
        // Permettre les requêtes non-AJAX temporairement pour déboguer
        // if (!$this->request->isAJAX()) {
        //     return $this->response->setJSON(['error' => 'Requête invalide']);
        // }

        $semestre = $this->request->getGet('semestre');

        if (!$semestre || !is_numeric($semestre)) {
            log_message('error', 'Semestre invalide: ' . $semestre);
            return $this->response->setJSON(['error' => 'Semestre invalide']);
        }

        try {
            $ressourceModel = new RessourceModel();
            $ressources = $ressourceModel->getRessourcesBySemestre((int)$semestre);

            log_message('info', 'Ressources trouvées pour semestre ' . $semestre . ': ' . count($ressources));
            log_message('debug', 'Ressources: ' . json_encode($ressources));

            return $this->response->setJSON(['ressources' => $ressources]);
        } catch (\Exception $e) {
            log_message('error', 'Erreur getRessources: ' . $e->getMessage());
            return $this->response->setJSON(['error' => 'Erreur serveur', 'message' => $e->getMessage()]);
        }
    }

    /**
     * Récupère la liste des enseignants (AJAX endpoint)
     */
    public function getEnseignants()
    {
        // Permettre les requêtes non-AJAX temporairement pour déboguer
        // if (!$this->request->isAJAX()) {
        //     return $this->response->setJSON(['error' => 'Requête invalide']);
        // }

        try {
            $utilisateurModel = new UtilisateurModel();
            $enseignants = $utilisateurModel->getUtilisateursByRole('enseignant');
            $directeurs = $utilisateurModel->getUtilisateursByRole('directeur');
            
            // Fusionner les deux listes
            $utilisateurs = array_merge($enseignants, $directeurs);

            log_message('info', 'Utilisateurs trouvés: ' . count($utilisateurs) . ' (Enseignants: ' . count($enseignants) . ', Directeurs: ' . count($directeurs) . ')');
            log_message('debug', 'Utilisateurs: ' . json_encode($utilisateurs));

            return $this->response->setJSON(['enseignants' => $utilisateurs]);
        } catch (\Exception $e) {
            log_message('error', 'Erreur getEnseignants: ' . $e->getMessage());
            return $this->response->setJSON(['error' => 'Erreur serveur', 'message' => $e->getMessage()]);
        }
    }


    /**
     * Supprimer un rattrapage
     */
    public function supprimer($id_rattrapage)
    {
        $db = \Config\Database::connect();

        // On utilise une transaction pour la sécurité (tout ou rien)
        $db->transStart();

        try {
            // 1. SUPPRIMER LES ENFANTS (Les absences liées)
            // C'est ça qui bloquait : on vide la table Absence pour ce rattrapage d'abord
            $db->table('absence')->where('id_rattrapage', $id_rattrapage)->delete();

            // 2. SUPPRIMER LE PARENT (Le rattrapage)
            // Maintenant qu'il n'a plus d'enfants "Absence", la suppression est autorisée.
            // (Note: La table 'Planification' se nettoiera toute seule grâce au ON DELETE CASCADE défini dans votre SQL)
            $db->table('rattrapage')->where('id_rattrapage', $id_rattrapage)->delete();

            $db->transComplete();

            if ($db->transStatus() === false) {
                return redirect()->back()->with('error', 'Impossible de supprimer le rattrapage.');
            }

            return redirect()->to('/gestion_rattrapage')->with('success', 'Le rattrapage a été supprimé avec succès.');

        } catch (\Exception $e) {
            // En cas d'erreur, on annule tout
            $db->transRollback();
            return redirect()->back()->with('error', 'Erreur lors de la suppression : ' . $e->getMessage());
        }
    }


    /**
     * Crée une nouvelle ressource (AJAX endpoint)
     */
    public function createRessource()
    {
        try {
            $nom = $this->request->getPost('nom');
            $semestre = $this->request->getPost('semestre');

            if (!$nom || !$semestre) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Nom et semestre requis'
                ]);
            }

            $db = \Config\Database::connect();

            // Vérifier si la ressource existe déjà
            $existing = $db->table('ressource')
                ->where('nom', trim($nom))
                ->where('semestre', $semestre)
                ->get()
                ->getRowArray();

            if ($existing) {
                return $this->response->setJSON([
                    'success' => true,
                    'id_ressource' => $existing['id_ressource'],
                    'message' => 'Ressource déjà existante'
                ]);
            }

            // Créer la nouvelle ressource
            $data = [
                'nom' => trim($nom),
                'semestre' => $semestre
            ];

            $result = $db->table('ressource')->insert($data);
            $id = $result ? $db->insertID() : false;

            if ($id) {
                return $this->response->setJSON([
                    'success' => true,
                    'id_ressource' => $id,
                    'message' => 'Ressource créée avec succès'
                ]);
            } else {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Erreur lors de la création'
                ]);
            }
        } catch (\Exception $e) {
            log_message('error', 'Erreur createRessource: ' . $e->getMessage());
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Erreur serveur: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Récupère les étudiants d'un semestre (AJAX endpoint)
     */
    public function getEtudiants()
    {
        // Permettre les requêtes non-AJAX temporairement pour déboguer
        // if (!$this->request->isAJAX()) {
        //     return $this->response->setJSON(['error' => 'Requête invalide']);
        // }

        $semestre = $this->request->getGet('semestre');

        if (!$semestre || !is_numeric($semestre)) {
            log_message('error', 'Semestre invalide pour étudiants: ' . $semestre);
            return $this->response->setJSON(['error' => 'Semestre invalide']);
        }

        try {
            $etudiantModel = new EtudiantModel();
            $etudiants = $etudiantModel->where('semestre', (int)$semestre)
                ->orderBy('nom', 'ASC')
                ->orderBy('prenom', 'ASC')
                ->findAll();

            log_message('info', 'Étudiants trouvés pour semestre ' . $semestre . ': ' . count($etudiants));
            log_message('debug', 'Étudiants: ' . json_encode($etudiants));

            return $this->response->setJSON(['etudiants' => $etudiants]);
        } catch (\Exception $e) {
            log_message('error', 'Erreur getEtudiants: ' . $e->getMessage());
            return $this->response->setJSON(['error' => 'Erreur serveur', 'message' => $e->getMessage()]);
        }
    }

    /**
     * Crée un nouveau rattrapage avec DS et absences
     */
    public function create()
    {
        // Validation des données
        $validation = \Config\Services::validation();

        $validation->setRules([
            'semestre' => 'required|integer|greater_than[0]|less_than[7]',
            'id_ressource' => 'required|integer',
            'mail_enseignant' => 'required|valid_email',
            'date_ds' => 'required|valid_date',
            'type_ds' => 'required|in_list[DS Table,DS Machine]',
            'duree' => 'required|integer|greater_than[0]',
            'etudiants_absents' => 'required'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return $this->response->setJSON([
                'success' => false,
                'errors' => $validation->getErrors()
            ]);
        }

        $db = \Config\Database::connect();
        $db->transStart();

        try {
            // 1. Créer le DS
            $dsModel = new DSModel();
            $dsData = [
                'date' => $this->request->getPost('date_ds'),
                'id_ressource' => $this->request->getPost('id_ressource'),
                'semestre' => $this->request->getPost('semestre'),
                'mail_enseignant' => $this->request->getPost('mail_enseignant'),
                'type_ds' => $this->request->getPost('type_ds'),
                'duree' => $this->request->getPost('duree')
            ];

            log_message('info', '=== CRÉATION DS ===');
            log_message('info', 'DS Data: ' . json_encode($dsData));

            $dsModel->createDS($dsData);

            log_message('info', 'DS créé avec succès');

            // 2. Créer le rattrapage
            $rattrapageModel = new RattrapageModel();
            $rattrapageData = [
                'mail_enseignant' => $this->request->getPost('mail_enseignant'),
                'id_ressource' => $this->request->getPost('id_ressource'),
                'date' => $this->request->getPost('date_ds'),
                'semestre' => $this->request->getPost('semestre')
            ];

            $id_rattrapage = $rattrapageModel->createRattrapage($rattrapageData);

            // 3. Créer les absences
            $etudiants_absents_raw = $this->request->getPost('etudiants_absents');
            log_message('info', '=== DÉBUT CRÉATION ABSENCES ===');
            log_message('info', 'POST etudiants_absents RAW: ' . var_export($etudiants_absents_raw, true));

            $etudiants_absents = json_decode($etudiants_absents_raw, true);
            log_message('info', 'JSON décodé: ' . var_export($etudiants_absents, true));
            log_message('info', 'Type de $etudiants_absents: ' . gettype($etudiants_absents));
            log_message('info', 'ID rattrapage: ' . var_export($id_rattrapage, true));

            if (!empty($etudiants_absents) && $id_rattrapage) {
                $absenceModel = new AbsenceModel();
                $absences = [];

                log_message('info', 'Nombre d\'étudiants à traiter: ' . count($etudiants_absents));

                foreach ($etudiants_absents as $index => $etudiant) {
                    log_message('info', "Étudiant $index: " . var_export($etudiant, true));
                    
                    // Gérer les deux formats possibles: string (email) ou object {email, justifie}
                    if (is_string($etudiant)) {
                        // Ancien format: juste l'email
                        $absences[] = [
                            'email_etud' => $etudiant,
                            'id_rattrapage' => $id_rattrapage,
                            'justifie' => 0
                        ];
                    } else if (is_array($etudiant) && isset($etudiant['email'])) {
                        // Nouveau format: objet avec email et justifie
                        $absences[] = [
                            'email_etud' => $etudiant['email'],
                            'id_rattrapage' => $id_rattrapage,
                            'justifie' => isset($etudiant['justifie']) ? (int)$etudiant['justifie'] : 0
                        ];
                    }
                }

                log_message('info', 'Array absences final: ' . var_export($absences, true));

                if (!empty($absences)) {
                    try {
                        $result = $absenceModel->insertMultipleAbsences($absences);
                        log_message('info', 'Résultat insertMultipleAbsences: ' . var_export($result, true));

                        // Vérification immédiate
                        $check = $db->table('absence')->where('id_rattrapage', $id_rattrapage)->countAllResults();
                        log_message('info', 'Vérification DB - Nombre d\'absences pour rattrapage ' . $id_rattrapage . ': ' . $check);
                    } catch (\Exception $e) {
                        log_message('error', 'ERREUR insertion absences: ' . $e->getMessage());
                    }
                }
            } else {
                log_message('warning', 'Condition échouée - empty: ' . (empty($etudiants_absents) ? 'oui' : 'non') . ', id_rattrapage: ' . ($id_rattrapage ? $id_rattrapage : 'null'));
            }

            log_message('info', '=== FIN CRÉATION ABSENCES ===');

            $db->transComplete();

            if ($db->transStatus() === false) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Erreur lors de la création du rattrapage'
                ]);
            }

            // === APPEL DE LA MÉTHODE PRIVÉE POUR L'EMAIL ===
            $postData = [
                'mail_enseignant' => $this->request->getPost('mail_enseignant'),
                'id_ressource' => $this->request->getPost('id_ressource'),
                'date_ds' => $this->request->getPost('date_ds'),
                'semestre' => $this->request->getPost('semestre'),
                'type_ds' => $this->request->getPost('type_ds'),
                'duree' => $this->request->getPost('duree')
            ];
            $emailResult = $this->envoieCreationEmail($postData, $absences ?? []);

            // Construction du message final
            $messageFlash = 'Rattrapage créé avec succès';
            if ($emailResult === 'sent') {
                $messageFlash .= '. Notification envoyée à l\'enseignant.';
            } elseif ($emailResult === 'error') {
                $messageFlash .= '. Attention : Erreur lors de l\'envoi du mail.';
            }
            // Si 'skipped', on n'ajoute rien au message pour ne pas polluer l'affichage

            return $this->response->setJSON([
                'success' => true,
                'message' => $messageFlash,
                'id_rattrapage' => $id_rattrapage
            ]);

        } catch (\Exception $e) {
            $db->transRollback();
            log_message('error', 'Erreur création rattrapage: ' . $e->getMessage());

            return $this->response->setJSON([
                'success' => false,
                'message' => 'Erreur lors de la création du rattrapage: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Envoie un email de notification à l'enseignant lors de la création d'un rattrapage
     */
    private function envoieCreationEmail(array $postData, array $absences): string
    {
        $notifModel = new NotificationModel();
        
        // 1. Vérification des préférences (Notif1 = Création - on suppose que c'est notif1 pour création)
        $preferences = $notifModel->where('email_ens', $postData['mail_enseignant'])->first();

        // Logique Opt-out : on envoie par défaut, sauf si explicitement désactivé (0)
        $doitEnvoyer = true;
        if ($preferences && isset($preferences['notif1'])) {
            $doitEnvoyer = ($preferences['notif1'] == 1);
        }

        if (!$doitEnvoyer) {
            log_message('info', 'Email création ignoré (notif1=0) pour ' . $postData['mail_enseignant']);
            return 'skipped';
        }

        try {
            // 2. Récupération du nom de la ressource
            $ressourceModel = new RessourceModel();
            $ressource = $ressourceModel->find($postData['id_ressource']);
            $nomRessource = $ressource ? $ressource['nom'] : 'Matière inconnue';

            // 3. Configuration de l'email
            $email = \Config\Services::email();
            $email->setMailType('html');
            $email->setFrom('no-reply@votre-etablissement.fr', 'Gestion Rattrapages');
            $email->setTo($postData['mail_enseignant']);
            $email->setSubject("Nouveau Rattrapage : " . $nomRessource);

            // 4. Construction du HTML
            $liEtudiants = "";
            if (!empty($absences)) {
                foreach ($absences as $abs) {
                    $liEtudiants .= "<li>" . esc($abs['email_etud']) . "</li>";
                }
            } else {
                $liEtudiants = "<li>Aucun étudiant absent sélectionné.</li>";
            }

            $message = "
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset='utf-8'>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 20px; }
                    .container { max-width: 600px; margin: 0 auto; background: #fff; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px; }
                    h2 { color: #16a34a; margin-top: 0; }
                    h3 { color: #374151; border-bottom: 2px solid #e5e7eb; padding-bottom: 5px; margin-top: 20px; }
                    ul { background-color: #f9fafb; padding: 15px 30px; border-radius: 5px; }
                    li { margin-bottom: 5px; }
                    .footer { margin-top: 30px; font-size: 0.9em; color: #6b7280; border-top: 1px solid #e5e7eb; padding-top: 10px; }
                </style>
            </head>
            <body>
                <div class='container'>
                    <h2>Nouveau rattrapage créé</h2>
                    <p>Un nouveau rattrapage dont vous êtes responsable vient d'être créé.</p>
                    
                    <h3>Informations du DS</h3>
                    <ul>
                        <li><strong>Ressource :</strong> " . esc($nomRessource) . "</li>
                        <li><strong>Date originale :</strong> " . esc($postData['date_ds']) . "</li>
                        <li><strong>Type :</strong> " . esc($postData['type_ds']) . "</li>
                        <li><strong>Durée :</strong> " . esc($postData['duree']) . " minutes</li>
                        <li><strong>Semestre :</strong> S" . esc($postData['semestre']) . "</li>
                    </ul>

                    <h3>Liste des étudiants absents</h3>
                    <ul>
                        " . $liEtudiants . "
                    </ul>
                    <p>Vous devrez planifier ce rattrapage dans les meilleurs délais.</p>
                    <div class='footer'><p>Cordialement,<br>La Direction</p></div>
                </div>
            </body>
            </html>";

            $email->setMessage($message);

            if ($email->send()) {
                log_message('info', 'Email de création envoyé à ' . $postData['mail_enseignant']);
                return 'sent';
            } else {
                log_message('error', 'Erreur envoi email création: ' . $email->printDebugger(['headers']));
                return 'error';
            }

        } catch (\Exception $e) {
            log_message('error', 'Exception email création: ' . $e->getMessage());
            return 'error';
        }
    }
}
