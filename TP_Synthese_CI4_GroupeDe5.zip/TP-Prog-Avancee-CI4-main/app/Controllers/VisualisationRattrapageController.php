<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class VisualisationRattrapageController extends BaseController {

    public function index($id_rattrapage) {
        $db = \Config\Database::connect();

        // 1. Récupérer les informations du rattrapage avec les jointures nécessaires
        // On joint Rattrapage, Ressource, Utilisateur (Enseignant), DS et Planification
        $builder = $db->table('rattrapage R');
        $builder->select('
            R.id_rattrapage as id,
            R.semestre,
            R.date as date_ds_original,
            Res.nom as ressource,
            U.nom as enseignant_nom,
            U.prenom as enseignant_prenom,
            U.email as enseignant_email,
            DS.type_ds as type,
            DS.duree,
            P.date as date_rattrapage,
            P.salle,
            P.type as statut_planification,
            P.commentaire as commentaire_planification
        ');

        $builder->join('ressource Res', 'Res.id_ressource = R.id_ressource', 'left');
        $builder->join('utilisateur U', 'U.email = R.mail_enseignant', 'left');
        // Jointure pour le DS (attention aux clés multiples selon votre schéma)
        // Ici on suppose que le DS est unique pour une ressource/semestre/date/prof
        // Si vous avez un id_ds dans Rattrapage, c'est mieux, sinon on fait une jointure large
        $builder->join('ds DS', 'DS.id_ressource = R.id_ressource AND DS.semestre = R.semestre AND DS.mail_enseignant = R.mail_enseignant AND DS.date = R.date', 'left');
        $builder->join('planification P', 'P.id_rattrapage = R.id_rattrapage', 'left');

        $builder->where('R.id_rattrapage', $id_rattrapage);

        $rattrapageData = $builder->get()->getRowArray();

        if (!$rattrapageData) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound("Rattrapage introuvable");
        }

        // 2. Déterminer l'état (Statut)
        $etat = 'En attente';
        if (!empty($rattrapageData['statut_planification'])) {
            switch($rattrapageData['statut_planification']) {
                case 'planifié':
                    $etat = 'Programmé';
                    break;
                case 'annulé':
                    $etat = 'Neutralisé';
                    break;
            }
        }

        // 3. Gestion de l'horaire
        $heure_debut = null;
        $heure_fin = null;
        $plage_horraire = null;
        
        // Extraire l'horaire du commentaire
        if (!empty($rattrapageData['commentaire_planification'])) {
            $plage_horraire = $this->extraireHoraireFromCommentaire($rattrapageData['commentaire_planification']);
            
            if ($plage_horraire) {
                $cleanHoraire = str_replace(' ', '', $plage_horraire);
                $parts = preg_split('/(-|à)/', $cleanHoraire);
                if (count($parts) >= 2) {
                    $heure_debut = $parts[0];
                    $heure_fin = $parts[1];
                }
            }
        }

        // 4. Récupérer la liste des étudiants pour ce rattrapage
        $builderEtud = $db->table('absence A');
        $builderEtud->select('E.nom, E.prenom, E.email, A.justifie');
        $builderEtud->join('eleve E', 'E.email = A.email_etud', 'left');
        $builderEtud->where('A.id_rattrapage', $id_rattrapage);

        $etudiants = $builderEtud->get()->getResultArray();

        // 5. Construire l'objet final pour la vue
        $rattrapage = [
            'id'                => $rattrapageData['id'],
            'ressource'         => $rattrapageData['ressource'],
            'semestre'          => 'S' . $rattrapageData['semestre'],
            'date_ds_original'  => $rattrapageData['date_ds_original'],
            'etat'              => $etat,
            'etudiants_count'   => count($etudiants),
            'etudiants'         => $etudiants,
            'type'              => $rattrapageData['type'],
            'duree'             => $rattrapageData['duree'],

            // Infos Enseignant
            'enseignant' => [
                'nom'    => $rattrapageData['enseignant_nom'],
                'prenom' => $rattrapageData['enseignant_prenom'],
                'email'  => $rattrapageData['enseignant_email']
            ],

            // Infos Planification
            'date_rattrapage'   => $rattrapageData['date_rattrapage'],
            'salle'             => $rattrapageData['salle'],
            'plage_horraire'    => $plage_horraire,
            'heure_debut'       => $heure_debut,
            'heure_fin'         => $heure_fin
        ];

        $data = [
            'active_page' => 'gestion_rattrapage',
            'role' => 'directeur', // Ou dynamique via session
            'rattrapage' => $rattrapage,
        ];

        return view('modeDirecteur/visualisation_rattrapage', $data);
    }

    private function extraireHoraireFromCommentaire($commentaire)
    {
        // Extraire l'horaire du commentaire s'il est au format "Horaire: HH:mm-HH:mm"
        if (preg_match('/Horaire:\s*(\d{2}:\d{2}-\d{2}:\d{2})/', $commentaire, $matches)) {
            return $matches[1];
        }
        
        return null;
    }
}