<?php
namespace App\Controllers\Connexion;
use App\Models\UtilisateurModel;
use App\Models\TokenVerificationModel;
use App\Controllers\BaseController;

class InscriptionController extends BaseController {
	public function index() {
		helper(['form']);

		$data = [
			'title' => 'SGRDS - Inscription',
		];

		return view('auth/register_view', $data);
	}

	public function inscritUtilisateur()
	{
		helper(['form']);
		$rules = [
			'nom'    => 'required|min_length[2]|max_length[50]',
			'prenom' => 'required|min_length[2]|max_length[50]',
			'email'  =>
				'required|min_length[4]|max_length[100]|valid_email',
			'mot_de_passe' => 'required|min_length[6]|max_length[50]',
			'confirmmdp' => 'matches[mot_de_passe]'
		];

		// Validation du formulaire
		if (! $this->validate($rules)) {
			return redirect()->back()->withInput()->with('msg', $this->validator);
		}

		// Récupération des données brutes nécessaires
		$email  = $this->request->getVar('email');
		$prenom = $this->request->getVar('prenom');

		// Création de l'utilisateur
		$this->creerCompteUtilisateur();

		// Génération et sauvegarde du token
		$token = $this->genererEtSauvegarderToken($email);

		// 4. Envoi de l'email
		if ($this->envoyerEmailActivation($email, $prenom, $token)) {
			return redirect()->to('auth/connexion')
							->with('success', 'Inscription réussie. Un email d\'activation vous a été envoyé.');
		} else {
			return redirect()->to('auth/connexion')
							->with('warning', 'Compte créé mais erreur lors de l\'envoi du mail. Veuillez contactez le support pour faire valider votre compte.');
		}
	}

	private function creerCompteUtilisateur()
	{
		$utilisateurModel = new UtilisateurModel();
		$nombreUtilisateurs = $utilisateurModel->countAll();

		if ($nombreUtilisateurs === 0) {
			$role = 'directeur';
		} else {
			$role = 'enseignant';
		}
		
		$userData = [
			'email'         => $this->request->getVar('email'),
			'mot_de_passe'  => password_hash($this->request->getVar('mot_de_passe'), PASSWORD_DEFAULT),
			'role'          => $role,
			'nom'           => $this->request->getVar('nom'),
			'prenom'        => $this->request->getVar('prenom'),
			'compte_valide' => false 
		];

		$utilisateurModel->save($userData);
	}

	private function genererEtSauvegarderToken(string $email): string
	{
		$tokenVerifModel = new TokenVerificationModel();
		
		$token = bin2hex(random_bytes(16));

		$tokenData = [
			'token_hash'        => $token,
			'email_utilisateur' => $email,
			'date_creation'     => date('Y-m-d H:i:s'),
			'date_expiration'   => date('Y-m-d H:i:s', strtotime('+100 years')),
			'type'              => 'activation'
		];

		$tokenVerifModel->createToken($tokenData);
		
		return $token;
	}

	private function envoyerEmailActivation(string $email, string $prenom, string $token): bool
	{
		$emailService = \Config\Services::email();
		
		$lienActivation = site_url("auth/inscription/$token");

		$emailService->setTo($email);
		$emailService->setFrom('maelous76@gmail.com', 'SGRDS Support');
		$emailService->setSubject('Activation de votre compte SGRDS');
		$emailService->setMailType('html');

		$message = '<!DOCTYPE html>
		<html>
		<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<title>Activation de votre compte SGRDS</title>
		</head>
		<body style="font-family: \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f9; margin: 0; padding: 0; -webkit-font-smoothing: antialiased;">
			<div style="max-width: 600px; margin: 40px auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);">
				<div style="background-color: #0f172a; padding: 32px 24px; text-align: center;">
					<h1 style="color: #ffffff; margin: 0; font-size: 28px; font-weight: 700; letter-spacing: -0.025em;">SGRDS</h1>
					<p style="color: #94a3b8; margin: 8px 0 0 0; font-size: 14px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.05em;">Gestion des Rattrapages</p>
				</div>
				<div style="padding: 40px 32px; color: #334155; line-height: 1.6;">
					<h2 style="color: #0f172a; margin-top: 0; font-size: 22px; font-weight: 600;">Bonjour ' . esc($prenom) . ',</h2>
					<p style="margin-top: 16px; font-size: 16px;">Bienvenue sur SGRDS ! Votre inscription a bien été enregistrée.</p>
					<p style="margin-top: 8px; font-size: 16px;">Pour finaliser la création de votre compte et accéder à la plateforme, veuillez confirmer votre adresse email en cliquant sur le bouton ci-dessous :</p>
					<div style="text-align: center; margin: 32px 0;">
						<a href="' . $lienActivation . '" style="background-color: #2563eb; color: #ffffff; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px; display: inline-block; box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.2);">Activer mon compte</a>
					</div>
					<p style="font-size: 14px; color: #64748b; margin-top: 24px;">Si le bouton ne fonctionne pas, vous pouvez copier et coller le lien suivant dans votre navigateur :</p>
					<p style="font-size: 12px; color: #2563eb; word-break: break-all; margin-top: 8px;">' . $lienActivation . '</p>
				</div>
				<div style="background-color: #f8fafc; padding: 24px; text-align: center; border-top: 1px solid #e2e8f0;">
					<p style="color: #64748b; font-size: 12px; margin: 0;">&copy; ' . date('Y') . ' SGRDS - IUT du Havre. Tous droits réservés.</p>
					<p style="color: #94a3b8; font-size: 12px; margin: 8px 0 0 0;">Ceci est un email automatique, merci de ne pas y répondre.</p>
				</div>
			</div>
		</body>
		</html>';

		$emailService->setMessage($message);

		if ($emailService->send()) {
			return true;
		} else {
			return false;
		}
	}

	public function activerCompte($token)
	{
		$tokenModel = new TokenVerificationModel();
		$utilisateurModel = new UtilisateurModel();

		// On cherche le token dans la base
		// On vérifie aussi que c'est bien un token d'activation
		$tokenData = $tokenModel->where('token_hash', $token)
								->where('type', 'activation')
								->first();

		// Si le token n'existe pas ou est incorrect
		if (!$tokenData) {
			return redirect()->to('auth/connexion')
							->with('error', 'Lien d\'activation invalide.');
		}

		// Vérification de l'expiration du token
		if (date('Y-m-d H:i:s') > $tokenData['date_expiration']) {
			return redirect()->to('auth/connexion')
							->with('error', 'Ce lien d\'activation a expiré.');
		}

		$email = $tokenData['email_utilisateur'];
		$utilisateur = $utilisateurModel->where('email', $email)->first();

		if ($utilisateur) {
			// On active le compte (mise à jour de compte_valide)
			$utilisateurModel->update($utilisateur['email'], ['compte_valide' => true]); 

			// On supprime le token (il ne doit servir qu'une fois)
			$tokenModel->delete($tokenData['id']);

			return redirect()->to('auth/connexion')
							->with('success', 'Votre compte a été activé avec succès !');
		} else {
			// Cas rare où le token existe mais l'utilisateur a été supprimé entre temps
			return redirect()->to('auth/connexion')
							->with('error', 'Utilisateur introuvable.');
		}
	}
}
