<?php
namespace App\Controllers\Connexion;

use CodeIgniter\Controller;
use App\Controllers\BaseController;
use App\Models\UtilisateurModel;
use App\Models\TokenVerificationModel;

class MdpOublieController extends BaseController 
{
    public function index() 
    {
        helper(['form']);

        $data = [
            'title' => 'SGRDS - Mot de passe oublié',
        ];

        return view('auth/forgot_password_view', $data);
    }

    public function envoieToken()
    {
        helper(['form']);

        $rules = [
            'email' => 'required|valid_email'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Veuillez entrer une adresse email valide.');
        }

        $email = $this->request->getVar('email');
        $utilisateurModel = new UtilisateurModel();

        // Vérifier si l'utilisateur existe
        $utilisateur = $utilisateurModel->where('email', $email)->first();

        if (!$utilisateur) {
            return redirect()->back()->withInput()->with('error', 'Aucun compte trouvé avec cette adresse email.');
        }

        // Générer et sauvegarder le token
        $token = $this->genererEtSauvegarderToken($email);

        // Envoyer l'email
        if ($this->envoyerEmailReset($email, $token)) {
            return redirect()->to('auth/connexion')
                             ->with('success', 'Si ce compte existe, un email de réinitialisation a été envoyé.');
        } else {
            return redirect()->back()->withInput()
                             ->with('error', 'Erreur lors de l\'envoi de l\'email. Veuillez réessayer.');
        }
    }

    private function genererEtSauvegarderToken(string $email): string
    {
        $tokenVerifModel = new TokenVerificationModel();

        $token = bin2hex(random_bytes(16)); 

        $tokenData = [
            'token_hash'        => $token,
            'email_utilisateur' => $email,
            'date_creation'     => date('Y-m-d H:i:s'),
            'date_expiration'   => date('Y-m-d H:i:s', strtotime('+1 hour')), // Expire dans 1h
            'type'              => 'changement_mdp'
        ];

        // On utilise ta méthode createToken du model
        $tokenVerifModel->createToken($tokenData);
        
        return $token;
    }

    private function envoyerEmailReset(string $email, string $token): bool
    {
        $emailService = \Config\Services::email();

        $lienReset = site_url("auth/mdpchangement/$token");

        $emailService->setTo($email);
        $emailService->setFrom('maelous76@gmail.com', 'SGRDS Support');
        $emailService->setSubject('Réinitialisation de votre mot de passe');
        $emailService->setMailType('html');

        $message = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation de mot de passe</title>
</head>
<body style="font-family: \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f9; margin: 0; padding: 0; -webkit-font-smoothing: antialiased;">
    <div style="max-width: 600px; margin: 40px auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);">
        <div style="background-color: #0f172a; padding: 32px 24px; text-align: center;">
            <h1 style="color: #ffffff; margin: 0; font-size: 28px; font-weight: 700; letter-spacing: -0.025em;">SGRDS</h1>
            <p style="color: #94a3b8; margin: 8px 0 0 0; font-size: 14px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.05em;">Gestion des Rattrapages</p>
        </div>
        <div style="padding: 40px 32px; color: #334155; line-height: 1.6;">
            <h2 style="color: #0f172a; margin-top: 0; font-size: 22px; font-weight: 600;">Bonjour,</h2>
            <p style="margin-top: 16px; font-size: 16px;">Une demande de réinitialisation de mot de passe a été effectuée pour votre compte SGRDS.</p>
            <p style="margin-top: 8px; font-size: 16px;">Si vous êtes à l\'origine de cette demande, cliquez sur le bouton ci-dessous pour définir un nouveau mot de passe :</p>
            <div style="text-align: center; margin: 32px 0;">
                <a href="' . $lienReset . '" style="background-color: #2563eb; color: #ffffff; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px; display: inline-block; box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.2);">Réinitialiser mon mot de passe</a>
            </div>
            <p style="font-size: 14px; color: #64748b; margin-top: 24px;">Ce lien est valide pendant <strong>1 heure</strong>.</p>
            <p style="font-size: 14px; color: #64748b; margin-top: 8px;">Si vous n\'avez pas demandé cette réinitialisation, vous pouvez ignorer cet email en toute sécurité.</p>
        </div>
        <div style="background-color: #f8fafc; padding: 24px; text-align: center; border-top: 1px solid #e2e8f0;">
            <p style="color: #64748b; font-size: 12px; margin: 0;">&copy; ' . date('Y') . ' SGRDS - IUT du Havre. Tous droits réservés.</p>
            <p style="color: #94a3b8; font-size: 12px; margin: 8px 0 0 0;">Ceci est un email automatique, merci de ne pas y répondre.</p>
        </div>
    </div>
</body>
</html>';

        $emailService->setMessage($message);

        return $emailService->send();
    }

    public function afficherFormulaireReset($token)
    {
        $tokenModel = new TokenVerificationModel();
        
        // 1. Vérification de l'existence et du type du token
        $tokenData = $tokenModel->where('token_hash', $token)
                                ->where('type', 'changement_mdp') // Ton nouveau type
                                ->first();

        // 2. Gestion des erreurs de token
        if (!$tokenData) {
            return redirect()->to('auth/connexion')->with('error', 'Ce lien est invalide.');
        }

        if (date('Y-m-d H:i:s') > $tokenData['date_expiration']) {
            return redirect()->to('auth/connexion')->with('error', 'Ce lien a expiré. Veuillez refaire une demande.');
        }

        // 3. Tout est bon, on affiche la vue
        // On passe le token à la vue car on en aura besoin pour le formulaire POST
        $data = [
            'title' => 'SGRDS - Nouveau mot de passe',
            'token' => $token 
        ];

        return view('auth/reset_password_view', $data);
    }

    public function sauvegarderNouveauMdp()
    {
        helper(['form']);
        
        // Validation des champs
        $rules = [
            'token'        => 'required',
            'mot_de_passe' => 'required|min_length[6]|max_length[50]',
            'confirmmdp'   => 'matches[mot_de_passe]'
        ];

        if (!$this->validate($rules)) {
            // S'il y a erreur, on redirige vers le formulaire (on a besoin du token pour reconstruire l'URL)
            $token = $this->request->getPost('token');
            return redirect()->to("auth/mdpoublie/$token")
                             ->withInput()
                             ->with('error', 'Veuillez vérifier les mots de passe saisis.');
        }

        $token      = $this->request->getPost('token');
        $nouveauMdp = $this->request->getPost('mot_de_passe');
        
        $tokenModel = new TokenVerificationModel();
        $utilisateurModel = new UtilisateurModel();

        // Re-vérification de sécurité du token
        $tokenData = $tokenModel->where('token_hash', $token)
                                ->where('type', 'changement_mdp')
                                ->first();

        if ($tokenData) {
            $email = $tokenData['email_utilisateur'];

            $utilisateurModel->update($email, [
                'mot_de_passe' => password_hash($nouveauMdp, PASSWORD_DEFAULT)
            ]);

            // Suppression du token
            $tokenModel->where('token_hash', $token)->delete();
            return redirect()->to('auth/connexion')
                             ->with('success', 'Votre mot de passe a été modifié avec succès. Connectez-vous.');
        } else {
            return redirect()->to('auth/connexion')->with('error', 'Erreur critique : Token introuvable lors de la sauvegarde.');
        }
    }
}
