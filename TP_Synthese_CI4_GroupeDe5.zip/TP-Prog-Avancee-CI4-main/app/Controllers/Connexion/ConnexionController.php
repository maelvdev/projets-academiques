<?php
namespace App\Controllers\Connexion;
use App\Models\UtilisateurModel;
use App\Controllers\BaseController;

class ConnexionController extends BaseController {
    public function index() {
        helper(['form']);

        $data = [
            'title' => 'SGRDS - Connexion',
        ];

        return view('auth/login_view', $data);
    }

    public function connexionAuth() {
        $session = session();
        $utilisateurModel = new UtilisateurModel();
        $email = $this->request->getVar('email');
        $mdp = $this->request->getVar('mot_de_passe');
        $nom = $this->request->getVar('nom');
        $prenom = $this->request->getVar('prenom');
        $data = $utilisateurModel->where('email', $email)->first();
        if ($data) {
            $pass = $data['mot_de_passe'];
            $authenticatePassword = password_verify($mdp, $pass);
            if ($authenticatePassword) {
                $ses_data = [
                    'nom' => $data['nom'],
                    'prenom' => $data['prenom'],
                    'email' => $data['email'],
                    'role' => $data['role'],
                    'compte_valide' => $data['compte_valide'],
                    'isLoggedIn' => true,
                ];
                $session->set($ses_data);
                return redirect()->to('/accueil');
            } else {
                return redirect()->back()->with('error', 'Mauvais mot de passe');
            }
        } else {
            return redirect()->back()->with('error', 'Email inexistant');
        }
    }

    public function logout() {
        $session = session();
        $session->destroy();
        return redirect()->to('/auth/connexion');
    }
}
