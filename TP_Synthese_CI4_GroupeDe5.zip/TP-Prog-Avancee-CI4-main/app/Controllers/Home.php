<?php

namespace App\Controllers;

class Home extends BaseController {
    public function index(): string {
        // TODO: Récupérer le vrai rôle depuis la session
        $role = 'Directeur';

        $data = [
            'active_page' => 'dashboard',
            'role' => $role,
        ];

        return view('modeDirecteur/dashboard', $data);
    }
}
