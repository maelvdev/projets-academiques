<?php
namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\EtudiantModel;

class EtudiantsController extends BaseController
{
    /**
     * Convertit le semestre de format S1-S6 vers 1-6
     */
    private function convertSemestre($semestre)
    {
        if (empty($semestre)) return null;
        // Extraire le chiffre de S1, S2, etc.
        return (int) str_replace('S', '', $semestre);
    }

    public function index()
    {
        $q = $this->request->getGet('q');
        $semestre = $this->request->getGet('semestre');
        
        // Convert semestre from 'S1'-'S6' format to integer 1-6 for database query
        $semestreInt = null;
        if (!empty($semestre)) {
            $semestreInt = $this->convertSemestre($semestre);
        }
        
        $page = max(1, (int) ($this->request->getGet('page') ?? 1));

        $perPage = 20;
        $offset = ($page - 1) * $perPage;

        $model = new EtudiantModel();

        // Récupérer items paginés
        $eleves = $model->findWithFilters([
            'q' => $q,
            'semestre' => $semestreInt,
            'limit' => $perPage,
            'offset' => $offset,
        ]);

        // Count total efficiently
        $total = $model->countWithFilters([
            'q' => $q,
            'semestre' => $semestreInt
        ]);

        return view('etudiants', [
            'eleves' => $eleves,
            'filters' => ['q' => $q, 'semestre' => $semestre],
            'page' => $page,
            'perPage' => $perPage,
            'total' => $total,
            'active_page' => 'gestion_etudiants',
            'role' => 'Directeur',
        ]);
    }

    public function create()
    {
        $validation = \Config\Services::validation();
        
        $validation->setRules([
            'email' => 'required|valid_email|is_unique[eleve.email]',
            'nom' => 'required|min_length[2]|max_length[100]',
            'prenom' => 'required|min_length[2]|max_length[100]',
            'semestre' => 'required|in_list[S1,S2,S3,S4,S5,S6]',
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $model = new EtudiantModel();
        
        $data = [
            'email' => $this->request->getPost('email'),
            'nom' => $this->request->getPost('nom'),
            'prenom' => $this->request->getPost('prenom'),
            'semestre' => $this->convertSemestre($this->request->getPost('semestre')),
        ];

        // Debug: vérifier les données reçues
        log_message('debug', 'Données POST reçues: ' . json_encode($this->request->getPost()));
        log_message('debug', 'Données à insérer: ' . json_encode($data));

        try {
            $result = $model->insert($data);
            
            if ($result === false) {
                // Récupérer les erreurs du modèle
                $errors = $model->errors();
                log_message('error', 'Erreur insertion étudiant: ' . json_encode($errors));
                log_message('error', 'Données tentées: ' . json_encode($data));
                
                $errorMsg = !empty($errors) ? implode(', ', $errors) : 'Erreur inconnue lors de l\'insertion';
                return redirect()->back()->withInput()->with('error', 'Erreur: ' . $errorMsg);
            }
            
            return redirect()->to('etudiants')->with('success', 'Étudiant ajouté avec succès');
            
        } catch (\Exception $e) {
            log_message('error', 'Exception lors de l\'ajout d\'étudiant: ' . $e->getMessage());
            log_message('error', 'Trace: ' . $e->getTraceAsString());
            return redirect()->back()->withInput()->with('error', 'Erreur: ' . $e->getMessage());
        }
    }

    public function update()
    {
        $validation = \Config\Services::validation();
        
        $originalEmail = $this->request->getPost('original_email');
        
        $validation->setRules([
            'email' => "required|valid_email|is_unique[eleve.email,email,{$originalEmail}]",
            'nom' => 'required|min_length[2]|max_length[100]',
            'prenom' => 'required|min_length[2]|max_length[100]',
            'semestre' => 'required|in_list[S1,S2,S3,S4,S5,S6]',
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors())
                ->with('edit_email', $originalEmail);
        }

        $model = new EtudiantModel();
        
        try {
            $newEmail = $this->request->getPost('email');
            
            // Debug
            log_message('debug', 'Modification - données POST: ' . json_encode($this->request->getPost()));
            
            // Si l'email a changé, on doit supprimer l'ancien et créer un nouveau
            if ($originalEmail !== $newEmail) {
                $student = $model->where('email', $originalEmail)->first();
                if (!$student) {
                    return redirect()->back()->with('error', 'Étudiant non trouvé');
                }
                
                // Supprimer l'ancien
                $model->delete($originalEmail);
                
                // Créer le nouveau
                $data = [
                    'email' => $newEmail,
                    'nom' => $this->request->getPost('nom'),
                    'prenom' => $this->request->getPost('prenom'),
                    'semestre' => $this->convertSemestre($this->request->getPost('semestre')),
                ];
                
                $result = $model->insert($data);
            } else {
                // Mise à jour simple
                $data = [
                    'nom' => $this->request->getPost('nom'),
                    'prenom' => $this->request->getPost('prenom'),
                    'semestre' => $this->convertSemestre($this->request->getPost('semestre')),
                ];
                
                $result = $model->update($originalEmail, $data);
            }
            
            if ($result === false) {
                $errors = $model->errors();
                log_message('error', 'Erreur mise à jour étudiant: ' . json_encode($errors));
                return redirect()->back()->with('error', 'Erreur lors de la mise à jour');
            }
            
            return redirect()->to('etudiants')->with('success', 'Étudiant modifié avec succès');
            
        } catch (\Exception $e) {
            log_message('error', 'Exception lors de la modification d\'étudiant: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Erreur: ' . $e->getMessage());
        }
    }

    public function delete()
    {
        $email = $this->request->getPost('email');
        
        if (empty($email)) {
            return redirect()->back()->with('error', 'Email manquant');
        }
        
        $model = new EtudiantModel();
        
        try {
            if ($model->delete($email)) {
                return redirect()->to('etudiants')->with('success', 'Étudiant supprimé avec succès');
            } else {
                return redirect()->back()->with('error', 'Erreur lors de la suppression');
            }
        } catch (\Exception $e) {
            log_message('error', 'Exception lors de la suppression d\'étudiant: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Erreur: ' . $e->getMessage());
        }
    }
}
