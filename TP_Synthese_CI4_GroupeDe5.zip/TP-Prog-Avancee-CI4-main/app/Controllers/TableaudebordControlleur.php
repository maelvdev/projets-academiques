<?php

namespace App\Controllers;

use CodeIgniter\Database\Query;
use App\Models\RattrapageModel;

class TableaudebordControlleur extends BaseController
{
    protected $rattrapageModel;
    protected $db;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
        // On instancie le modèle ici pour l'utiliser partout
        $this->rattrapageModel = new RattrapageModel();
    }

    public function index()
    {
        helper(['form']);
        $session = session();

        // 1. Récupération et Sécurisation
        $role = trim((string)$session->get('role'));
        $emailUtilisateur = $session->get('email');
        $nom = $session->get('nom');
        $prenom = $session->get('prenom');

        if (!$role || !$emailUtilisateur) {
            return redirect()->to('/auth/connexion')->with('error', 'Veuillez vous connecter.');
        }

        // 2. Données de base communes
        $data = [
            'role' => $role,
            'nom' => $nom,
            'prenom' => $prenom,
            'active_page' => 'dashboard'
        ];

        // 3. Logique conditionnelle selon le rôle
        // On fusionne les données spécifiques (Directeur ou Enseignant) dans $data
        if (strcasecmp($role, 'directeur') === 0) {
            $dashboardData = $this->getDashboardDirecteur();
        } else {
            $dashboardData = $this->getDashboardEnseignant($emailUtilisateur);
        }

        $data = array_merge($data, $dashboardData);

        return view('accueil', $data);
    }

    /**
     * Récupère les données pour le tableau de bord Directeur
     */
    private function getDashboardDirecteur()
    {
        $rattrapagesRecents = $this->rattrapageModel->getRattrapagesRecents(3);

        $stats = $this->getStatsRattrapages(); 

        $taches = $this->getTachesAFaire();

        return [
            'stats' => $stats,
            'rattrapages_recents' => $rattrapagesRecents,
            'taches' => $taches
        ];
    }

    /**
     * Récupère les données pour le tableau de bord Enseignant
     */
    private function getDashboardEnseignant($email)
    {
        $mesRattrapages = $this->rattrapageModel->getMesRattrapages($email, 3);

        log_message("error", "Email utilisé : " . $email);
        log_message("error", "Résultat Rattrapages : " . print_r($mesRattrapages, true));


        $stats = $this->getStatsEnseignant($email);
        $prochainsEvenements = $this->getProchainsEvenements($email);

        return [
            'stats' => $stats,
            'mes_rattrapages' => $mesRattrapages,
            'prochains_evenements' => $prochainsEvenements
        ];
    }

    /**
     * Statistiques globales pour le Directeur
     */
    private function getStatsRattrapages()
    {
        // Rattrapages en attente (ceux qui ont une planification de type 'en attente' ou sans planification)
        $enCours = $this->db->query("
            SELECT COUNT(DISTINCT r.id_rattrapage) as total
            FROM rattrapage r
            LEFT JOIN planification p ON r.id_rattrapage = p.id_rattrapage
            WHERE p.type = 'en attente' OR p.id_rattrapage IS NULL
        ")->getRow()->total ?? 0;

        // Rattrapages programmés/planifiés
        $programmes = $this->db->query("
            SELECT COUNT(DISTINCT r.id_rattrapage) as total
            FROM rattrapage r
            INNER JOIN planification p ON r.id_rattrapage = p.id_rattrapage
            WHERE p.type = 'planifié'
        ")->getRow()->total ?? 0;

        // Rattrapages neutralisés/annulés
        $neutralises = $this->db->query("
            SELECT COUNT(DISTINCT r.id_rattrapage) as total
            FROM rattrapage r
            LEFT JOIN planification p ON r.id_rattrapage = p.id_rattrapage
            WHERE p.type = 'annulé'
        ")->getRow()->total ?? 0;

        return [
            'en_cours' => $enCours,
            'programmes' => $programmes,
            'neutralises' => $neutralises
        ];
    }

    /**
     * Récupère les tâches à faire
     */
    private function getTachesAFaire()
    {
        // Rattrapages sans planification
        $rattrapagesSansPlanif = $this->db->query("
            SELECT COUNT(*) as total
            FROM rattrapage r
            LEFT JOIN planification p ON r.id_rattrapage = p.id_rattrapage
            WHERE p.id_rattrapage IS NULL
        ")->getRow()->total ?? 0;

        // DS sans rattrapage créé pour les absents
        $dsSansRattrapage = $this->db->query("
            SELECT COUNT(DISTINCT d.id_ds) as total
            FROM ds d
            INNER JOIN absence a ON a.id_rattrapage IS NULL
            WHERE d.date < CURRENT_DATE
        ")->getRow()->total ?? 0;

        // Rattrapages programmés sans salle
        $sansSalle = $this->db->query("
            SELECT COUNT(*) as total
            FROM planification
            WHERE salle IS NULL OR salle = ''
        ")->getRow()->total ?? 0;

        return [
            'rattrapages_a_confirmer' => $rattrapagesSansPlanif,
            'examens_manquants' => $dsSansRattrapage,
            'salles_a_reserver' => $sansSalle
        ];
    }

    /**
     * Statistiques pour un enseignant
     */
    private function getStatsEnseignant($email)
    {
        // Rattrapages en attente
        $enAttente = $this->db->query("
            SELECT COUNT(*) as total
            FROM rattrapage r
            LEFT JOIN planification p ON r.id_rattrapage = p.id_rattrapage
            WHERE r.mail_enseignant = ? AND (p.id_rattrapage IS NULL OR p.type = 'En attente')
        ", [$email])->getRow()->total ?? 0;

        // Rattrapages planifiés
        $planifies = $this->db->query("
            SELECT COUNT(*) as total
            FROM rattrapage r
            INNER JOIN planification p ON r.id_rattrapage = p.id_rattrapage
            WHERE r.mail_enseignant = ? AND p.type = 'planifié'
        ", [$email])->getRow()->total ?? 0;

        // Total étudiants concernés
        $totalEtudiants = $this->db->query("
            SELECT COUNT(DISTINCT a.email_etud) as total
            FROM rattrapage r
            INNER JOIN absence a ON r.id_rattrapage = a.id_rattrapage
            WHERE r.mail_enseignant = ?
        ", [$email])->getRow()->total ?? 0;

        // Ressources enseignées
        $mesRessources = $this->db->query("
            SELECT COUNT(DISTINCT res.nom) as total
            FROM rattrapage r
            LEFT JOIN ressource res ON r.id_ressource = res.id_ressource
            WHERE r.mail_enseignant = ?
        ", [$email])->getRow()->total ?? 0;

        return [
            'en_attente' => $enAttente,
            'planifies' => $planifies,
            'total_etudiants' => $totalEtudiants,
            'mes_ressources' => $mesRessources
        ];
    }

    /**
     * Récupère les prochains événements d'un enseignant
     */
    private function getProchainsEvenements($email, $limit = 2)
    {
        $query = "
            SELECT 
                res.nom AS ressource,
                p.date,
                p.salle,
                r.semestre,
                p.heure_debut, -- On récupère l'heure de début
                p.heure_fin,    -- On récupère l'heure de fin
				p.plage_horraire
            FROM rattrapage r
            LEFT JOIN ressource res ON r.id_ressource = res.id_ressource
            INNER JOIN planification p ON r.id_rattrapage = p.id_rattrapage
            WHERE r.mail_enseignant = ? 
                AND p.date >= CURRENT_DATE
                AND p.type = 'planifié'
            ORDER BY p.date ASC, p.heure_debut ASC -- Tri par date PUIS par heure
            LIMIT ?
        ";

        return $this->db->query($query, [$email, $limit])->getResultArray();
    }
}
