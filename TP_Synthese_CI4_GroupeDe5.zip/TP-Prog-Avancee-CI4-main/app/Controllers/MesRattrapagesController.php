<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class MesRattrapagesController extends BaseController {

    public function index() {
        $email_enseignant = session()->get('email');

        if (!$email_enseignant) {
            return redirect()->to('/login');
        }

        $db = \Config\Database::connect();
        $builder = $db->table('rattrapage R');

        $builder->select('
            P.commentaire as commentaire_planification,
            R.id_rattrapage as id,
            R.semestre,
            R.date as date_ds_original,
            Res.nom as ressource,
            P.date as date_rattrapage,
            P.salle,
            P.type as statut_planification,
            COUNT(DISTINCT absence.email_etud) as etudiants_count
        ');

        $builder->join('ressource Res', 'Res.id_ressource = R.id_ressource', 'left');
        $builder->join('planification P', 'P.id_rattrapage = R.id_rattrapage', 'left');
        $builder->join('absence', 'absence.id_rattrapage = R.id_rattrapage', 'left');

        $builder->where('R.mail_enseignant', $email_enseignant);
        
        $builder->groupBy('R.id_rattrapage, R.semestre, R.date, Res.nom, P.date, P.salle, P.type, P.commentaire');
        $builder->orderBy('R.date', 'DESC');

        $results = $builder->get()->getResultArray();

        $rattrapages = [];
        foreach ($results as $row) {

            $etat = 'En attente';

            if (!empty($row['statut_planification'])) {
                switch($row['statut_planification']) {
                    case 'planifié':
                        $etat = 'Programmé';
                        break;
                    case 'annulé':
                        $etat = 'Neutralisé';
                        break;
                }
            }

            $heure_debut = null;
            $heure_fin = null;
            $plage_horraire = null;

            // Extraire l'horaire du commentaire
            if (!empty($row['commentaire_planification'])) {
                $plage_horraire = $this->extraireHoraireFromCommentaire($row['commentaire_planification']);
                
                if ($plage_horraire) {
                    $cleanHoraire = str_replace(' ', '', $plage_horraire);
                    $parts = preg_split('/(-|à)/', $cleanHoraire);
                    if (count($parts) >= 2) {
                        $heure_debut = $parts[0];
                        $heure_fin = $parts[1];
                    }
                }
            }

            $rattrapages[] = [
                'id'                => $row['id'],
                'ressource'         => $row['ressource'],
                'semestre'          => 'S' . $row['semestre'],
                'date_ds_original'  => $row['date_ds_original'],
                'etat'              => $etat,
                'etudiants_count'   => $row['etudiants_count'],

                'date_rattrapage'   => $row['date_rattrapage'],
                'salle'             => $row['salle'],

                // C'est ici qu'on passe la plage horaire à la vue
                'plage_horraire'    => $plage_horraire,
                'heure_debut'       => $heure_debut,
                'heure_fin'         => $heure_fin
            ];
        }

        $data = [
            'title' => 'Mes Rattrapages',
            'active_page' => 'mes_rattrapages',
            'rattrapages' => $rattrapages
        ];

        return view('modeEnseignant/mes_rattrapages', $data);
    }

    private function extraireHoraireFromCommentaire($commentaire)
    {
        // Extraire l'horaire du commentaire s'il est au format "Horaire: HH:mm-HH:mm"
        if (preg_match('/Horaire:\s*(\d{2}:\d{2}-\d{2}:\d{2})/', $commentaire, $matches)) {
            return $matches[1];
        }
        
        return null;
    }
}