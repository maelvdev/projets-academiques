<?php

namespace App\Controllers;

use App\Models\RattrapageModel;
use App\Models\AbsenceModel;
use App\Models\UtilisateurModel;
use App\Models\RessourceModel;
use App\Models\NotificationModel;
use App\Models\DSModel;
use App\Models\EtudiantModel;

class ModifierRattrapageController extends BaseController {

    public function index($id_rattrapage): string {
        $rattrapageModel = new RattrapageModel();
        $absenceModel = new AbsenceModel();
        $utilisateurModel = new UtilisateurModel();
        $ressourceModel = new RessourceModel();
        $dsModel = new DSModel();
        
        // Récupérer le rattrapage avec ses détails
        $db = \Config\Database::connect();
        $builder = $db->table('rattrapage R');
        $builder->select('
            R.id_rattrapage,
            R.date,
            R.semestre,
            R.mail_enseignant,
            R.id_ressource,
            Res.nom as ressource_nom,
            U.nom as enseignant_nom,
            U.prenom as enseignant_prenom,
            DS.id_ds,
            DS.date as date_ds,
            DS.type_ds,
            DS.duree,
            P.date as date_planification,
            P.type as type_planification,
            P.salle as salle_planification,
            P.commentaire as commentaire_planification
        ');
        $builder->join('ressource Res', 'Res.id_ressource = R.id_ressource', 'left');
        $builder->join('utilisateur U', 'U.email = R.mail_enseignant', 'left');
        $builder->join('ds DS', 'DS.id_ressource = R.id_ressource AND DS.semestre = R.semestre AND DS.mail_enseignant = R.mail_enseignant AND DS.date = R.date', 'left');
        $builder->join('planification P', 'P.id_rattrapage = R.id_rattrapage', 'left');
        $builder->where('R.id_rattrapage', $id_rattrapage);
        
        $rattrapage = $builder->get()->getRowArray();
        
        // Debug: vérifier les données récupérées
        log_message('info', 'Rattrapage récupéré: ' . json_encode($rattrapage));
        
        if (!$rattrapage) {
            return redirect()->to('/gestion_rattrapage')->with('error', 'Rattrapage introuvable');
        }
        
        // Récupérer les étudiants absents
        $absenceBuilder = $db->table('absence A');
        $absenceBuilder->select('E.email, E.nom, E.prenom, E.groupe, E.semestre as semestre_etudiant, A.justifie');
        $absenceBuilder->join('eleve E', 'E.email = A.email_etud', 'left');
        $absenceBuilder->where('A.id_rattrapage', $id_rattrapage);
        $etudiants = $absenceBuilder->get()->getResultArray();
        
        // Déterminer l'état
        $etat = 'En attente';
        if ($rattrapage['date_planification']) {
            $etat = 'Programmé';
        }
        
        // Récupérer les enseignants selon le rôle
        $role = session()->get('role') ?? 'enseignant';
        $email_utilisateur = session()->get('email');
        
        if (strtolower($role) === 'directeur') {
            // Le directeur voit tous les enseignants ET tous les directeurs
            $enseignants = $utilisateurModel->getUtilisateursByRole('enseignant');
            $directeurs = $utilisateurModel->getUtilisateursByRole('directeur');
            $enseignants = array_merge($enseignants, $directeurs);
        } else {
            // L'enseignant ne voit que lui-même
            $enseignants = [$utilisateurModel->find($email_utilisateur)];
        }
        
        $data = [
            'title' => "SGRDS - Modification d'un rattrapage",
            'rattrapage' => [
                'id' => $rattrapage['id_rattrapage'],
                'id_rattrapage' => $rattrapage['id_rattrapage'],
                'ressource' => $rattrapage['ressource_nom'],
                'id_ressource' => $rattrapage['id_ressource'],
                'semestre' => $rattrapage['semestre'],
                'date_ds_original' => $rattrapage['date_ds'],
                'type_ds' => $rattrapage['type_ds'],
                'duree' => $rattrapage['duree'],
                'mail_enseignant' => $rattrapage['mail_enseignant'],
                'etat' => $etat,
                'etudiants' => $etudiants,
                'date_rattrapage' => $rattrapage['date_planification'],
                'type_planification' => $rattrapage['type_planification'] ?? 'en attente',
                'salle' => $rattrapage['salle_planification'],
                'commentaire' => $rattrapage['commentaire_planification'],
            ],
            'enseignants' => $enseignants,
            'active_page' => 'gestion_rattrapage',
            'role' => $role,
        ];

        return view('modeDirecteur/modification_rattrapage', $data);
    }

    public function update($id)
    {
        log_message('info', '=== DÉBUT UPDATE RATTRAPAGE === ID: ' . $id);
        
        $validation = \Config\Services::validation();
        $validation->setRules([
            'semestre' => 'required|integer|greater_than[0]|less_than[7]',
            'id_ressource' => 'required|integer',
            'mail_enseignant' => 'required|valid_email',
            'date_ds_original' => 'required|valid_date',
            'type_ds' => 'required|in_list[DS Table,DS Machine]',
            'duree' => 'required|integer|greater_than[0]'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $db = \Config\Database::connect();
        $db->transStart();

        try {
            $rattrapageModel = new RattrapageModel();
            $dsModel = new DSModel();
            $absenceModel = new AbsenceModel();
            
            // Vérification existence
            $rattrapage = $rattrapageModel->find($id);
            if (!$rattrapage) {
                return redirect()->to('/gestion_rattrapage')->with('error', 'Rattrapage introuvable');
            }

            $postData = $this->request->getPost();

            // 1. Mise à jour du DS
            $db->table('ds')
                ->where('id_ressource', $rattrapage['id_ressource'])
                ->where('semestre', $rattrapage['semestre'])
                ->where('mail_enseignant', $rattrapage['mail_enseignant'])
                ->where('date', $rattrapage['date'])
                ->update([
                    'date' => $postData['date_ds_original'],
                    'id_ressource' => $postData['id_ressource'],
                    'semestre' => $postData['semestre'],
                    'mail_enseignant' => $postData['mail_enseignant'],
                    'type_ds' => $postData['type_ds'],
                    'duree' => $postData['duree']
                ]);

            // 2. Mise à jour du Rattrapage
            $rattrapageModel->update($id, [
                'mail_enseignant' => $postData['mail_enseignant'],
                'id_ressource' => $postData['id_ressource'],
                'date' => $postData['date_ds_original'],
                'semestre' => $postData['semestre']
            ]);

            // 3. Mise à jour des Absences
            $absenceModel->where('id_rattrapage', $id)->delete();

            $etudiants = $postData['etudiants'] ?? [];
            $absences = [];
            
            if (!empty($etudiants)) {
                foreach ($etudiants as $etudiant) {
                    if (empty($etudiant['email'])) continue;
                    $absences[] = [
                        'email_etud' => $etudiant['email'],
                        'id_rattrapage' => $id,
                        'justifie' => isset($etudiant['justifie']) ? (int)$etudiant['justifie'] : 0
                    ];
                }
                if (!empty($absences)) {
                    $absenceModel->insertMultipleAbsences($absences);
                }
            }

            $db->transComplete();

            if ($db->transStatus() === false) {
                return redirect()->back()->withInput()->with('error', 'Erreur lors de la mise à jour (BDD).');
            }

            // === APPEL DE LA MÉTHODE PRIVÉE POUR L'EMAIL ===
            // On a sorti toute la logique email ici
            $emailResult = $this->envoieModificationEmail($postData, $absences);

            // Construction du message final
            $messageFlash = 'Rattrapage mis à jour avec succès.';
            if ($emailResult === 'sent') {
                $messageFlash .= ' Notification envoyée à l\'enseignant.';
            } elseif ($emailResult === 'error') {
                $messageFlash .= ' Attention : Erreur lors de l\'envoi du mail.';
            }
            // Si 'skipped', on n'ajoute rien au message pour ne pas polluer l'affichage

            return redirect()->to('/gestion_rattrapage')->with('success', $messageFlash);

        } catch (\Exception $e) {
            $db->transRollback();
            log_message('error', 'Erreur update: ' . $e->getMessage());
            return redirect()->back()->withInput()->with('error', 'Exception: ' . $e->getMessage());
        }
    }

    private function envoieModificationEmail(array $postData, array $absences): string
    {
        $notifModel = new NotificationModel();
        
        // 1. Vérification des préférences (Notif2 = Modification)
        $preferences = $notifModel->where('email_ens', $postData['mail_enseignant'])->first();

        // Logique Opt-out : on envoie par défaut, sauf si explicitement désactivé (0)
        $doitEnvoyer = true;
        if ($preferences && isset($preferences['notif2'])) {
            $doitEnvoyer = ($preferences['notif2'] == 1);
        }

        if (!$doitEnvoyer) {
            log_message('info', 'Email modif ignoré (notif2=0) pour ' . $postData['mail_enseignant']);
            return 'skipped';
        }

        try {
            // 2. Récupération du nom de la ressource
            $ressourceModel = new RessourceModel();
            $ressource = $ressourceModel->find($postData['id_ressource']);
            $nomRessource = $ressource ? $ressource['nom'] : 'Matière inconnue';

            // 3. Configuration de l'email
            $email = \Config\Services::email();
            $email->setMailType('html');
            $email->setFrom('no-reply@votre-etablissement.fr', 'Gestion Rattrapages');
            $email->setTo($postData['mail_enseignant']);
            $email->setSubject("Modification Rattrapage : " . $nomRessource);

            // 4. Construction du HTML
            $liEtudiants = "";
            if (!empty($absences)) {
                foreach ($absences as $abs) {
                    $liEtudiants .= "<li>" . esc($abs['email_etud']) . "</li>";
                }
            } else {
                $liEtudiants = "<li>Aucun étudiant absent sélectionné.</li>";
            }

            $message = "
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset='utf-8'>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 20px; }
                    .container { max-width: 600px; margin: 0 auto; background: #fff; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px; }
                    h2 { color: #d97706; margin-top: 0; }
                    h3 { color: #374151; border-bottom: 2px solid #e5e7eb; padding-bottom: 5px; margin-top: 20px; }
                    ul { background-color: #f9fafb; padding: 15px 30px; border-radius: 5px; }
                    li { margin-bottom: 5px; }
                    .footer { margin-top: 30px; font-size: 0.9em; color: #6b7280; border-top: 1px solid #e5e7eb; padding-top: 10px; }
                </style>
            </head>
            <body>
                <div class='container'>
                    <h2>Mise à jour d'un rattrapage</h2>
                    <p>Les informations concernant un rattrapage dont vous êtes responsable ont été modifiées.</p>
                    
                    <h3>Nouvelles informations du DS</h3>
                    <ul>
                        <li><strong>Ressource :</strong> " . esc($nomRessource) . "</li>
                        <li><strong>Date originale :</strong> " . esc($postData['date_ds_original']) . "</li>
                        <li><strong>Type :</strong> " . esc($postData['type_ds']) . "</li>
                        <li><strong>Durée :</strong> " . esc($postData['duree']) . " minutes</li>
                    </ul>

                    <h3>Liste des étudiants mise à jour</h3>
                    <ul>
                        " . $liEtudiants . "
                    </ul>
                    <p>Merci de prendre en compte ces modifications.</p>
                    <div class='footer'><p>Cordialement,<br>La Direction</p></div>
                </div>
            </body>
            </html>";

            $email->setMessage($message);

            if ($email->send()) {
                log_message('info', 'Email de modification envoyé à ' . $postData['mail_enseignant']);
                return 'sent';
            } else {
                log_message('error', 'Erreur envoi email modif: ' . $email->printDebugger(['headers']));
                return 'error';
            }

        } catch (\Exception $e) {
            log_message('error', 'Exception email modif: ' . $e->getMessage());
            return 'error';
        }
    }
}
