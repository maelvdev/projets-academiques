<?php

namespace App\Controllers;

use App\Models\UtilisateurModel;

class GestionUtilisateurController extends BaseController {
    public function index(): string {
        $utilisateurModel = new UtilisateurModel();
        $utilisateurs = $utilisateurModel->findAll();

        $data = [
            'title' => 'SGRDS - Gestion des utilisateurs',
            'utilisateurs' => $utilisateurs,
            'active_page' => 'gestion_utilisateur',
            'role' => session()->get('role'),
        ];

        return view('modeDirecteur/gestion_utilisateur', $data);
    }

    public function voir($email)
    {
        $utilisateurModel = new UtilisateurModel();
        $user = $utilisateurModel->where('email', $email)->first();

        if (!$user) {
            return redirect()->to('/gestion_utilisateur')->with('error', 'Utilisateur introuvable.');
        }

        $data = [
            'title' => 'SGRDS - Voir utilisateur',
            'user' => $user,
            'active_page' => 'gestion_utilisateur',
            'role' => session()->get('role'),
        ];

        return view('modeDirecteur/voir_utilisateur', $data);
    }

    public function modifier($email)
    {
        $utilisateurModel = new UtilisateurModel();
        $user = $utilisateurModel->where('email', $email)->first();

        if (!$user) {
            return redirect()->to('/gestion_utilisateur')->with('error', 'Utilisateur introuvable.');
        }

        // Empêcher la modification d'un directeur par URL si on n'est pas censé le faire (bien que le bouton soit caché)
        if (strcasecmp(trim($user['role']), 'directeur') === 0) {
             return redirect()->to('/gestion_utilisateur')->with('error', 'Impossible de modifier un directeur.');
        }

        $data = [
            'title' => 'SGRDS - Modifier utilisateur',
            'user' => $user,
            'active_page' => 'gestion_utilisateur',
            'role' => session()->get('role'),
        ];

        return view('modeDirecteur/modification_utilisateur', $data);
    }

    public function update()
    {
        $utilisateurModel = new UtilisateurModel();
        $email = $this->request->getPost('email');
        
        // Validation basique
        if (!$email) {
            return redirect()->back()->with('error', 'Identifiant manquant.');
        }

        $nouveauRole = $this->request->getPost('role');

        $data = [
            'email' => $email, // Important pour save()
            'nom' => $this->request->getPost('nom'),
            'prenom' => $this->request->getPost('prenom'),
            'role' => $nouveauRole,
            'compte_valide' => $this->request->getPost('compte_valide') ? true : false,
        ];

        $message = 'Utilisateur mis à jour avec succès.';

        // Si on promeut un utilisateur comme Directeur
        if (strcasecmp($nouveauRole, 'directeur') === 0) {
            // Trouver l'ancien directeur
            $ancienDirecteur = $utilisateurModel->where('role', 'directeur')->first();
            
            // Si un directeur existe et que ce n'est pas l'utilisateur qu'on est en train de modifier
            if ($ancienDirecteur && $ancienDirecteur['email'] !== $email) {
                // Rétrograder l'ancien directeur
                $utilisateurModel->update($ancienDirecteur['email'], ['role' => 'enseignant']);
                $message .= ' L\'ancien directeur (' . $ancienDirecteur['prenom'] . ' ' . $ancienDirecteur['nom'] . ') a été passé en enseignant.';
            }
        }

        // Utilisation de save() qui gère mieux les clés primaires non auto-incrémentées
        if (!$utilisateurModel->save($data)) {
            return redirect()->back()->with('error', 'Erreur lors de la mise à jour : ' . implode(', ', $utilisateurModel->errors()));
        }

        // Si l'utilisateur modifie son propre compte, on le déconnecte pour forcer la mise à jour des droits en session
        if ($email === session()->get('email')) {
            session()->destroy();
            return redirect()->to('/auth/connexion')->with('success', 'Vos informations ont été mises à jour. Veuillez vous reconnecter.');
        }

        return redirect()->to('/gestion_utilisateur')->with('success', $message);
    }

    public function supprimer($email)
    {
        $utilisateurModel = new UtilisateurModel();
        $user = $utilisateurModel->where('email', $email)->first();

        if (!$user) {
            return redirect()->to('/gestion_utilisateur')->with('error', 'Utilisateur introuvable.');
        }

        if (strcasecmp(trim($user['role']), 'directeur') === 0) {
            return redirect()->to('/gestion_utilisateur')->with('error', 'Impossible de supprimer un directeur.');
        }

        $utilisateurModel->delete($email);

        return redirect()->to('/gestion_utilisateur')->with('success', 'Utilisateur supprimé avec succès.');
    }
}
