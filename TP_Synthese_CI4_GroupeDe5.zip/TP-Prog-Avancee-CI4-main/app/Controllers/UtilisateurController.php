<?php
namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UtilisateurModel;
use App\Models\TokenVerificationModel;

class UtilisateurController extends BaseController {
    // Affiche un formulaire d'inscription minimal (optionnel)
    public function registerForm() {
        echo view('auth/register');
    }

    // Traite l'inscription et envoie le token par email
    public function register() {
        log_message('error', 'register controller called');
        $post = $this->request->getPost();
        $email = $post['email'] ?? null;
        $nom = $post['nom'] ?? null;
        $prenom = $post['prenom'] ?? null;
        $role = $post['role'] ?? 'enseignant';
        $password = $post['password'] ?? null;

        // validation simple
        if (!$email || !$password || !$nom) {
            return redirect()->back()->with('error', 'Données manquantes');
        }

        $userModel = new UtilisateurModel();
        if ($userModel->existsByEmail($email)) {
            return redirect()->back()->with('error', 'Email déjà utilisé');
        }

        $db = \Config\Database::connect();
        $db->transStart();

        $pwdHash = password_hash($password, PASSWORD_DEFAULT);
        $userModel->insert([
            'email' => $email,
            'mot_de_passe' => $pwdHash,
            'role' => $role,
            'nom' => $nom,
            'prenom' => $prenom,
            'compte_valide' => false,
        ]);

        // Génération token sécurisé
        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $expires = date('Y-m-d H:i:s', strtotime('+24 hours'));

        $tokenModel = new TokenVerificationModel();
        $tokenModel->createToken([
            'token_hash' => $tokenHash,
            'email_utilisateur' => $email,
            'date_expiration' => $expires,
            'type' => 'verification',
        ]);

        $db->transComplete();

        // Envoi email (simplifié) - utilise le service Email de CI
        $emailService = \Config\Services::email();
        $verificationUrl = base_url('auth/verify?token=' . $token);
        $emailService->setTo($email);
        $emailService->setSubject('Confirmation de votre compte SGRDS');
        $body = "Bonjour {$prenom},\n\nVeuillez confirmer votre compte en cliquant sur le lien suivant:\n{$verificationUrl}\n\nCe lien expirera dans 24 heures.";
        $emailService->setMessage($body);
        // send might be blocked on some dev environments; ignore return
        try {
            $emailService->send();
        } catch (\Exception $e) {
            // Logging minimal
            log_message('error', 'Erreur envoi mail: ' . $e->getMessage());
        }

        return redirect()
            ->to('/')
            ->with('message', 'Inscription enregistrée. Vérifiez votre email pour activer le compte.');
    }

    // Vérifie le token envoyé par email
    public function verify() {
        $token = $this->request->getGet('token');
        if (!$token) {
            return redirect()->to('/login')->with('error', 'Token manquant');
        }

        $tokenHash = hash('sha256', $token);
        $tokenModel = new TokenVerificationModel();
        $row = $tokenModel->findByHash($tokenHash);

        if (!$row) {
            return redirect()->to('/login')->with('error', 'Token invalide ou expiré');
        }

        // Vérifier expiration
        if (strtotime($row['date_expiration']) < time()) {
            // supprimer token expiré
            $tokenModel->deleteById($row['id']);
            return redirect()->to('/login')->with('error', 'Token expiré');
        }

        // Activer le compte
        $userModel = new UtilisateurModel();
        $userModel->update($row['email_utilisateur'], [
            'compte_valide' => true,
        ]);
        // supprimer le token
        $tokenModel->deleteById($row['id']);

        return redirect()->to('/')->with('message', 'Compte activé. Vous pouvez maintenant vous connecter.');
    }
}
