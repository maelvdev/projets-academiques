<?php
namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UtilisateurModel;
use App\Models\NotificationModel;

class ParametresController extends BaseController {
    protected $utilisateurModel;
    protected $notificationModel;

    public function __construct()
    {
        $this->utilisateurModel = new UtilisateurModel();
        $this->notificationModel = new NotificationModel();
    }

    public function profil() {
        $session = session();
        $email = $session->get('email');

        $ligneUtilisateur = null;
        if ($email) {
            $ligneUtilisateur = $this->utilisateurModel->where('email', $email)->first();
        }

        $utilisateur = [
            'prenom' => $ligneUtilisateur['prenom'] ?? '',
            'nom' => $ligneUtilisateur['nom'] ?? '',
            'email' => $ligneUtilisateur['email'] ?? $email,
            'telephone' => $ligneUtilisateur['telephone'] ?? '',
            'departement' => $ligneUtilisateur['departement'] ?? '',
            'role' => $ligneUtilisateur['role'] ?? '',
        ];

        $data = [
            'active_page' => 'parametres',
            'active_tab' => 'profil',
            'role' => $utilisateur['role'] ?: 'Utilisateur',
            'user' => $utilisateur,
        ];

        return view('parametres/profil-view', $data);
    }

    public function updateProfil() {
        $validation = \Config\Services::validation();

        $validation->setRules([
            'prenom' => 'required|min_length[2]|max_length[50]',
            'nom' => 'required|min_length[2]|max_length[50]',
            'email' => 'required|valid_email',
            'telephone' => 'permit_empty|max_length[20]',
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $session = session();
        $email = $session->get('email');
        if (!$email) {
            return redirect()->to('/login')->with('error', 'Vous devez vous connecter pour modifier votre profil');
        }

        $ligneUtilisateur = $this->utilisateurModel->where('email', $email)->first();
        if (!$ligneUtilisateur) {
            return redirect()->back()->withInput()->with('error', 'Utilisateur introuvable');
        }

        $newEmail = $this->request->getPost('email');
        if ($newEmail !== $email) {
            $exists = $this->utilisateurModel->where('email', $newEmail)->first();
            if ($exists) {
                return redirect()->back()->withInput()->with('error', 'Cet email est déjà utilisé par un autre compte');
            }
        }

        $updateData = [
            'prenom' => $this->request->getPost('prenom'),
            'nom' => $this->request->getPost('nom'),
            'email' => $newEmail,
            'telephone' => $this->request->getPost('telephone'),
        ];

        $updated = $this->utilisateurModel->where('email', $email)->set($updateData)->update();
        if ($updated === false) {
            return redirect()->back()->withInput()->with('error', 'Impossible de mettre à jour le profil');
        }

        $session->set([
            'prenom' => $updateData['prenom'],
            'nom' => $updateData['nom'],
            'email' => $updateData['email'],
        ]);

        return redirect()->to('parametres/profil')->with('success', 'Profil mis à jour avec succès');
    }

    public function motDePasse() {
        $session = session();
        $email = $session->get('email');

        $userRow = null;
        if ($email) {
            $userRow = $this->utilisateurModel->where('email', $email)->first();
        }

        $user = [
            'prenom' => $userRow['prenom'] ?? '',
            'nom' => $userRow['nom'] ?? '',
            'role' => $userRow['role'] ?? '',
        ];

        $data = [
            'active_page' => 'parametres',
            'active_tab' => 'mot-de-passe',
            'role' => $user['role'] ?: 'Utilisateur',
            'user' => $user,
        ];

        return view('parametres/mot-de-passe-view', $data);
    }

    public function updateMotDePasse() {
        $validation = \Config\Services::validation();

        $validation->setRules([
            'current_password' => 'required',
            'new_password' => 'required|min_length[8]|max_length[255]',
            'confirm_password' => 'required|matches[new_password]',
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->with('errors', $validation->getErrors());
        }

        $session = session();
        $email = $session->get('email');
        if (!$email) {
            return redirect()->to('/auth/connexion')->with('error', 'Vous devez vous connecter pour modifier votre mot de passe');
        }

        $utilisateur = $this->utilisateurModel->where('email', $email)->first();
        if (!$utilisateur) {
            return redirect()->back()->with('error', 'Utilisateur introuvable');
        }

        $current = $this->request->getPost('current_password');
        if (!password_verify($current, $utilisateur['mot_de_passe'])) {
            return redirect()->back()->withInput()->with('error', 'Mot de passe actuel incorrect');
        }

        $new = $this->request->getPost('new_password');
        $hash = password_hash($new, PASSWORD_DEFAULT);

        $updated = $this->utilisateurModel->where('email', $email)->set(['mot_de_passe' => $hash])->update();
        if ($updated === false) {
            return redirect()->back()->withInput()->with('error', 'Impossible de mettre à jour le mot de passe');
        }

        return redirect()->to('parametres/mot-de-passe')->with('success', 'Mot de passe modifié avec succès');
    }

    public function notifications() {
        $session = session();
        $email = $session->get('email');

        $userRow = null;
        if ($email) {
            $userRow = $this->utilisateurModel->where('email', $email)->first();
        }

        if (!$userRow) {
            return redirect()->to('/auth/connexion');
        }

        $user = [
            'prenom' => $userRow['prenom'] ?? '',
            'nom'    => $userRow['nom'] ?? '',
            'role'   => $userRow['role'] ?? '',
        ];

        $notifData = $this->notificationModel->where('email_ens', $email)->first();

        $preferences = [
            'notif_rattrapages'   => $notifData ? (bool)$notifData['notif1'] : false,
            'notif_modifications' => $notifData ? (bool)$notifData['notif2'] : false,
        ];

        $data = [
            'active_page' => 'parametres',
            'active_tab'  => 'notifications',
            'role'        => $user['role'] ?: 'Utilisateur',
            'user'        => $user,
            'preferences' => $preferences,
        ];

        return view('parametres/notifications-view', $data);
    }

    public function updateNotifications() {
        $session = session();
        $email = $session->get('email');

        if (!$email) {
            return redirect()->to('/auth/connexion')->with('error', 'Session expirée.');
        }

        $notif1 = $this->request->getPost('notif_rattrapages') ? 1 : 0;
        $notif2 = $this->request->getPost('notif_modifications') ? 1 : 0;

        $dataToUpdate = [
            'notif1' => $notif1,
            'notif2' => $notif2
        ];

        $exists = $this->notificationModel->where('email_ens', $email)->first();

        if ($exists) {
            $this->notificationModel
                ->where('email_ens', $email)
                ->set($dataToUpdate)
                ->update();
        } else {
            $dataToUpdate['email_ens'] = $email;
            $this->notificationModel->insert($dataToUpdate);
        }

        return redirect()->to('parametres/notifications')->with('success', 'Préférences de notifications mises à jour avec succès.');
    }

    public function deconnecterSessions() {
        $session = session();
        $session->destroy();

        return redirect()->to('/auth/connexion')->with('success', 'Vous avez été déconnecté');
    }

    public function supprimerCompte() {
        $session = session();
        $email = $session->get('email');
        
        if (!$email) {
            return redirect()->to('/auth/connexion')->with('error', 'Vous devez vous connecter pour supprimer votre compte');
        }

        $utilisateur = $this->utilisateurModel->where('email', $email)->first();
        
        if (!$utilisateur) {
            return redirect()->back()->with('error', 'Utilisateur introuvable');
        }

        if ($utilisateur['role'] === 'directeur') {
            $nbDirecteurs = $this->utilisateurModel->where('role', 'directeur')->countAllResults();
            if ($nbDirecteurs <= 1) {
                return redirect()->to('/parametres')
                    ->with('error', 'Il faut que le directeur transfère son rôle avant de supprimer son compte.');
            }
        }

        $deleted = $this->utilisateurModel->where('email', $email)->delete();
        
        if ($deleted === false) {
            return redirect()->back()->with('error', 'Impossible de supprimer le compte');
        }

        $session->destroy();

        return redirect()->to('/auth/inscription')->with('success', 'Compte supprimé avec succès');
    }
}
