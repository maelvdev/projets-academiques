<?php

namespace App\Controllers;

class AuthController extends BaseController {
    public function login() {
        helper(['form']);

        $data = [
            'title' => 'SGRDS - Connexion',
        ];

        return view('auth/login_view', $data);
    }

    public function register() {
        helper(['form']);

        $data = [
            'title' => 'SGRDS - Inscription',
        ];

        return view('auth/register_view', $data);
    }

    public function forgotPassword() {
        helper(['form']);

        $data = [
            'title' => 'SGRDS - Mot de passe oublié',
        ];

        return view('auth/forgot_password_view', $data);
    }
}
