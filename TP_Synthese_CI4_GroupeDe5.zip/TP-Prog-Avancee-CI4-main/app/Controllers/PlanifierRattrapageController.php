<?php

namespace App\Controllers;

use App\Models\RattrapageModel;
use App\Models\AbsenceModel;
use App\Models\UtilisateurModel;
use App\Models\RessourceModel;
use App\Models\DSModel;
use App\Models\EtudiantModel;

class PlanifierRattrapageController extends BaseController {

    public function index($id_rattrapage): \CodeIgniter\HTTP\RedirectResponse | string
    {
        $rattrapageModel = new RattrapageModel();
        $absenceModel = new AbsenceModel();
        $utilisateurModel = new UtilisateurModel();
        $ressourceModel = new RessourceModel();
        $dsModel = new DSModel();

        $db = \Config\Database::connect();
        $builder = $db->table('rattrapage R');

        $builder->select('
            R.id_rattrapage,
            R.date,
            R.semestre,
            R.mail_enseignant,
            R.id_ressource,
            Res.nom as ressource_nom,
            U.nom as enseignant_nom,
            U.prenom as enseignant_prenom,
            DS.id_ds,
            DS.date as date_ds,
            DS.type_ds,
            DS.duree,
            P.date as date_planification,
            P.type as type_planification,
            P.salle as salle_planification,
            P.commentaire as commentaire_planification
        ');

        $builder->join('ressource Res', 'Res.id_ressource = R.id_ressource', 'left');
        $builder->join('utilisateur U', 'U.email = R.mail_enseignant', 'left');
        $builder->join('ds DS', 'DS.id_ressource = R.id_ressource AND DS.semestre = R.semestre AND DS.mail_enseignant = R.mail_enseignant AND DS.date = R.date', 'left');
        $builder->join('planification P', 'P.id_rattrapage = R.id_rattrapage', 'left');
        $builder->where('R.id_rattrapage', $id_rattrapage);

        $rattrapage = $builder->get()->getRowArray();

        if (!$rattrapage) {
            return redirect()->to('/mes_rattrapages')->with('error', 'Rattrapage introuvable');
        }

        $absenceBuilder = $db->table('absence A');
        $absenceBuilder->select('E.email, E.nom, E.prenom, E.semestre as semestre_etudiant, A.justifie');
        $absenceBuilder->join('eleve E', 'E.email = A.email_etud', 'left');
        $absenceBuilder->where('A.id_rattrapage', $id_rattrapage);
        $etudiants = $absenceBuilder->get()->getResultArray();

        $etat = 'En attente';
        if ($rattrapage['date_planification']) {
            $etat = 'Programmé';
        }

        $role = session()->get('role') ?? 'enseignant';
        $email_utilisateur = session()->get('email');

        if (strtolower($role) === 'directeur') {
            $enseignants = $utilisateurModel->getUtilisateursByRole('enseignant');
        } else {
            $enseignants = [$utilisateurModel->find($email_utilisateur)];
        }

        $data = [
            'title' => "SGRDS - Modification d'un rattrapage",
            'rattrapage' => [
                'id' => $rattrapage['id_rattrapage'],
                'id_rattrapage' => $rattrapage['id_rattrapage'],
                'ressource' => $rattrapage['ressource_nom'],
                'id_ressource' => $rattrapage['id_ressource'],
                'semestre' => $rattrapage['semestre'],
                'date_ds_original' => $rattrapage['date_ds'],
                'type_ds' => $rattrapage['type_ds'],
                'duree' => $rattrapage['duree'],
                'mail_enseignant' => $rattrapage['mail_enseignant'],
                'etat' => $etat,
                'etudiants' => $etudiants,
                'date_rattrapage' => $rattrapage['date_planification'],
                'type_planification' => $rattrapage['type_planification'] ?? 'en attente',
                'salle' => $rattrapage['salle_planification'],
                'plage_horraire' => $this->extraireHoraireFromCommentaire($rattrapage['commentaire_planification']),
                'commentaire' => $rattrapage['commentaire_planification'],
            ],
            'enseignants' => $enseignants,
            'active_page' => 'mes_rattrapages',
            'role' => $role,
        ];

        return view('modeEnseignant/planifier_rattrapage', $data);
    }

    public function planifier($id_rattrapage)
    {
        $request = \Config\Services::request();
        $db = \Config\Database::connect();

        // 1. Validation des données avec REGEX pour l'horaire
        $rules = [
            'date_rattrapage' => 'required|valid_date',
            'horaire' => [
                // Regex stricte : 2 chiffres:2 chiffres - 2 chiffres:2 chiffres
                'rules'  => 'required|regex_match[/^([01]\d|2[0-3]):[0-5]\d-([01]\d|2[0-3]):[0-5]\d$/]',
                'errors' => [
                    'regex_match' => 'La syntaxe de la plage horaire doit impérativement être : HH:mm-HH:mm (ex: 10:30-12:20)'
                ]
            ],
            'salle'           => 'required|max_length[20]',
            'type_rattrapage' => 'required',
        ];

        if (!$this->validate($rules)) {
            // Renvoie les erreurs à la vue (accessibles via session('errors'))
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $horaire = $request->getPost('horaire');
        $duree = $this->calculerDuree($horaire);

        $commentaireSaisi = $request->getPost('commentaire');
        $typeRattrapage   = $request->getPost('type_rattrapage');

        $commentaireFinal = "Type: $typeRattrapage.";
        if (!empty($commentaireSaisi)) {
            $commentaireFinal .= " " . $commentaireSaisi;
        }

        $data = [
            'id_rattrapage'  => $id_rattrapage,
            'date'           => $request->getPost('date_rattrapage'),
            'salle'          => $request->getPost('salle'),
            'type'           => 'planifié',
            'commentaire'    => $commentaireFinal . " Horaire: " . $horaire . " (Durée: " . $duree . " min)"
        ];

        $builder = $db->table('planification');

        $exists = $builder->where('id_rattrapage', $id_rattrapage)->countAllResults() > 0;

        if ($exists) {
            $builder->where('id_rattrapage', $id_rattrapage)->update($data);
        } else {
            $builder->insert($data);
        }

        return redirect()->to('/mes_rattrapages')->with('success', 'Le rattrapage a été planifié avec succès.');
    }

    public function annuler($id_rattrapage)
    {
        $request = \Config\Services::request();
        $db = \Config\Database::connect();

        $raison = $request->getPost('raison_annulation');

        // La raison est maintenant optionnelle
        $commentaire = !empty($raison) ? "Annulation : " . $raison : "Annulation (sans raison spécifiée)";

        $data = [
            'id_rattrapage'  => $id_rattrapage,
            'type'           => 'annulé',
            'date'           => null,
            'salle'          => null,
            'commentaire'    => $commentaire
        ];

        $builder = $db->table('planification');

        $exists = $builder->where('id_rattrapage', $id_rattrapage)->countAllResults() > 0;

        if ($exists) {
            $builder->where('id_rattrapage', $id_rattrapage)->update($data);
        } else {
            $builder->insert($data);
        }

        return redirect()->to('/mes_rattrapages')->with('success', 'Le rattrapage a été marqué comme annulé.');
    }

    public function supprimer($id_rattrapage)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('planification');

        $builder->where('id_rattrapage', $id_rattrapage)->delete();

        return redirect()->back()->with('success', 'La planification a été annulée. Le rattrapage est de nouveau en attente.');
    }

    private function calculerDuree($horaireString)
    {
        $horaireString = str_replace(' ', '', $horaireString);

        $parts = preg_split('/(-|à)/', $horaireString);

        if (count($parts) === 2) {
            $debut = strtotime($parts[0]);
            $fin   = strtotime($parts[1]);

            if ($debut && $fin && $fin > $debut) {
                return ($fin - $debut) / 60;
            }
        }

        return 0;
    }

    private function extraireHoraireFromCommentaire($commentaire)
    {
        // Extraire l'horaire du commentaire s'il est au format "Horaire: HH:mm-HH:mm"
        if (preg_match('/Horaire:\s*(\d{2}:\d{2}-\d{2}:\d{2})/', $commentaire, $matches)) {
            return $matches[1];
        }
        
        return 'Non défini';
    }
}