<?php
namespace App\Controllers;

use App\Controllers\BaseController;

class ErreurPageControlleur extends BaseController {
    /**
     * Affiche la page 404 personnalisée
     */
    public function show404() {
        $uri = service('uri')->getPath();
        $message = "La page demandée n'existe pas : /" . $uri;
        // Render the HTML-specific view used by ExceptionHandler for consistency
        echo view('errors/html/error_404', ['message' => $message]);
    }

    /**
     * Affiche la page 500 personnalisée
     */
    public function show500() {
        $msg = $this->request->getGet('message') ?? 'Erreur interne du serveur.';
        echo view('errors/html/error_500', ['message' => $msg]);
    }
}
