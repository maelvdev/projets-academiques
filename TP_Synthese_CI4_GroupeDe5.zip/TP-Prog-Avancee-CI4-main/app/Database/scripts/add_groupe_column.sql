-- Migration: Ajout de la colonne 'groupe' à la table Eleve
-- Date: 2025-11-27
-- Description: Permet de stocker le groupe de chaque étudiant (ex: G1, G2, TP1, etc.)

USE projet_prog_avancee;

ALTER TABLE Eleve 
ADD COLUMN groupe VARCHAR(20) DEFAULT NULL 
COMMENT 'Groupe de l''étudiant (ex: G1, G2, TP1, etc.)';

-- Vérification
DESCRIBE Eleve;
