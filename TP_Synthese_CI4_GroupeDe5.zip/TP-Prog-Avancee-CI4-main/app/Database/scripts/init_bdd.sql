--
-- 1. Confirmation de la base de données cible (Utilisation de \c, commande psql)
-- \c nom_base_de_donnees

---------------------------------------------------

--
-- 2. SUPPRESSION DES TABLES EXISTANTES (Pour une réinitialisation propre)
-- L'ordre de suppression est important pour éviter les conflits de clés étrangères.
-- PostgreSQL : utilisation de CASCADE pour supprimer les dépendances
--

DROP TABLE IF EXISTS token_verification CASCADE;
DROP TABLE IF EXISTS planification CASCADE;
DROP TABLE IF EXISTS absence CASCADE;
DROP TABLE IF EXISTS ds CASCADE;
DROP TABLE IF EXISTS rattrapage CASCADE;
DROP TABLE IF EXISTS ressource CASCADE;
DROP TABLE IF EXISTS eleve CASCADE;
DROP TABLE IF EXISTS utilisateur CASCADE;
DROP TABLE IF EXISTS notification CASCADE;

---------------------------------------------------

--
-- 3. CRÉATION DES TABLES
--

--
-- Table 1: Utilisateur (Gestion des comptes et rôles)
-- Contient l'authentification et les détails des enseignants/directeurs.
--
CREATE TABLE utilisateur (
    email VARCHAR(100) PRIMARY KEY, -- PK (Email utilisé comme identifiant unique)
    mot_de_passe VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('directeur', 'enseignant')),
    nom VARCHAR(50) NOT NULL,
    prenom VARCHAR(50) NOT NULL,
    compte_valide BOOLEAN DEFAULT FALSE -- Pour la validation/activation (0 = non validé, 1 = validé)
);

---------------------------------------------------

--
-- Table 2: Ressource (Liste des matières/ressources enseignées)
--
CREATE TABLE ressource (
    id_ressource SERIAL PRIMARY KEY,
    nom VARCHAR(100) NOT NULL UNIQUE, -- Nom de la ressource (ex: "R1.01 - Initiation au développement")
    semestre INT NOT NULL CHECK (semestre BETWEEN 1 AND 6)
);

---------------------------------------------------

--
-- Table 3: Eleve (Détails des étudiants)
--
CREATE TABLE eleve (
    email VARCHAR(100) PRIMARY KEY, -- PK (Email utilisé comme identifiant unique)
    nom VARCHAR(50) NOT NULL,
    prenom VARCHAR(50) NOT NULL,
    semestre INT NOT NULL CHECK (semestre BETWEEN 1 AND 6), -- S1=1, S2=2, S3=3, etc.
    groupe VARCHAR(20) DEFAULT NULL -- Groupe de l'étudiant (ex: G1, G2, TP1, etc.)
);

---------------------------------------------------

--
-- Table 4: Rattrapage (Entité principale du rattrapage, le DS initial)
-- L'attribut 'mail_enseignant' est la clé étrangère vers Utilisateur.
-- L'attribut 'id_ressource' est la clé étrangère vers Ressource.
--
CREATE TABLE rattrapage (
    id_rattrapage SERIAL PRIMARY KEY, -- Clé primaire auto-incrémentée
    mail_enseignant VARCHAR(100) NOT NULL, -- FK vers utilisateur (l'enseignant qui gère le rattrapage)
    id_ressource INT NOT NULL, -- FK vers ressource
    date DATE NOT NULL,
    semestre INT NOT NULL CHECK (semestre BETWEEN 1 AND 6),
    
    CONSTRAINT fk_rattrapage_enseignant
        FOREIGN KEY (mail_enseignant)
        REFERENCES utilisateur (email)
        ON DELETE CASCADE,
    
    CONSTRAINT fk_rattrapage_ressource
        FOREIGN KEY (id_ressource)
        REFERENCES ressource (id_ressource)
        ON DELETE CASCADE
);

---------------------------------------------------

--
-- Table 5: DS (Informations du DS initial)
-- Contient les détails du devoir surveillé : date, type, durée, etc.
--
CREATE TABLE ds (
    id_ds SERIAL PRIMARY KEY,
    date DATE NOT NULL,
    id_ressource INT NOT NULL, -- FK vers ressource
    semestre INT NOT NULL CHECK (semestre BETWEEN 1 AND 6),
    mail_enseignant VARCHAR(100) NOT NULL, -- FK vers utilisateur (l'enseignant qui a fait le DS)
    type_ds VARCHAR(50) NOT NULL CHECK (type_ds IN ('DS Table', 'DS Machine')),
    duree INT NOT NULL, -- Durée en minutes
    
    CONSTRAINT fk_ds_enseignant
        FOREIGN KEY (mail_enseignant)
        REFERENCES utilisateur (email)
        ON DELETE CASCADE,
    
    CONSTRAINT fk_ds_ressource
        FOREIGN KEY (id_ressource)
        REFERENCES ressource (id_ressource)
        ON DELETE CASCADE
);

---------------------------------------------------

--
-- Table 6: Absence (Jointure entre Rattrapage et Eleve)
-- Gère les étudiants absents justifiés/non justifiés.
--
CREATE TABLE absence (
    email_etud VARCHAR(100) NOT NULL, -- FK vers eleve
    id_rattrapage INT NOT NULL, -- FK vers rattrapage
    justifie SMALLINT NOT NULL DEFAULT 0, -- Si l'absence est justifiée (0 = non justifié par défaut)
    
    PRIMARY KEY (email_etud, id_rattrapage),
    
    CONSTRAINT fk_absence_etud
        FOREIGN KEY (email_etud)
        REFERENCES eleve (email)
        ON DELETE CASCADE,
        
    CONSTRAINT fk_absence_rattrapage
        FOREIGN KEY (id_rattrapage)
        REFERENCES rattrapage (id_rattrapage)
        ON DELETE CASCADE
);

---------------------------------------------------

--
-- Table 7: Planification (Détails de l'organisation du rattrapage)
-- Contient les détails saisis par l'enseignant.
-- L'attribut 'message' dans votre schéma est renommé 'commentaire' pour la clarté.
-- Une relation 1-1 avec Rattrapage est implicite si id_rattrapage est PK.
--
CREATE TABLE planification (
    id_rattrapage INT PRIMARY KEY, -- PK et FK vers rattrapage
    type VARCHAR(50) NOT NULL CHECK (type IN ('annulé', 'planifié', 'en attente')),
    date DATE,
    heure_debut TIME,  -- Nouvelle colonne (ex: 14:00:00)
    heure_fin TIME,    -- Nouvelle colonne (ex: 16:00:00)
    duree INT,         -- Durée en minutes (ajoutée pour compatibilité code)
    plage_horraire VARCHAR(20), -- Format "HH:mm-HH:mm" (ajoutée pour compatibilité code)
    salle VARCHAR(20),
    commentaire TEXT,

    CONSTRAINT fk_planif_rattrapage
        FOREIGN KEY (id_rattrapage)
        REFERENCES rattrapage (id_rattrapage)
        ON DELETE CASCADE
);

---------------------------------------------------

---------------------------------------------------

--
-- Table 8: Token_Verification (pour confirmation d'inscription par email)
-- Stocke un hash du token (sécurité) et la date d'expiration
-- Utilisé pour activer le compte utilisateur après clic sur le lien de vérification
--
CREATE TABLE token_verification (
    id SERIAL PRIMARY KEY,
    token_hash VARCHAR(128) NOT NULL UNIQUE,
    email_utilisateur VARCHAR(100) NOT NULL,
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_expiration TIMESTAMP NOT NULL,
    type VARCHAR(50) NOT NULL DEFAULT 'verification',

    CONSTRAINT fk_token_utilisateur
        FOREIGN KEY (email_utilisateur)
        REFERENCES utilisateur (email)
        ON DELETE CASCADE
);

CREATE INDEX idx_token_verif_expiration ON token_verification(date_expiration);

--
-- Table 9: Notification
-- Gestion des préférences de notification des enseignants
-- Basé sur le diagramme fourni (Lien avec Utilisateur via email_ens)
--
CREATE TABLE notification (
    id_notif SERIAL PRIMARY KEY,
    email_ens VARCHAR(100) NOT NULL, -- Clé étrangère vers utilisateur
    notif1 SMALLINT DEFAULT 0,     -- Booléen (0 = Faux, 1 = Vrai)
    notif2 SMALLINT DEFAULT 0,     -- Booléen (0 = Faux, 1 = Vrai)

    CONSTRAINT fk_notification_utilisateur
        FOREIGN KEY (email_ens)
        REFERENCES utilisateur (email)
        ON DELETE CASCADE -- Si l'utilisateur est supprimé, ses préférences de notif le sont aussi
);


--
-- 4. DÉCLENCHEUR (TRIGGER)
-- Création automatique des préférences de notification à l'inscription d'un utilisateur
--
CREATE OR REPLACE FUNCTION create_notification_on_user_insert()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO notification (email_ens, notif1, notif2)
    VALUES (NEW.email, 1, 1);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER after_utilisateur_insert
AFTER INSERT ON utilisateur
FOR EACH ROW
EXECUTE FUNCTION create_notification_on_user_insert();


---------------------------------------------------
-- Données de test
---------------------------------------------------

--
-- Insertion de ressources
--
INSERT INTO ressource (nom, semestre) VALUES
('R1.01 - Initiation au développement', 1),
('R1.02 - Développement d''interfaces web', 1),
('R1.03 - Introduction à l''architecture des ordinateurs', 1),
('R1.04 - Introduction aux bases de données', 1),
('R1.05 - Introduction aux réseaux informatiques', 1),
('R1.06 - Mathématiques discrètes', 1),
('R1.07 - Outils mathématiques fondamentaux', 1),
('R1.08 - Gestion de projet & des organisations', 1),
('R1.09 - Économie durable et numérique', 1),
('R1.10 - Anglais professionnel', 1),
('R1.11 - Bases de la communication', 1),
('R1.12 - Projet professionnel et personnel', 1),
('R2.01 - Développement orienté objets', 2),
('R2.02 - Développement d''applications avec IHM', 2),
('R2.03 - Qualité de développement', 2),
('R2.04 - Communication et fonctionnement bas niveau', 2),
('R2.05 - Introduction aux services réseaux', 2),
('R2.06 - Exploitation d''une base de données', 2),
('R2.07 - Graphes', 2),
('R2.08 - Outils numériques pour les statistiques descriptives', 2),
('R2.09 - Méthodes numériques', 2),
('R2.10 - Gestion de projet et des organisations', 2),
('R2.11 - Droit des contrats et du numérique', 2),
('R2.12 - Anglais professionnel', 2),
('R3.01 - Développement web', 3),
('R3.02 - Développement d''applications réparties', 3),
('R3.03 - Analyse et modélisation', 3),
('R3.04 - Qualité de développement', 3),
('R3.05 - Programmation système', 3),
('R3.06 - Architecture des réseaux', 3),
('R3.07 - SQL dans un système de gestion de bases de données', 3),
('R3.08 - Probabilités', 3),
('R3.09 - Cryptographie et sécurité', 3),
('R3.10 - Management des systèmes d''information', 3),
('R3.11 - Droit des services numériques', 3),
('R3.12 - Anglais professionnel', 3),
('R4.01 - Architecture logicielle', 4),
('R4.02 - Qualité de développement', 4),
('R4.03 - Qualité et non-relationnel', 4),
('R4.04 - Méthodes d''optimisation pour l''aide à la décision', 4),
('R4.05 - Anglais professionnel', 4),
('R4.06 - Communication interne', 4),
('R4.07 - Droit du numérique approfondi', 4),
('R5.01 - Développement avancé', 5),
('R5.02 - Qualité algorithmique', 5),
('R5.03 - Programmation fonctionnelle', 5),
('R5.04 - Virtualisation', 5),
('R5.05 - Programmation avancée', 5),
('R5.06 - Sensibilisation à la programmation multimédia', 5),
('R5.07 - Automatisation', 5),
('R5.08 - Qualité de développement', 5),
('R5.09 - Mathématiques pour l''informatique', 5),
('R5.10 - Anglais professionnel', 5),
('R6.01 - Architecture et développement', 6),
('R6.02 - Développement avancé', 6),
('R6.03 - Développement pour applications mobiles', 6),
('R6.04 - Qualité et au-delà du relationnel', 6),
('R6.05 - Mathématiques approfondies', 6),
('R6.06 - Anglais professionnel', 6);


-- Activation de l'extension pgcrypto si pas déjà fait
-- CREATE EXTENSION IF NOT EXISTS pgcrypto;
/*
INSERT INTO Utilisateur (email, mot_de_passe, role, nom, prenom, compte_valide) VALUES
('alice.dupont@example.edu', encode(digest('AlicePass2025!'::text, 'sha256'::text), 'hex'), 'enseignant', 'Dupont', 'Alice', TRUE),
('bruno.martin@example.edu', encode(digest('BrunoPass2025!'::text, 'sha256'::text), 'hex'), 'enseignant', 'Martin', 'Bruno', TRUE),
('celine.lefevre@example.edu', encode(digest('CelinePass2025!'::text, 'sha256'::text), 'hex'), 'enseignant', 'Lefevre', 'Céline', TRUE),
('damien.roche@example.edu', encode(digest('DamienPass2025!'::text, 'sha256'::text), 'hex'), 'enseignant', 'Roche', 'Damien', TRUE),
('emma.moreau@example.edu', encode(digest('EmmaPass2025!'::text, 'sha256'::text), 'hex'), 'enseignant', 'Moreau', 'Emma', TRUE),
('fabrice.girard@example.edu', encode(digest('FabricePass2025!'::text, 'sha256'::text), 'hex'), 'enseignant', 'Girard', 'Fabrice', TRUE),
('gaelle.perrin@example.edu', encode(digest('GaellePass2025!'::text, 'sha256'::text), 'hex'), 'enseignant', 'Perrin', 'Gaëlle', TRUE),
('hugo.leblanc@example.edu', encode(digest('HugoPass2025!'::text, 'sha256'::text), 'hex'), 'enseignant', 'Leblanc', 'Hugo', TRUE);
*/

INSERT INTO eleve (email, nom, prenom, semestre) VALUES
('lea.martin@student.example.edu', 'Martin', 'Léa', 1),
('thomas_bernard@student.example.edu', 'Bernard', 'Thomas', 1),
('manon.durand@student.example.edu', 'Durand', 'Manon', 1),
('lionel.rousseau@student.example.edu', 'Rousseau', 'Lionel', 2),
('emma.garnier@student.example.edu', 'Garnier', 'Emma', 2),
('hugo.morel@student.example.edu', 'Morel', 'Hugo', 2),
('clara.picard@student.example.edu', 'Picard', 'Clara', 3),
('mathieu.faure@student.example.edu', 'Faure', 'Mathieu', 3),
('sarah.lefort@student.example.edu', 'Lefort', 'Sarah', 3),
('lucas.brun@student.example.edu', 'Brun', 'Lucas', 4),
('anais.boyer@student.example.edu', 'Boyer', 'Anaïs', 4),
('nicolas.gautier@student.example.edu', 'Gautier', 'Nicolas', 4),
('julie.meunier@student.example.edu', 'Meunier', 'Julie', 5),
('quentin.hamel@student.example.edu', 'Hamel', 'Quentin', 5),
('eva.roux@student.example.edu', 'Roux', 'Eva', 5),
('paul.mercier@student.example.edu', 'Mercier', 'Paul', 6),
('celine.fabre@student.example.edu', 'Fabre', 'Céline', 6),
('antoine.lefevre@student.example.edu', 'Lefèvre', 'Antoine', 6),
('marie.dumas@student.example.edu', 'Dumas', 'Marie', 1),
('arthur.gillet@student.example.edu', 'Gillet', 'Arthur', 2),
('zoe.lacroix@student.example.edu', 'Lacroix', 'Zoé', 3),
('lucie.petit@student.example.edu', 'Petit', 'Lucie', 4),
('remi.colin@student.example.edu', 'Colin', 'Rémi', 5),
('isabelle.morel@student.example.edu', 'Morel', 'Isabelle', 6);
