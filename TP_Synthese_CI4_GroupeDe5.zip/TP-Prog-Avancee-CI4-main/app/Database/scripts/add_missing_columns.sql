-- Script pour ajouter les colonnes manquantes à la table planification
-- Ces colonnes sont utilisées dans le code mais n'existent pas dans la base de données

-- Ajouter la colonne plage_horraire pour stocker les horaires du rattrapage
ALTER TABLE planification ADD COLUMN plage_horraire VARCHAR(100);

-- Commentaire: La colonne duree existe déjà dans la table ds, donc pas besoin de l'ajouter ici
-- La duree devrait être récupérée depuis la table ds dans les requêtes