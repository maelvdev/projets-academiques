-- Script pour ajouter la valeur par défaut à la colonne justifie
-- et mettre à jour les valeurs NULL existantes

USE projet_prog_avancee;

-- Mettre à jour les valeurs NULL existantes à 0
UPDATE Absence 
SET justifie = 0 
WHERE justifie IS NULL;

-- Modifier la colonne pour ajouter DEFAULT 0
ALTER TABLE Absence 
MODIFY COLUMN justifie TINYINT(1) NOT NULL DEFAULT 0 
COMMENT 'Si l''absence est justifiée (0 = non justifié par défaut)';

-- Vérification
SELECT COUNT(*) as total_absences, 
       SUM(CASE WHEN justifie = 1 THEN 1 ELSE 0 END) as justifiees,
       SUM(CASE WHEN justifie = 0 THEN 1 ELSE 0 END) as non_justifiees
FROM Absence;
