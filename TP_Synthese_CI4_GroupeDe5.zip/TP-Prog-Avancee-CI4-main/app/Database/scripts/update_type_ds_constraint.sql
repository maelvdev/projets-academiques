-- Migration: Mise à jour de la contrainte type_ds
-- Date: 2025-11-27
-- Description: Remplacer les anciennes valeurs 'devoir surveillé'/'SAE' par 'DS Table'/'DS Machine'

USE projet_prog_avancee;

-- Méthode: Recréer la table avec la bonne contrainte
-- Étape 1: Désactiver temporairement les contraintes de clés étrangères
SET FOREIGN_KEY_CHECKS = 0;

-- Étape 2: Sauvegarder les données existantes
CREATE TEMPORARY TABLE DS_backup AS SELECT * FROM DS;

-- Étape 3: Supprimer l'ancienne table
DROP TABLE DS;

-- Étape 4: Recréer la table avec la nouvelle contrainte
CREATE TABLE DS (
    id_ds INT AUTO_INCREMENT PRIMARY KEY,
    date DATE NOT NULL,
    id_ressource INT NOT NULL,
    semestre INT NOT NULL CHECK (semestre BETWEEN 1 AND 6),
    mail_enseignant VARCHAR(100) NOT NULL,
    type_ds VARCHAR(50) NOT NULL CHECK (type_ds IN ('DS Table', 'DS Machine')),
    duree INT NOT NULL,
    
    CONSTRAINT fk_ds_enseignant
        FOREIGN KEY (mail_enseignant)
        REFERENCES Utilisateur (email)
        ON DELETE RESTRICT,
    
    CONSTRAINT fk_ds_ressource
        FOREIGN KEY (id_ressource)
        REFERENCES Ressource (id_ressource)
        ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Étape 5: Restaurer les données en convertissant les anciennes valeurs
-- Convertir 'devoir surveillé' en 'DS Table' et 'SAE' en 'DS Machine'
INSERT INTO DS (id_ds, date, id_ressource, semestre, mail_enseignant, type_ds, duree)
SELECT 
    id_ds, 
    date, 
    id_ressource, 
    semestre, 
    mail_enseignant, 
    CASE 
        WHEN type_ds = 'devoir surveillé' THEN 'DS Table'
        WHEN type_ds = 'SAE' THEN 'DS Machine'
        ELSE type_ds  -- Garde la valeur si elle est déjà 'DS Table' ou 'DS Machine'
    END as type_ds,
    duree
FROM DS_backup;

-- Étape 6: Supprimer la table temporaire
DROP TEMPORARY TABLE DS_backup;

-- Étape 7: Réactiver les contraintes de clés étrangères
SET FOREIGN_KEY_CHECKS = 1;

-- Vérification
SHOW CREATE TABLE DS;
