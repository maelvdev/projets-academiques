<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class EleveSeeder extends Seeder
{
    public function run()
    {
        $data = [
            ['email' => 'lea.martin@student.example.edu', 'nom' => 'Martin', 'prenom' => 'Léa', 'semestre' => 1, 'groupe' => 'G1'],
            ['email' => 'thomas_bernard@student.example.edu', 'nom' => 'Bernard', 'prenom' => 'Thomas', 'semestre' => 1, 'groupe' => 'G1'],
            ['email' => 'manon.durand@student.example.edu', 'nom' => 'Durand', 'prenom' => 'Manon', 'semestre' => 1, 'groupe' => 'G2'],
            ['email' => 'marie.dumas@student.example.edu', 'nom' => 'Dumas', 'prenom' => 'Marie', 'semestre' => 1, 'groupe' => 'G2'],
            
            ['email' => 'lionel.rousseau@student.example.edu', 'nom' => 'Rousseau', 'prenom' => 'Lionel', 'semestre' => 2, 'groupe' => 'G1'],
            ['email' => 'emma.garnier@student.example.edu', 'nom' => 'Garnier', 'prenom' => 'Emma', 'semestre' => 2, 'groupe' => 'G1'],
            ['email' => 'hugo.morel@student.example.edu', 'nom' => 'Morel', 'prenom' => 'Hugo', 'semestre' => 2, 'groupe' => 'G2'],
            ['email' => 'arthur.gillet@student.example.edu', 'nom' => 'Gillet', 'prenom' => 'Arthur', 'semestre' => 2, 'groupe' => 'G2'],
            
            ['email' => 'clara.picard@student.example.edu', 'nom' => 'Picard', 'prenom' => 'Clara', 'semestre' => 3, 'groupe' => 'G1'],
            ['email' => 'mathieu.faure@student.example.edu', 'nom' => 'Faure', 'prenom' => 'Mathieu', 'semestre' => 3, 'groupe' => 'G1'],
            ['email' => 'sarah.lefort@student.example.edu', 'nom' => 'Lefort', 'prenom' => 'Sarah', 'semestre' => 3, 'groupe' => 'G2'],
            ['email' => 'zoe.lacroix@student.example.edu', 'nom' => 'Lacroix', 'prenom' => 'Zoé', 'semestre' => 3, 'groupe' => 'G2'],
            
            ['email' => 'lucas.brun@student.example.edu', 'nom' => 'Brun', 'prenom' => 'Lucas', 'semestre' => 4, 'groupe' => 'G1'],
            ['email' => 'anais.boyer@student.example.edu', 'nom' => 'Boyer', 'prenom' => 'Anaïs', 'semestre' => 4, 'groupe' => 'G1'],
            ['email' => 'nicolas.gautier@student.example.edu', 'nom' => 'Gautier', 'prenom' => 'Nicolas', 'semestre' => 4, 'groupe' => 'G2'],
            ['email' => 'lucie.petit@student.example.edu', 'nom' => 'Petit', 'prenom' => 'Lucie', 'semestre' => 4, 'groupe' => 'G2'],
            
            ['email' => 'julie.meunier@student.example.edu', 'nom' => 'Meunier', 'prenom' => 'Julie', 'semestre' => 5, 'groupe' => 'G1'],
            ['email' => 'quentin.hamel@student.example.edu', 'nom' => 'Hamel', 'prenom' => 'Quentin', 'semestre' => 5, 'groupe' => 'G1'],
            ['email' => 'eva.roux@student.example.edu', 'nom' => 'Roux', 'prenom' => 'Eva', 'semestre' => 5, 'groupe' => 'G2'],
            ['email' => 'remi.colin@student.example.edu', 'nom' => 'Colin', 'prenom' => 'Rémi', 'semestre' => 5, 'groupe' => 'G2'],
            
            ['email' => 'paul.mercier@student.example.edu', 'nom' => 'Mercier', 'prenom' => 'Paul', 'semestre' => 6, 'groupe' => 'G1'],
            ['email' => 'celine.fabre@student.example.edu', 'nom' => 'Fabre', 'prenom' => 'Céline', 'semestre' => 6, 'groupe' => 'G1'],
            ['email' => 'antoine.lefevre@student.example.edu', 'nom' => 'Lefèvre', 'prenom' => 'Antoine', 'semestre' => 6, 'groupe' => 'G2'],
            ['email' => 'isabelle.morel@student.example.edu', 'nom' => 'Morel', 'prenom' => 'Isabelle', 'semestre' => 6, 'groupe' => 'G2'],
        ];

        $this->db->table('eleve')->insertBatch($data);
    }
}