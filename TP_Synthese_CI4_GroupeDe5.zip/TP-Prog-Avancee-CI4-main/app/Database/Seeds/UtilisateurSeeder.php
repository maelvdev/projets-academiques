<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UtilisateurSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'email' => 'alice.dupont@example.edu',
                'mot_de_passe' => hash('sha256', 'AlicePass2025!'),
                'role' => 'enseignant',
                'nom' => 'Dupont',
                'prenom' => 'Alice',
                'compte_valide' => true,
            ],
            [
                'email' => 'bruno.martin@example.edu',
                'mot_de_passe' => hash('sha256', 'BrunoPass2025!'),
                'role' => 'enseignant',
                'nom' => 'Martin',
                'prenom' => 'Bruno',
                'compte_valide' => true,
            ],
            [
                'email' => 'celine.lefevre@example.edu',
                'mot_de_passe' => hash('sha256', 'CelinePass2025!'),
                'role' => 'enseignant',
                'nom' => 'Lefevre',
                'prenom' => 'Céline',
                'compte_valide' => true,
            ],
            [
                'email' => 'damien.roche@example.edu',
                'mot_de_passe' => hash('sha256', 'DamienPass2025!'),
                'role' => 'enseignant',
                'nom' => 'Roche',
                'prenom' => 'Damien',
                'compte_valide' => true,
            ],
            [
                'email' => 'emma.moreau@example.edu',
                'mot_de_passe' => hash('sha256', 'EmmaPass2025!'),
                'role' => 'enseignant',
                'nom' => 'Moreau',
                'prenom' => 'Emma',
                'compte_valide' => true,
            ],
            [
                'email' => 'fabrice.girard@example.edu',
                'mot_de_passe' => hash('sha256', 'FabricePass2025!'),
                'role' => 'enseignant',
                'nom' => 'Girard',
                'prenom' => 'Fabrice',
                'compte_valide' => true,
            ],
            [
                'email' => 'gaelle.perrin@example.edu',
                'mot_de_passe' => hash('sha256', 'GaellePass2025!'),
                'role' => 'enseignant',
                'nom' => 'Perrin',
                'prenom' => 'Gaëlle',
                'compte_valide' => true,
            ],
            [
                'email' => 'hugo.leblanc@example.edu',
                'mot_de_passe' => hash('sha256', 'HugoPass2025!'),
                'role' => 'enseignant',
                'nom' => 'Leblanc',
                'prenom' => 'Hugo',
                'compte_valide' => true,
            ],
            [
                'email' => 'directeur@example.edu',
                'mot_de_passe' => hash('sha256', 'DirecteurPass2025!'),
                'role' => 'directeur',
                'nom' => 'Admin',
                'prenom' => 'Directeur',
                'compte_valide' => true,
            ],
        ];

        $this->db->table('utilisateur')->insertBatch($data);
    }
}