<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class RessourceSeeder extends Seeder
{
    public function run()
    {
        $data = [
            // Semestre 1
            ['nom' => 'R1.01 - Initiation au développement', 'semestre' => 1],
            ['nom' => 'R1.02 - Développement d\'interfaces web', 'semestre' => 1],
            ['nom' => 'R1.03 - Introduction à l\'architecture des ordinateurs', 'semestre' => 1],
            ['nom' => 'R1.04 - Introduction aux bases de données', 'semestre' => 1],
            ['nom' => 'R1.05 - Introduction aux réseaux informatiques', 'semestre' => 1],
            ['nom' => 'R1.06 - Mathématiques discrètes', 'semestre' => 1],
            ['nom' => 'R1.07 - Outils mathématiques fondamentaux', 'semestre' => 1],
            ['nom' => 'R1.08 - Gestion de projet & des organisations', 'semestre' => 1],
            ['nom' => 'R1.09 - Économie durable et numérique', 'semestre' => 1],
            ['nom' => 'R1.10 - Anglais professionnel', 'semestre' => 1],
            ['nom' => 'R1.11 - Bases de la communication', 'semestre' => 1],
            ['nom' => 'R1.12 - Projet professionnel et personnel', 'semestre' => 1],
            
            // Semestre 2
            ['nom' => 'R2.01 - Développement orienté objets', 'semestre' => 2],
            ['nom' => 'R2.02 - Développement d\'applications avec IHM', 'semestre' => 2],
            ['nom' => 'R2.03 - Qualité de développement', 'semestre' => 2],
            ['nom' => 'R2.04 - Communication et fonctionnement bas niveau', 'semestre' => 2],
            ['nom' => 'R2.05 - Introduction aux services réseaux', 'semestre' => 2],
            ['nom' => 'R2.06 - Exploitation d\'une base de données', 'semestre' => 2],
            ['nom' => 'R2.07 - Graphes', 'semestre' => 2],
            ['nom' => 'R2.08 - Outils numériques pour les statistiques descriptives', 'semestre' => 2],
            ['nom' => 'R2.09 - Méthodes numériques', 'semestre' => 2],
            ['nom' => 'R2.10 - Gestion de projet et des organisations', 'semestre' => 2],
            ['nom' => 'R2.11 - Droit des contrats et du numérique', 'semestre' => 2],
            ['nom' => 'R2.12 - Anglais professionnel', 'semestre' => 2],
            
            // Semestre 3
            ['nom' => 'R3.01 - Développement web', 'semestre' => 3],
            ['nom' => 'R3.02 - Développement d\'applications réparties', 'semestre' => 3],
            ['nom' => 'R3.03 - Analyse et modélisation', 'semestre' => 3],
            ['nom' => 'R3.04 - Qualité de développement', 'semestre' => 3],
            ['nom' => 'R3.05 - Programmation système', 'semestre' => 3],
            ['nom' => 'R3.06 - Architecture des réseaux', 'semestre' => 3],
            ['nom' => 'R3.07 - SQL dans un système de gestion de bases de données', 'semestre' => 3],
            ['nom' => 'R3.08 - Probabilités', 'semestre' => 3],
            ['nom' => 'R3.09 - Cryptographie et sécurité', 'semestre' => 3],
            ['nom' => 'R3.10 - Management des systèmes d\'information', 'semestre' => 3],
            ['nom' => 'R3.11 - Droit des services numériques', 'semestre' => 3],
            ['nom' => 'R3.12 - Anglais professionnel', 'semestre' => 3],
            
            // Semestre 4
            ['nom' => 'R4.01 - Architecture logicielle', 'semestre' => 4],
            ['nom' => 'R4.02 - Qualité de développement', 'semestre' => 4],
            ['nom' => 'R4.03 - Qualité et non-relationnel', 'semestre' => 4],
            ['nom' => 'R4.04 - Méthodes d\'optimisation pour l\'aide à la décision', 'semestre' => 4],
            ['nom' => 'R4.05 - Anglais professionnel', 'semestre' => 4],
            ['nom' => 'R4.06 - Communication interne', 'semestre' => 4],
            ['nom' => 'R4.07 - Droit du numérique approfondi', 'semestre' => 4],
            
            // Semestre 5
            ['nom' => 'R5.01 - Développement avancé', 'semestre' => 5],
            ['nom' => 'R5.02 - Qualité algorithmique', 'semestre' => 5],
            ['nom' => 'R5.03 - Programmation fonctionnelle', 'semestre' => 5],
            ['nom' => 'R5.04 - Virtualisation', 'semestre' => 5],
            ['nom' => 'R5.05 - Programmation avancée', 'semestre' => 5],
            ['nom' => 'R5.06 - Sensibilisation à la programmation multimédia', 'semestre' => 5],
            ['nom' => 'R5.07 - Automatisation', 'semestre' => 5],
            ['nom' => 'R5.08 - Qualité de développement', 'semestre' => 5],
            ['nom' => 'R5.09 - Mathématiques pour l\'informatique', 'semestre' => 5],
            ['nom' => 'R5.10 - Anglais professionnel', 'semestre' => 5],
            
            // Semestre 6
            ['nom' => 'R6.01 - Architecture et développement', 'semestre' => 6],
            ['nom' => 'R6.02 - Développement avancé', 'semestre' => 6],
            ['nom' => 'R6.03 - Développement pour applications mobiles', 'semestre' => 6],
            ['nom' => 'R6.04 - Qualité et au-delà du relationnel', 'semestre' => 6],
            ['nom' => 'R6.05 - Mathématiques approfondies', 'semestre' => 6],
            ['nom' => 'R6.06 - Anglais professionnel', 'semestre' => 6],
        ];

        $this->db->table('ressource')->insertBatch($data);
    }
}