<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        // Ordre important : respecter les dépendances entre tables
        $this->call('RessourceSeeder');
        $this->call('UtilisateurSeeder');
        $this->call('EleveSeeder');
        
        // Note : Les tables rattrapage, ds, absence, planification, token_verification
        // ne sont pas peuplées ici car elles seront créées dynamiquement par l'application
    }
}