<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateNotificationTrigger extends Migration
{
    public function up()
    {
        $db = \Config\Database::connect();
        
        // Créer la fonction trigger
        $db->query("
            CREATE OR REPLACE FUNCTION create_notification_on_user_insert()
            RETURNS TRIGGER AS \$\$
            BEGIN
                INSERT INTO notification (email_ens, notif1, notif2)
                VALUES (NEW.email, 1, 1);
                RETURN NEW;
            END;
            \$\$ LANGUAGE plpgsql;
        ");
        
        // Créer le trigger
        $db->query("
            CREATE TRIGGER after_utilisateur_insert
            AFTER INSERT ON utilisateur
            FOR EACH ROW
            EXECUTE FUNCTION create_notification_on_user_insert();
        ");
    }

    public function down()
    {
        $db = \Config\Database::connect();
        
        // Supprimer le trigger
        $db->query("DROP TRIGGER IF EXISTS after_utilisateur_insert ON utilisateur");
        
        // Supprimer la fonction
        $db->query("DROP FUNCTION IF EXISTS create_notification_on_user_insert()");
    }
}