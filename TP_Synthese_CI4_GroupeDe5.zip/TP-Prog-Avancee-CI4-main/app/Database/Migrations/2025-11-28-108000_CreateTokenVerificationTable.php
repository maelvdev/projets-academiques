<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateTokenVerificationTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'SERIAL',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'token_hash' => [
                'type'       => 'VARCHAR',
                'constraint' => '128',
                'unique'     => true,
            ],
            'email_utilisateur' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
            ],
            'date_creation' => [
                'type'    => 'TIMESTAMP',
                'default' => 'CURRENT_TIMESTAMP',
            ],
            'date_expiration' => [
                'type' => 'TIMESTAMP',
            ],
            'type' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
                'default'    => 'verification',
            ],
        ]);

        $this->forge->addKey('id', true);
        
        $this->forge->addForeignKey(
            'email_utilisateur',
            'utilisateur',
            'email',
            'CASCADE',
            'CASCADE'
        );

        $this->forge->createTable('token_verification');
        
        // Créer un index sur date_expiration pour les performances
        $db = \Config\Database::connect();
        $db->query("CREATE INDEX idx_token_verif_expiration ON token_verification(date_expiration)");
    }

    public function down()
    {
        $this->forge->dropTable('token_verification');
    }
}