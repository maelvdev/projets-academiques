<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateRattrapageTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id_rattrapage' => [
                'type'           => 'SERIAL',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'mail_enseignant' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
            ],
            'id_ressource' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'date' => [
                'type' => 'DATE',
            ],
            'semestre' => [
                'type' => 'INT',
            ],
        ]);

        $this->forge->addKey('id_rattrapage', true);
        
        $this->forge->addForeignKey(
            'mail_enseignant',
            'utilisateur',
            'email',
            'RESTRICT',
            'RESTRICT'
        );
        
        $this->forge->addForeignKey(
            'id_ressource',
            'ressource',
            'id_ressource',
            'RESTRICT',
            'RESTRICT'
        );

        $this->forge->createTable('rattrapage');
        
        // Ajouter la contrainte CHECK pour le semestre
        $db = \Config\Database::connect();
        $db->query("ALTER TABLE rattrapage ADD CONSTRAINT chk_rattrapage_semestre CHECK (semestre BETWEEN 1 AND 6)");
    }

    public function down()
    {
        $this->forge->dropTable('rattrapage');
    }
}