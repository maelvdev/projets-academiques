<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateUtilisateurTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'email' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
            ],
            'mot_de_passe' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'role' => [
                'type'       => 'VARCHAR',
                'constraint' => '20',
            ],
            'nom' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
            ],
            'prenom' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
            ],
            'compte_valide' => [
                'type'    => 'BOOLEAN',
                'default' => false,
            ],
        ]);

        $this->forge->addKey('email', true);
        
        // Ajouter une contrainte CHECK pour le rôle (PostgreSQL)
        $this->forge->createTable('utilisateur');
        
        // Ajouter la contrainte CHECK après création de la table
        $db = \Config\Database::connect();
        $db->query("ALTER TABLE utilisateur ADD CONSTRAINT chk_role CHECK (role IN ('directeur', 'enseignant'))");
    }

    public function down()
    {
        $this->forge->dropTable('utilisateur');
    }
}