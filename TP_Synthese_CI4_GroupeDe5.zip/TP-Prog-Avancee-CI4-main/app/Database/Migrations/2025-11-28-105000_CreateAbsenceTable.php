<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateAbsenceTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'email_etud' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
            ],
            'id_rattrapage' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'justifie' => [
                'type'    => 'SMALLINT',
                'default' => 0,
            ],
        ]);

        $this->forge->addKey(['email_etud', 'id_rattrapage'], true);
        
        $this->forge->addForeignKey(
            'email_etud',
            'eleve',
            'email',
            'CASCADE',
            'CASCADE'
        );
        
        $this->forge->addForeignKey(
            'id_rattrapage',
            'rattrapage',
            'id_rattrapage',
            'RESTRICT',
            'RESTRICT'
        );

        $this->forge->createTable('absence');
    }

    public function down()
    {
        $this->forge->dropTable('absence');
    }
}