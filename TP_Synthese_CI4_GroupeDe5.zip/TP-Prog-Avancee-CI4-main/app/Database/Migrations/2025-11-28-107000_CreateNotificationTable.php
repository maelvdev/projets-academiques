<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateNotificationTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id_notif' => [
                'type'           => 'SERIAL',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'email_ens' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
            ],
            'notif1' => [
                'type'    => 'SMALLINT',
                'default' => 0,
            ],
            'notif2' => [
                'type'    => 'SMALLINT',
                'default' => 0,
            ],
        ]);

        $this->forge->addKey('id_notif', true);
        
        $this->forge->addForeignKey(
            'email_ens',
            'utilisateur',
            'email',
            'CASCADE',
            'CASCADE'
        );

        $this->forge->createTable('notification');
    }

    public function down()
    {
        $this->forge->dropTable('notification');
    }
}