<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateRessourceTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id_ressource' => [
                'type'           => 'SERIAL',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'nom' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
                'unique'     => true,
            ],
            'semestre' => [
                'type' => 'INT',
            ],
        ]);

        $this->forge->addKey('id_ressource', true);
        $this->forge->createTable('ressource');
        
        // Ajouter la contrainte CHECK pour le semestre
        $db = \Config\Database::connect();
        $db->query("ALTER TABLE ressource ADD CONSTRAINT chk_semestre CHECK (semestre BETWEEN 1 AND 6)");
    }

    public function down()
    {
        $this->forge->dropTable('ressource');
    }
}