<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateDsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id_ds' => [
                'type'           => 'SERIAL',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'date' => [
                'type' => 'DATE',
            ],
            'id_ressource' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'semestre' => [
                'type' => 'INT',
            ],
            'mail_enseignant' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
            ],
            'type_ds' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
            ],
            'duree' => [
                'type' => 'INT',
            ],
        ]);

        $this->forge->addKey('id_ds', true);
        
        $this->forge->addForeignKey(
            'mail_enseignant',
            'utilisateur',
            'email',
            'RESTRICT',
            'RESTRICT'
        );
        
        $this->forge->addForeignKey(
            'id_ressource',
            'ressource',
            'id_ressource',
            'RESTRICT',
            'RESTRICT'
        );

        $this->forge->createTable('ds');
        
        // Ajouter les contraintes CHECK
        $db = \Config\Database::connect();
        $db->query("ALTER TABLE ds ADD CONSTRAINT chk_ds_semestre CHECK (semestre BETWEEN 1 AND 6)");
        $db->query("ALTER TABLE ds ADD CONSTRAINT chk_type_ds CHECK (type_ds IN ('DS Table', 'DS Machine'))");
    }

    public function down()
    {
        $this->forge->dropTable('ds');
    }
}