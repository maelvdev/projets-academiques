<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePlanificationTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id_rattrapage' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'type' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
            ],
            'date' => [
                'type' => 'DATE',
                'null' => true,
            ],
            'heure_debut' => [
                'type' => 'TIME',
                'null' => true,
            ],
            'heure_fin' => [
                'type' => 'TIME',  
                'null' => true,
            ],
            'duree' => [
                'type' => 'INT',
                'null' => true,
            ],
            'plage_horraire' => [
                'type'       => 'VARCHAR',
                'constraint' => '20',
                'null'       => true,
            ],
            'salle' => [
                'type'       => 'VARCHAR',
                'constraint' => '20',
                'null'       => true,
            ],
            'commentaire' => [
                'type' => 'TEXT',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id_rattrapage', true);
        
        $this->forge->addForeignKey(
            'id_rattrapage',
            'rattrapage',
            'id_rattrapage',
            'CASCADE',
            'CASCADE'
        );

        $this->forge->createTable('planification');
        
        // Ajouter la contrainte CHECK pour le type
        $db = \Config\Database::connect();
        $db->query("ALTER TABLE planification ADD CONSTRAINT chk_planification_type CHECK (type IN ('annulé', 'planifié', 'en attente'))");
    }

    public function down()
    {
        $this->forge->dropTable('planification');
    }
}