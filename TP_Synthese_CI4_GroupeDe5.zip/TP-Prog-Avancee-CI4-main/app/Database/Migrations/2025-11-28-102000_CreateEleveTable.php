<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateEleveTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'email' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
            ],
            'nom' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
            ],
            'prenom' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
            ],
            'semestre' => [
                'type' => 'INT',
            ],
            'groupe' => [
                'type'       => 'VARCHAR',
                'constraint' => '20',
                'null'       => true,
                'default'    => null,
            ],
        ]);

        $this->forge->addKey('email', true);
        $this->forge->createTable('eleve');
        
        // Ajouter la contrainte CHECK pour le semestre
        $db = \Config\Database::connect();
        $db->query("ALTER TABLE eleve ADD CONSTRAINT chk_eleve_semestre CHECK (semestre BETWEEN 1 AND 6)");
    }

    public function down()
    {
        $this->forge->dropTable('eleve');
    }
}