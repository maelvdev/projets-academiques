<?= $this->extend('layouts/root_layout') ?>

<?= $this->section('root_content') ?>

<?php 
$activePage = $active_page ?? 'Accueil'; 
$session = session();
// On récupère le rôle soit de la variable passée à la vue, soit de la session
$role = $role ?? $session->get('role');
?>


    <aside class="fixed top-0 left-0 h-full w-64 bg-sidebar text-sidebar-foreground flex flex-col z-50 shadow-xl border-r border-sidebar-border">

        <div class="p-6 border-b border-sidebar-border">
            <h1 class="text-xl font-bold tracking-wide">SGRDS</h1>
            <p class="text-sm text-white/50 mt-1">Gestion Rattrapages</p>
        </div>

        <nav class="flex-1 p-4 space-y-2 overflow-y-auto">

            <a href="<?= site_url('accueil') ?>" class="flex items-center gap-3 px-4 py-3 <?= $activePage === 'dashboard' ? 'bg-accent' : 'hover:bg-accent/20' ?> rounded-lg transition-colors group" draggable="false">
                <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
                <span class="font-medium">Tableau de bord</span>
            </a>

            <?php if (strcasecmp(trim($role), 'directeur') === 0): ?>
                <a href="<?= site_url('gestion_rattrapage',) ?>" class="flex items-center gap-3 px-4 py-3 hover:bg-accent hover:text-accent-foreground <?= $activePage === 'gestion_rattrapage' ? 'bg-accent' : 'hover:bg-accent/20' ?> rounded-lg transition-colors" draggable="false">
                    <i data-lucide="file-signature" class="w-5 h-5"></i>
                    <span class="font-medium">Gestion des rattrapages</span>
                </a>

                <a href="<?= site_url('etudiants',) ?>" class="flex items-center gap-3 px-4 py-3 hover:bg-accent hover:text-accent-foreground <?= $activePage === 'gestion_etudiants' ? 'bg-accent' : 'hover:bg-accent/20' ?> rounded-lg transition-colors" draggable="false">
                    <i data-lucide="users" class="w-5 h-5"></i>
                    <span class="font-medium">Étudiants</span>
                </a>

                <a href="<?= site_url('/gestion_utilisateur',) ?>" class="flex items-center gap-3 px-4 py-3 hover:bg-accent hover:text-accent-foreground <?= $activePage === 'gestion_utilisateur' ? 'bg-accent' : 'hover:bg-accent/20' ?> rounded-lg transition-colors" draggable="false">
                    <i data-lucide="user-round-pen" class="w-5 h-5"></i>
                    <span class="font-medium">Gestion des utilisateurs</span>
                </a>

                <a href="<?= site_url('mes_rattrapages',) ?>" class="flex items-center gap-3 px-4 py-3 hover:bg-accent hover:text-accent-foreground <?= $activePage === 'mes_rattrapages' ? 'bg-accent' : 'hover:bg-accent/20' ?> rounded-lg transition-colors">
                    <i data-lucide="file-text" class="w-5 h-5"></i>
                    <span class="font-medium">Mes rattrapages</span>
                </a>
            <?php else: ?>
                <a href="<?= site_url('mes_rattrapages',) ?>" class="flex items-center gap-3 px-4 py-3 hover:bg-accent hover:text-accent-foreground <?= $activePage === 'mes_rattrapages' ? 'bg-accent' : 'hover:bg-accent/20' ?> rounded-lg transition-colors">
                    <i data-lucide="file-text" class="w-5 h-5"></i>
                    <span class="font-medium">Mes rattrapages</span>
                </a>
            <?php endif; ?>
        </nav>

        <div class="p-4 border-t border-sidebar-border bg-sidebar">
            <div class="mb-4 px-2">
                <?php 
                $nom = $session->get('nom') ?? 'Utilisateur';
                $prenom = $session->get('prenom') ?? '';
                $roleAffichage = $session->get('role') ?? 'Invité';
                ?>
                <h3 class="font-bold text-md"><?= esc($nom) . ' ' . esc($prenom) ?></h3>
                <p class="text-sm text-white/50"><?= esc($roleAffichage) ?></p>
            </div>

            <div class="space-y-2">
                <a href="<?= site_url('parametres',) ?>" class="w-full flex items-center gap-2 px-3 py-2 text-md border border-input rounded-md <?= $activePage === 'parametres' ? 'bg-accent text-accent-foreground' : 'hover:bg-accent hover:text-accent-foreground' ?> transition-colors text-left">
                    <i data-lucide="settings" class="w-4 h-4"></i>
                    <span>Paramètres</span>
                </a>

                <a href="<?= site_url('auth/logout',) ?>" class="w-full flex items-center gap-2 px-3 py-2 text-md border border-input rounded-md hover:bg-destructive/30 hover:text-white transition-colors text-left">
                    <i data-lucide="log-out" class="w-4 h-4"></i>
                    <span>Déconnexion</span>
                </a>
            </div>
        </div>
    </aside>

    <main class="pl-100 pr-40 py-8"> <?= $this->renderSection('main_content') ?>
    </main>

<?= $this->endSection() ?>
