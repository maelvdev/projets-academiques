<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'SGRDS') ?></title>
    <link href="<?= base_url('css/styles.css') ?>" rel="stylesheet">
    <link rel="icon" type="image/png" href="<?= base_url('logo.png') ?>">
</head>
<body class="bg-background text-foreground font-sans antialiased min-h-screen flex flex-col">

<div class="fixed top-4 right-4 z-50 w-full max-w-sm space-y-4 pointer-events-none">

    <!-- Succès -->
    <?php if (session()->getFlashdata('success')): ?>
        <div class="pointer-events-auto flex items-center w-full max-w-xs p-4 mb-4 text-green-800 bg-green-50 rounded-lg shadow-lg border border-green-200 animate-in slide-in-from-top-2 duration-300" role="alert">
            <div class="inline-flex items-center justify-center flex-shrink-0 w-8 h-8 text-green-500 bg-green-100 rounded-lg">
                <i data-lucide="check-circle" class="w-5 h-5"></i>
            </div>
            <div class="ms-3 text-sm font-normal"><?= session()->getFlashdata('success') ?></div>
            <button type="button" class="ms-auto -mx-1.5 -my-1.5 bg-green-50 text-green-500 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 hover:bg-green-200 inline-flex items-center justify-center h-8 w-8" data-dismiss-target="#alert-success" aria-label="Close" onclick="this.parentElement.remove()">
                <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        </div>
    <?php endif; ?>

    <!-- Erreur -->
    <?php if (session()->getFlashdata('error')): ?>
        <div class="pointer-events-auto flex items-center w-full max-w-xs p-4 mb-4 text-red-800 bg-red-50 rounded-lg shadow-lg border border-red-200 animate-in slide-in-from-top-2 duration-300" role="alert">
            <div class="inline-flex items-center justify-center flex-shrink-0 w-8 h-8 text-red-500 bg-red-100 rounded-lg">
                <i data-lucide="alert-circle" class="w-5 h-5"></i>
            </div>
            <div class="ms-3 text-sm font-normal"><?= session()->getFlashdata('error') ?></div>
            <button type="button" class="ms-auto -mx-1.5 -my-1.5 bg-red-50 text-red-500 rounded-lg focus:ring-2 focus:ring-red-400 p-1.5 hover:bg-red-200 inline-flex items-center justify-center h-8 w-8" aria-label="Close" onclick="this.parentElement.remove()">
                <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        </div>
    <?php endif; ?>

    <!-- Erreurs de Validation (Liste) -->
    <?php if (session()->getFlashdata('errors')): ?>
        <div class="pointer-events-auto flex flex-col w-full max-w-xs p-4 mb-4 text-red-800 bg-red-50 rounded-lg shadow-lg border border-red-200 animate-in slide-in-from-top-2 duration-300" role="alert">
            <div class="flex items-center mb-2">
                <div class="inline-flex items-center justify-center flex-shrink-0 w-8 h-8 text-red-500 bg-red-100 rounded-lg">
                    <i data-lucide="alert-triangle" class="w-5 h-5"></i>
                </div>
                <div class="ms-3 text-sm font-bold">Veuillez corriger les erreurs :</div>
                <button type="button" class="ms-auto -mx-1.5 -my-1.5 bg-red-50 text-red-500 rounded-lg focus:ring-2 focus:ring-red-400 p-1.5 hover:bg-red-200 inline-flex items-center justify-center h-8 w-8" aria-label="Close" onclick="this.parentElement.parentElement.remove()">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>
            <ul class="list-disc list-inside text-sm ms-2">
                <?php foreach (session()->getFlashdata('errors') as $error): ?>
                    <li><?= esc($error) ?></li>
                <?php endforeach ?>
            </ul>
        </div>
    <?php endif; ?>

</div>

<?= $this->renderSection('root_content') ?>

<script src="https://unpkg.com/lucide@latest"></script>
<script>
    lucide.createIcons();

    setTimeout(() => {
        const alerts = document.querySelectorAll('[role="alert"]');
        alerts.forEach(alert => {
            alert.style.transition = "opacity 0.5s ease";
            alert.style.opacity = "0";
            setTimeout(() => alert.remove(), 500);
        });
    }, 5000);
</script>

</body>
</html>
