<?= $this->extend('layouts/dashboard_layout') ?>

<?= $this->section('main_content') ?>

<div class="max-w-4xl mx-auto">
    <!-- Header -->
    <div class="mb-6">
        <a href="<?= site_url(
            'gestion_rattrapage',
        ) ?>" class="flex items-center text-sm text-blue-600 hover:underline mb-4">
            <i data-lucide="arrow-left" class="w-4 h-4 mr-1"></i>
            Retour aux rattrapages
        </a>
        <div class="flex justify-between items-end">
            <h1 class="text-3xl font-bold text-blue-900">Créer un rattrapage</h1>
            <span class="text-sm text-gray-500" id="step-indicator">Étape 1 sur 4</span>
        </div>
    </div>

    <!-- Form Container -->
    <form id="create-rattrapage-form" class="space-y-6">

        <!-- Step 1: Semestre et Ressource -->
        <div id="step-1" class="bg-white rounded-lg border-2 border-blue-600 p-6 transition-all duration-200">
            <div class="flex items-center gap-3 mb-6">
                <div class="flex items-center justify-center w-8 h-8 rounded-full bg-blue-900 text-white font-bold text-sm">1</div>
                <h2 class="text-lg font-bold text-blue-900">Sélectionner le semestre et la ressource *</h2>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-2">Semestre *</label>
                    <select id="semestre" name="semestre" class="w-full p-2.5 bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                        <option value="">Sélectionnez un semestre</option>
                        <option value="1">Semestre 1</option>
                        <option value="2">Semestre 2</option>
                        <option value="3">Semestre 3</option>
                        <option value="4">Semestre 4</option>
                        <option value="5">Semestre 5</option>
                        <option value="6">Semestre 6</option>
                    </select>
                </div>
                <div class="relative">
                    <label class="block text-sm font-bold text-gray-700 mb-2">Ressource (Matière) *</label>
                    <input type="text" 
                           id="ressource-input" 
                           placeholder="Tapez ou sélectionnez une ressource..." 
                           autocomplete="off"
                           class="w-full p-2.5 bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                           disabled>
                    <input type="hidden" id="ressource" name="id_ressource" value="">
                    
                    <!-- Dropdown des suggestions -->
                    <div id="ressource-dropdown" class="hidden absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-y-auto">
                        <!-- Les suggestions seront ajoutées ici dynamiquement -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Step 2: Informations du DS -->
        <div id="step-2" class="bg-white rounded-lg border border-gray-200 p-6 opacity-50 pointer-events-none transition-all duration-200">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center gap-3">
                    <div class="flex items-center justify-center w-8 h-8 rounded-full bg-gray-400 text-white font-bold text-sm step-number">2</div>
                    <h2 class="text-lg font-bold text-gray-500 step-title">Informations du DS original</h2>
                </div>
                <i data-lucide="lock" class="w-5 h-5 text-gray-400 step-lock"></i>
            </div>

            <div id="step-2-overlay" class="bg-gray-50 rounded-md p-4 mb-6 text-gray-400 text-sm flex items-center gap-2">
                <i data-lucide="lock" class="w-4 h-4"></i>
                Veuillez sélectionner un semestre et une ressource pour continuer
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-2">Date du DS original *</label>
                    <input type="date" id="date_ds" name="date_ds" class="w-full p-2.5 bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" onchange="checkStep2()">
                </div>
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-2">Type de DS *</label>
                    <select id="type_ds" name="type_ds" class="w-full p-2.5 bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                        <option value="">Sélectionnez un type</option>
                        <option value="DS Table">DS Table</option>
                        <option value="DS Machine">DS Machine</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-2">Durée (en minutes) *</label>
                    <input type="number" id="duree" name="duree" min="1" max="300" placeholder="Ex: 120" class="w-full p-2.5 bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                </div>
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-2">Enseignant responsable *</label>
                    <select id="enseignant" name="mail_enseignant" class="w-full p-2.5 bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                        <option value="">Sélectionnez un enseignant</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Step 3: Étudiants -->
        <div id="step-3" class="bg-white rounded-lg border border-gray-200 p-6 opacity-50 pointer-events-none transition-all duration-200">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center gap-3">
                    <div class="flex items-center justify-center w-8 h-8 rounded-full bg-gray-400 text-white font-bold text-sm step-number">3</div>
                    <h2 class="text-lg font-bold text-gray-500 step-title">Ajouter les étudiants absents</h2>
                </div>
                <i data-lucide="lock" class="w-5 h-5 text-gray-400 step-lock"></i>
            </div>

            <div id="step-3-overlay" class="bg-gray-50 rounded-md p-4 mb-6 text-gray-400 text-sm flex items-center gap-2">
                <i data-lucide="lock" class="w-4 h-4"></i>
                Veuillez compléter les informations du DS pour continuer
            </div>

            <!-- Barres de recherche -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Rechercher par nom</label>
                    <div class="relative">
                        <i data-lucide="search" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
                        <input type="text" 
                               id="search-nom" 
                               placeholder="Tapez un nom..." 
                               class="w-full pl-10 p-2.5 bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Rechercher par prénom</label>
                    <div class="relative">
                        <i data-lucide="search" class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"></i>
                        <input type="text" 
                               id="search-prenom" 
                               placeholder="Tapez un prénom..." 
                               class="w-full pl-10 p-2.5 bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                    </div>
                </div>
            </div>

            <div class="bg-gray-50 p-6 rounded-lg border border-gray-200 mb-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="font-bold text-gray-700">Étudiants du semestre</h3>
                    <span id="selected-count" class="text-sm text-blue-600 font-medium">0 sélectionné(s)</span>
                </div>
                <div class="bg-blue-50 border border-blue-200 rounded-md p-3 mb-4 text-xs text-blue-800">
                    <i data-lucide="info" class="w-4 h-4 inline mr-1"></i>
                    Cochez "Absent" pour sélectionner l'étudiant, puis "Justifié" si son absence est justifiée
                </div>
                <div id="students-list-selector" class="space-y-2 max-h-96 overflow-y-auto">
                    <p class="text-sm text-gray-500">Chargement des étudiants...</p>
                </div>
            </div>
            
            <div class="mt-4 flex justify-end">
                 <button type="button" onclick="validateStep3()" class="px-4 py-2 bg-blue-900 text-white rounded-md hover:bg-blue-800 font-medium text-sm">
                    Valider la liste
                </button>
            </div>
        </div>

        <!-- Step 4: Résumé -->
        <div id="step-4" class="bg-white rounded-lg border border-gray-200 p-6 opacity-50 pointer-events-none transition-all duration-200">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center gap-3">
                    <div class="flex items-center justify-center w-8 h-8 rounded-full bg-gray-400 text-white font-bold text-sm step-number">4</div>
                    <h2 class="text-lg font-bold text-gray-500 step-title">Résumé et notification</h2>
                </div>
            </div>

            <div class="bg-gray-50 rounded-lg p-6 mb-6">
                <div class="grid grid-cols-2 gap-y-4 text-sm">
                    <div class="text-gray-500">Ressource</div>
                    <div class="font-medium" id="summary-ressource">-</div>
                    
                    <div class="text-gray-500">Semestre</div>
                    <div class="font-medium" id="summary-semestre">-</div>
                    
                    <div class="text-gray-500">Enseignant</div>
                    <div class="font-medium" id="summary-enseignant">-</div>
                    
                    <div class="text-gray-500">Date originale</div>
                    <div class="font-medium" id="summary-date">-</div>
                    
                    <div class="text-gray-500">Type</div>
                    <div class="font-medium" id="summary-type">-</div>
                    
                    <div class="text-gray-500">Durée</div>
                    <div class="font-medium" id="summary-duree">-</div>
                </div>
            </div>

            <div class="border border-blue-100 bg-blue-50 rounded-lg p-6">
                <div class="flex items-center gap-2 text-blue-800 font-bold mb-4">
                    <i data-lucide="mail" class="w-4 h-4"></i>
                    Email à envoyer
                </div>
                
                <div class="bg-white border border-blue-100 rounded-md p-4 text-sm text-gray-600">
                    <div class="mb-2"><span class="font-bold">À:</span> <span id="email-recipient">Enseignant</span></div>
                    <div class="mb-4"><span class="font-bold">Objet:</span> Rattrapage de <span id="email-subject-resource">...</span></div>
                    
                    <p class="mb-2">Cher Enseignant,</p>
                    <p class="mb-2">Vous trouverez ci-dessous la liste des étudiants absents justifiés pour le rattrapage de : <span id="email-body-resource">...</span></p>
                    <p>Veuillez planifier le rattrapage en conséquence.</p>
                </div>
            </div>

            <div class="mt-6 flex justify-end">
                <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 font-medium flex items-center gap-2">
                    <i data-lucide="send" class="w-4 h-4"></i>
                    Créer et envoyer email
                </button>
            </div>
        </div>

    </form>
</div>

<script>
    // State
    let currentStep = 1;
    let selectedStudents = [];
    let studentsJustification = {}; // Stocke l'état justifié de chaque étudiant {email: true/false}
    let allStudents = [];
    let ressourcesData = {};
    let enseignantsData = [];
    let availableRessources = []; // Liste des ressources disponibles
    let selectedRessourceName = ''; // Nom de la ressource sélectionnée

    // DOM Elements
    const stepIndicator = document.getElementById('step-indicator');
    const semestreSelect = document.getElementById('semestre');
    const ressourceInput = document.getElementById('ressource-input');
    const ressourceHidden = document.getElementById('ressource');
    const ressourceDropdown = document.getElementById('ressource-dropdown');
    const enseignantSelect = document.getElementById('enseignant');

    // Load enseignants on page load
    console.log('Chargement des enseignants...');
    fetch('<?= site_url('rattrapage/get-enseignants') ?>')
        .then(response => {
            console.log('Response enseignants status:', response.status);
            return response.json();
        })
        .then(data => {
            console.log('Data enseignants reçue:', data);
            if (data.enseignants) {
                console.log('Nombre d\'enseignants:', data.enseignants.length);
                enseignantsData = data.enseignants;
                enseignantSelect.innerHTML = '<option value="">Sélectionnez un enseignant</option>';
                data.enseignants.forEach(ens => {
                    const option = document.createElement('option');
                    option.value = ens.email;
                    option.textContent = `${ens.prenom} ${ens.nom}`;
                    enseignantSelect.appendChild(option);
                });
            } else {
                console.log('Aucun enseignant trouvé dans la réponse');
            }
        })
        .catch(error => console.error('Erreur chargement enseignants:', error));

    // Step 1 Logic - Load resources when semestre changes
    semestreSelect.addEventListener('change', function() {
        const selectedSemestre = this.value;
        ressourceInput.value = '';
        ressourceInput.placeholder = 'Chargement...';
        ressourceInput.disabled = true;
        ressourceHidden.value = '';
        ressourceDropdown.classList.add('hidden');
        
        if (selectedSemestre) {
            console.log('Fetching ressources pour semestre:', selectedSemestre);
            fetch(`<?= site_url('rattrapage/get-ressources') ?>?semestre=${selectedSemestre}`)
                .then(response => {
                    console.log('Response status:', response.status);
                    return response.json();
                })
                .then(data => {
                    console.log('Data reçue:', data);
                    if (data.ressources) {
                        console.log('Nombre de ressources:', data.ressources.length);
                        availableRessources = data.ressources;
                        ressourcesData = {};
                        data.ressources.forEach(res => {
                            ressourcesData[res.id_ressource] = res.nom;
                        });
                        ressourceInput.disabled = false;
                        ressourceInput.placeholder = 'Tapez ou sélectionnez une ressource...';
                    } else {
                        console.log('Aucune ressource trouvée');
                        availableRessources = [];
                        ressourceInput.disabled = false;
                        ressourceInput.placeholder = 'Tapez le nom d\'une nouvelle ressource...';
                    }
                })
                .catch(error => {
                    console.error('Erreur chargement ressources:', error);
                    ressourceInput.placeholder = 'Erreur de chargement';
                });
        } else {
            ressourceInput.placeholder = 'Sélectionnez d\'abord un semestre';
        }
        checkStep1();
    });

    // Gestion de l'autocomplétion de la ressource
    ressourceInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase().trim();
        
        if (!searchTerm) {
            ressourceDropdown.classList.add('hidden');
            ressourceHidden.value = '';
            selectedRessourceName = '';
            checkStep1();
            return;
        }

        // Filtrer les ressources correspondantes
        const matches = availableRessources.filter(res => 
            res.nom.toLowerCase().includes(searchTerm)
        );

        // Afficher le dropdown
        ressourceDropdown.innerHTML = '';
        
        if (matches.length > 0) {
            matches.forEach(res => {
                const div = document.createElement('div');
                div.className = 'px-4 py-2 hover:bg-blue-50 cursor-pointer text-sm';
                div.textContent = res.nom;
                div.onclick = () => selectRessource(res.id_ressource, res.nom);
                ressourceDropdown.appendChild(div);
            });
        }
        
        // Toujours ajouter l'option "Créer nouvelle ressource"
        const createDiv = document.createElement('div');
        createDiv.className = 'px-4 py-2 hover:bg-green-50 cursor-pointer text-sm border-t border-gray-200 text-green-700 font-medium flex items-center gap-2';
        createDiv.innerHTML = `
            <i data-lucide="plus-circle" class="w-4 h-4"></i>
            <span>Créer "${this.value}"</span>
        `;
        createDiv.onclick = () => createNewRessource(this.value);
        ressourceDropdown.appendChild(createDiv);
        
        ressourceDropdown.classList.remove('hidden');
        lucide.createIcons();
    });

    // Focus sur l'input pour afficher toutes les ressources
    ressourceInput.addEventListener('focus', function() {
        if (availableRessources.length > 0 && !this.value) {
            ressourceDropdown.innerHTML = '';
            availableRessources.forEach(res => {
                const div = document.createElement('div');
                div.className = 'px-4 py-2 hover:bg-blue-50 cursor-pointer text-sm';
                div.textContent = res.nom;
                div.onclick = () => selectRessource(res.id_ressource, res.nom);
                ressourceDropdown.appendChild(div);
            });
            ressourceDropdown.classList.remove('hidden');
        }
    });

    // Fermer le dropdown si on clique ailleurs
    document.addEventListener('click', function(e) {
        if (!ressourceInput.contains(e.target) && !ressourceDropdown.contains(e.target)) {
            ressourceDropdown.classList.add('hidden');
        }
    });

    function selectRessource(id, nom) {
        ressourceInput.value = nom;
        ressourceHidden.value = id;
        selectedRessourceName = nom;
        ressourceDropdown.classList.add('hidden');
        checkStep1();
    }

    function createNewRessource(nom) {
        if (!nom.trim()) {
            alert('Veuillez saisir un nom de ressource');
            return;
        }

        const semestre = semestreSelect.value;
        if (!semestre) {
            alert('Veuillez d\'abord sélectionner un semestre');
            return;
        }

        // Créer la nouvelle ressource via AJAX
        const formData = new FormData();
        formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
        formData.append('nom', nom.trim());
        formData.append('semestre', semestre);

        fetch('<?= site_url('rattrapage/create-ressource') ?>', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Ajouter la nouvelle ressource à la liste
                const newRessource = {
                    id_ressource: data.id_ressource,
                    nom: nom.trim()
                };
                availableRessources.push(newRessource);
                ressourcesData[data.id_ressource] = nom.trim();
                
                // Sélectionner automatiquement la nouvelle ressource
                selectRessource(data.id_ressource, nom.trim());
                
                alert('Ressource créée avec succès !');
            } else {
                alert(data.message || 'Erreur lors de la création de la ressource');
            }
        })
        .catch(error => {
            console.error('Erreur:', error);
            alert('Erreur lors de la création de la ressource');
        });
    }

    ressourceInput.addEventListener('change', checkStep1);

    ressourceInput.addEventListener('change', checkStep1);

    function activateStep(stepId) {
        const step = document.getElementById(stepId);
        step.classList.remove('opacity-50', 'pointer-events-none', 'border-gray-200');
        step.classList.add('border-2', 'border-blue-600');
        
        // Update header
        const number = step.querySelector('.step-number');
        if(number) {
            number.classList.remove('bg-gray-400');
            number.classList.add('bg-blue-900');
        }
        
        const title = step.querySelector('.step-title');
        if(title) {
            title.classList.remove('text-gray-500');
            title.classList.add('text-blue-900');
        }

        const lock = step.querySelector('.step-lock');
        if(lock) lock.classList.add('hidden');

        const overlay = step.querySelector('[id$="-overlay"]');
        if(overlay) overlay.classList.add('hidden');
        
        // Update global indicator
        const stepNum = stepId.split('-')[1];
        stepIndicator.textContent = `Étape ${stepNum} sur 4`;
    }

    function checkStep1() {
        if (semestreSelect.value && ressourceHidden.value) {
            activateStep('step-2');
            updateSummary();
        }
    }

    ['date_ds', 'type_ds', 'duree', 'enseignant'].forEach(id => {
        document.getElementById(id)?.addEventListener('change', checkStep2);
        document.getElementById(id)?.addEventListener('input', checkStep2);
    });

    function checkStep2() {
        const date = document.getElementById('date_ds').value;
        const type = document.getElementById('type_ds').value;
        const duree = document.getElementById('duree').value;
        const enseignant = document.getElementById('enseignant').value;

        if (date && type && duree && enseignant && parseInt(duree) > 0) {
            activateStep('step-3');
            loadStudents();
            updateSummary();
        }
    }

    function loadStudents() {
        const semestre = semestreSelect.value;
        if (!semestre) return;

        const listContainer = document.getElementById('students-list-selector');
        listContainer.innerHTML = '<p class="text-sm text-gray-500">Chargement des étudiants...</p>';

        console.log('Fetching étudiants pour semestre:', semestre);
        fetch(`<?= site_url('rattrapage/get-etudiants') ?>?semestre=${semestre}`)
            .then(response => {
                console.log('Response étudiants status:', response.status);
                return response.json();
            })
            .then(data => {
                console.log('Data étudiants reçue:', data);
                if (data.etudiants && data.etudiants.length > 0) {
                    console.log('Nombre d\'étudiants:', data.etudiants.length);
                    allStudents = data.etudiants;
                    renderStudentsList();
                } else {
                    console.log('Aucun étudiant trouvé ou data.etudiants est vide');
                    listContainer.innerHTML = '<p class="text-sm text-gray-500">Aucun étudiant trouvé pour ce semestre</p>';
                }
            })
            .catch(error => {
                console.error('Erreur chargement étudiants:', error);
                listContainer.innerHTML = '<p class="text-sm text-red-500">Erreur de chargement des étudiants</p>';
            });
    }

    function renderStudentsList() {
        const listContainer = document.getElementById('students-list-selector');
        const searchNom = document.getElementById('search-nom')?.value.toLowerCase() || '';
        const searchPrenom = document.getElementById('search-prenom')?.value.toLowerCase() || '';
        
        // Filtrer les étudiants
        const filteredStudents = allStudents.filter(student => {
            const matchNom = student.nom.toLowerCase().includes(searchNom);
            const matchPrenom = student.prenom.toLowerCase().includes(searchPrenom);
            return matchNom && matchPrenom;
        });

        listContainer.innerHTML = '';

        if (filteredStudents.length === 0) {
            listContainer.innerHTML = '<p class="text-sm text-gray-500 text-center py-4">Aucun étudiant trouvé</p>';
            return;
        }

        filteredStudents.forEach(student => {
            const div = document.createElement('div');
            div.className = 'grid grid-cols-12 items-center gap-3 p-2 hover:bg-gray-100 rounded transition-colors';
            const isChecked = selectedStudents.includes(student.email);
            const isJustified = studentsJustification[student.email] || false;
            div.innerHTML = `
                <div class="col-span-6 flex items-center gap-2">
                    <input type="checkbox" 
                           id="student-${student.email}" 
                           value="${student.email}" 
                           ${isChecked ? 'checked' : ''}
                           class="student-checkbox w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                           onchange="updateStudentSelection()">
                    <label for="student-${student.email}" class="text-sm text-gray-700 cursor-pointer">
                        ${student.nom} ${student.prenom}
                    </label>
                </div>
                <div class="col-span-6 flex items-center gap-2 ${isChecked ? '' : 'opacity-50'}">
                    <input type="checkbox" 
                           id="justified-${student.email}" 
                           value="${student.email}" 
                           ${isJustified ? 'checked' : ''}
                           ${isChecked ? '' : 'disabled'}
                           class="justify-checkbox w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                           onchange="updateJustification('${student.email}', this.checked)">
                    <label for="justified-${student.email}" class="text-sm text-gray-600 cursor-pointer flex items-center gap-1">
                        <i data-lucide="check-circle" class="w-4 h-4 ${isJustified ? 'text-green-600' : 'text-gray-400'}"></i>
                        Justifié
                    </label>
                </div>
            `;
            listContainer.appendChild(div);
        });

        // Réinitialiser les icônes Lucide
        lucide.createIcons();
    }

    function updateStudentSelection() {
        const checkboxes = document.querySelectorAll('.student-checkbox:checked');
        selectedStudents = Array.from(checkboxes).map(cb => cb.value);
        
        // Mettre à jour le compteur
        const countElement = document.getElementById('selected-count');
        if (countElement) {
            countElement.textContent = `${selectedStudents.length} sélectionné(s)`;
        }
        
        // Activer/désactiver les cases "Justifié" en fonction de la sélection
        document.querySelectorAll('.student-checkbox').forEach(checkbox => {
            const email = checkbox.value;
            const justifyCheckbox = document.getElementById(`justified-${email}`);
            const justifyContainer = justifyCheckbox?.parentElement;
            
            if (checkbox.checked) {
                justifyCheckbox.disabled = false;
                justifyContainer?.classList.remove('opacity-50');
            } else {
                justifyCheckbox.disabled = true;
                justifyCheckbox.checked = false;
                justifyContainer?.classList.add('opacity-50');
                studentsJustification[email] = false;
            }
        });
        
        lucide.createIcons();
    }
    
    function updateJustification(email, isJustified) {
        studentsJustification[email] = isJustified;
        
        // Mettre à jour l'icône visuellement
        const icon = document.querySelector(`#justified-${email} + label i`);
        if (icon) {
            if (isJustified) {
                icon.classList.remove('text-gray-400');
                icon.classList.add('text-green-600');
            } else {
                icon.classList.remove('text-green-600');
                icon.classList.add('text-gray-400');
            }
        }
    }

    // Ajouter les listeners de recherche
    function initSearchListeners() {
        const searchNom = document.getElementById('search-nom');
        const searchPrenom = document.getElementById('search-prenom');
        
        if (searchNom) {
            searchNom.addEventListener('input', renderStudentsList);
        }
        if (searchPrenom) {
            searchPrenom.addEventListener('input', renderStudentsList);
        }
    }

    // Initialiser les listeners après le chargement des étudiants
    function loadStudents() {
        const semestre = semestreSelect.value;
        if (!semestre) return;

        const listContainer = document.getElementById('students-list-selector');
        listContainer.innerHTML = '<p class="text-sm text-gray-500">Chargement des étudiants...</p>';

        console.log('Fetching étudiants pour semestre:', semestre);
        fetch(`<?= site_url('rattrapage/get-etudiants') ?>?semestre=${semestre}`)
            .then(response => {
                console.log('Response étudiants status:', response.status);
                return response.json();
            })
            .then(data => {
                console.log('Data étudiants reçue:', data);
                if (data.etudiants && data.etudiants.length > 0) {
                    console.log('Nombre d\'étudiants:', data.etudiants.length);
                    allStudents = data.etudiants;
                    selectedStudents = []; // Réinitialiser la sélection
                    studentsJustification = {}; // Réinitialiser les justifications
                    renderStudentsList();
                    initSearchListeners();
                } else {
                    console.log('Aucun étudiant trouvé ou data.etudiants est vide');
                    listContainer.innerHTML = '<p class="text-sm text-gray-500">Aucun étudiant trouvé pour ce semestre</p>';
                }
            })
            .catch(error => {
                console.error('Erreur chargement étudiants:', error);
                listContainer.innerHTML = '<p class="text-sm text-red-500">Erreur de chargement des étudiants</p>';
            });
    }
    
    function validateStep3() {
        updateStudentSelection();
        if (selectedStudents.length > 0) {
            activateStep('step-4');
            updateSummary();
        } else {
            alert("Veuillez sélectionner au moins un étudiant absent.");
        }
    }

    function updateSummary() {
        const ressourceId = ressourceHidden.value;
        const ressourceName = selectedRessourceName || ressourcesData[ressourceId] || ressourceInput.value || '-';
        document.getElementById('summary-ressource').textContent = ressourceName;
        
        const semestreVal = semestreSelect.value;
        document.getElementById('summary-semestre').textContent = semestreVal ? `Semestre ${semestreVal}` : '-';
        
        const enseignantText = enseignantSelect.options[enseignantSelect.selectedIndex]?.text;
        document.getElementById('summary-enseignant').textContent = enseignantText !== 'Sélectionnez un enseignant' ? enseignantText : '-';
        document.getElementById('email-recipient').textContent = enseignantText !== 'Sélectionnez un enseignant' ? enseignantText : 'Enseignant';
        
        document.getElementById('summary-date').textContent = document.getElementById('date_ds').value || '-';
        document.getElementById('summary-type').textContent = document.getElementById('type_ds').value || '-';
        
        const dureeVal = document.getElementById('duree').value;
        document.getElementById('summary-duree').textContent = dureeVal ? `${dureeVal} minutes` : '-';
        
        document.getElementById('email-subject-resource').textContent = ressourceName;
        document.getElementById('email-body-resource').textContent = ressourceName;
    }

    // Form submission
    document.getElementById('create-rattrapage-form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        updateStudentSelection();
        
        if (selectedStudents.length === 0) {
            alert('Veuillez sélectionner au moins un étudiant absent');
            return;
        }

        const formData = new FormData();
        formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
        formData.append('semestre', semestreSelect.value);
        formData.append('id_ressource', ressourceHidden.value);
        formData.append('mail_enseignant', enseignantSelect.value);
        formData.append('date_ds', document.getElementById('date_ds').value);
        formData.append('type_ds', document.getElementById('type_ds').value);
        formData.append('duree', document.getElementById('duree').value);
        
        // Préparer les données des étudiants avec leur statut justifié
        const etudiantsData = selectedStudents.map(email => ({
            email: email,
            justifie: studentsJustification[email] ? 1 : 0
        }));
        
        const etudiantsJSON = JSON.stringify(etudiantsData);
        console.log('=== ENVOI FORMULAIRE ===');
        console.log('selectedStudents array:', selectedStudents);
        console.log('studentsJustification:', studentsJustification);
        console.log('etudiantsData à envoyer:', etudiantsData);
        console.log('JSON à envoyer:', etudiantsJSON);
        formData.append('etudiants_absents', etudiantsJSON);

        // Disable submit button
        const submitBtn = e.target.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i data-lucide="loader-2" class="w-4 h-4 animate-spin"></i> Création en cours...';
        lucide.createIcons();

        fetch('<?= site_url('rattrapage/create') ?>', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(data.message || 'Rattrapage créé avec succès !');
                window.location.href = '<?= site_url('gestion_rattrapage') ?>';
            } else {
                alert(data.message || 'Erreur lors de la création du rattrapage');
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i data-lucide="send" class="w-4 h-4"></i> Créer et envoyer email';
                lucide.createIcons();
            }
        })
        .catch(error => {
            console.error('Erreur:', error);
            alert('Erreur lors de la création du rattrapage');
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i data-lucide="send" class="w-4 h-4"></i> Créer et envoyer email';
            lucide.createIcons();
        });
    });

    // Initialize icons
    lucide.createIcons();
</script>

<?= $this->endSection() ?>
