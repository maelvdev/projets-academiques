<?= $this->extend("layouts/dashboard_layout") ?>

<?= $this->section("main_content") ?>

<div class="items-center w-full flex flex-col gap-8">
    <?php if (session()->getFlashdata('success')): ?>
        <div class="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-md">
            <?= session()->getFlashdata('success') ?>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-md">
            <?= session()->getFlashdata('error') ?>
        </div>
    <?php endif; ?>

    <!-- En-tête -->
    <div class="flex justify-between items-center w-full">
        <div>
            <h2 class="text-4xl font-bold text-primary">Gestion des étudiants</h2>
            <p class="text-muted-foreground mt-1"><?= esc(
            	$total ?? 0,
            ) ?> étudiant<?= ($total ?? 0) > 1
 	? "s"
 	: "" ?> trouvé<?= ($total ?? 0) > 1 ? "s" : "" ?></p>
        </div>
        <button onclick="openModal()" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2">
            <i data-lucide="plus" class="w-4 h-4 mr-2"></i>
            Ajouter un étudiant
        </button>
    </div>

    <div class="bg-card rounded-xl shadow-sm border border-border p-4 w-full">
        <div class="flex items-center justify-between mb-3">
            <h3 class="font-semibold text-lg flex items-center gap-2">
                <i data-lucide="filter" class="w-5 h-5 text-primary"></i> Filtres
            </h3>
            <a href="<?= site_url(
            	"etudiants",
            ) ?>" class="text-sm text-slate-600 hover:underline">Réinitialiser</a>
        </div>
        <form method="get" action="<?= site_url('etudiants') ?>" id="filterForm" class="grid grid-cols-1 md:grid-cols-2 gap-3 items-end">
            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Recherche</label>
                <input type="text" name="q" id="searchInput" value="<?= esc(
                	$filters["q"] ?? "",
                ) ?>" placeholder="Nom ou email..." class="w-full rounded-md border border-gray-200 bg-white px-3 py-2" />
            </div>

            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Semestre</label>
                <select name="semestre" class="w-full rounded-md border border-gray-200 bg-white px-3 py-2" onchange="this.form.submit()">
                    <option value="">Tous</option>
                    <option value="S1" <?= isset($filters["semestre"]) &&
                    $filters["semestre"] === "S1"
                    	? "selected"
                    	: "" ?>>S1</option>
                    <option value="S2" <?= isset($filters["semestre"]) &&
                    $filters["semestre"] === "S2"
                    	? "selected"
                    	: "" ?>>S2</option>
                    <option value="S3" <?= isset($filters["semestre"]) &&
                    $filters["semestre"] === "S3"
                    	? "selected"
                    	: "" ?>>S3</option>
                    <option value="S4" <?= isset($filters["semestre"]) &&
                    $filters["semestre"] === "S4"
                    	? "selected"
                    	: "" ?>>S4</option>
                    <option value="S5" <?= isset($filters["semestre"]) &&
                    $filters["semestre"] === "S5"
                    	? "selected"
                    	: "" ?>>S5</option>
                    <option value="S6" <?= isset($filters["semestre"]) &&
                    $filters["semestre"] === "S6"
                    	? "selected"
                    	: "" ?>>S6</option>
                </select>
            </div>
        </form>
    </div>

    <!-- Liste des étudiants (cartes) -->
    <div class="space-y-4 w-full">
        <?php if (!empty($eleves)): ?>
            <?php foreach ($eleves as $e): ?>
                <div class="bg-white rounded-xl p-4 shadow-sm border border-border flex items-start justify-between">
                    <div class="flex-1">
                        <div class="flex items-center gap-3">
                            <div class="p-3 bg-blue-50 rounded-full">
                                <i data-lucide="user" class="w-5 h-5 text-blue-500"></i>
                            </div>
                            <div>
                                <h4 class="text-lg font-semibold text-slate-900"><?= esc(
                                	$e["nom"] ?? "",
                                ) ?> <?= esc($e["prenom"] ?? "") ?></h4>
                                <p class="text-sm text-slate-600 mt-1"><?= esc(
                                	$e["email"] ?? "",
                                ) ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="flex flex-col items-end gap-2">
                        <div class="flex items-center gap-3">
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                                <?= !empty($e['semestre']) ? 'S' . esc($e['semestre']) : 'N/A' ?>
                            </span>
                        </div>

                        <div class="flex items-center gap-2 mt-2">
                            <button onclick='openProfileModal(<?= json_encode($e) ?>)' class="text-sm text-primary hover:underline px-3 py-1">Voir le profil</button>
                            <button onclick='openEditModal(<?= json_encode($e) ?>)' class="text-sm bg-white border border-gray-200 text-primary px-3 py-1 rounded-md hover:bg-accent hover:text-accent-foreground transition-colors">Modifier</button>
                            <button onclick='confirmDelete(<?= json_encode($e["email"]) ?>)' class="text-red-400 hover:text-red-600 p-2" title="Supprimer">
                                <i data-lucide="trash-2" class="w-5 h-5"></i>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="bg-white rounded-xl p-8 shadow-sm border border-border text-center">
                <div class="p-4 bg-slate-50 rounded-full inline-block mb-4">
                    <i data-lucide="users" class="w-8 h-8 text-slate-400"></i>
                </div>
                <h3 class="text-lg font-semibold text-slate-900 mb-2">Aucun étudiant trouvé</h3>
                <p class="text-sm text-muted-foreground">Essayez de modifier vos filtres ou ajoutez un nouvel étudiant.</p>
            </div>
        <?php endif; ?>

        <!-- Pagination -->
        <?php if (! empty($total) && $total > $perPage): ?>
            <?php 
                $pages = ceil($total / $perPage);
                // Build query string preserving filters
                $queryParams = [];
                if (!empty($filters['q'])) $queryParams['q'] = $filters['q'];
                if (!empty($filters['semestre'])) $queryParams['semestre'] = $filters['semestre'];
            ?>
            <div class="flex justify-center items-center gap-2 mt-6">
                <?php if ($page > 1): ?>
                    <?php $queryParams["page"] = $page - 1; ?>
                    <a href="<?= site_url("etudiants") .
                    	"?" .
                    	http_build_query(
                    		$queryParams,
                    	) ?>" class="px-3 py-2 border border-border rounded-md text-sm hover:bg-accent hover:text-accent-foreground transition-colors">
                        <i data-lucide="chevron-left" class="w-4 h-4"></i>
                    </a>
                <?php endif; ?>

                <?php for ($p = 1; $p <= $pages; $p++): ?>
                    <?php $queryParams["page"] = $p; ?>
                    <a href="<?= site_url("etudiants") .
                    	"?" .
                    	http_build_query($queryParams) ?>" 
                       class="px-4 py-2 border rounded-md text-sm transition-colors <?= $p ==
                       $page
                       	? "bg-primary text-primary-foreground"
                       	: "border-border hover:bg-accent hover:text-accent-foreground" ?>">
                        <?= $p ?>
                    </a>
                <?php endfor; ?>

                <?php if ($page < $pages): ?>
                    <?php $queryParams["page"] = $page + 1; ?>
                    <a href="<?= site_url("etudiants") .
                    	"?" .
                    	http_build_query(
                    		$queryParams,
                    	) ?>" class="px-3 py-2 border border-border rounded-md text-sm hover:bg-accent hover:text-accent-foreground transition-colors">
                        <i data-lucide="chevron-right" class="w-4 h-4"></i>
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

</div>

<!-- Modal d'ajout d'étudiant -->
<div id="addStudentModal" class="hidden fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50" onclick="closeModalOnBackdrop(event)">
    <div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4" onclick="event.stopPropagation()">
        <div class="flex justify-between items-center p-6 border-b border-gray-200">
            <h3 class="text-xl font-bold text-gray-900">Ajouter un étudiant</h3>
            <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600 transition-colors">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <form action="<?= site_url('etudiants/create') ?>" method="POST" class="p-6 space-y-4">
            <?= csrf_field() ?>

            <div class="space-y-2">
                <label for="email" class="text-sm font-medium text-gray-700">Email <span class="text-red-500">*</span></label>
                <input type="email" id="email" name="email" value="<?= old('email') ?>" required
                    class="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#003d7a] focus:border-transparent">
                <?php if (session('errors.email')): ?>
                    <p class="text-xs text-red-600"><?= session('errors.email') ?></p>
                <?php endif; ?>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div class="space-y-2">
                    <label for="nom" class="text-sm font-medium text-gray-700">Nom <span class="text-red-500">*</span></label>
                    <input type="text" id="nom" name="nom" value="<?= old('nom') ?>" required
                        class="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#003d7a] focus:border-transparent">
                    <?php if (session('errors.nom')): ?>
                        <p class="text-xs text-red-600"><?= session('errors.nom') ?></p>
                    <?php endif; ?>
                </div>

                <div class="space-y-2">
                    <label for="prenom" class="text-sm font-medium text-gray-700">Prénom <span class="text-red-500">*</span></label>
                    <input type="text" id="prenom" name="prenom" value="<?= old('prenom') ?>" required
                        class="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#003d7a] focus:border-transparent">
                    <?php if (session('errors.prenom')): ?>
                        <p class="text-xs text-red-600"><?= session('errors.prenom') ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="space-y-2">
                <label for="semestre" class="text-sm font-medium text-gray-700">Semestre <span class="text-red-500">*</span></label>
                <select id="semestre" name="semestre" required
                    class="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#003d7a] focus:border-transparent">
                    <option value="">Sélectionner...</option>
                    <option value="S1" <?= old('semestre') === 'S1' ? 'selected' : '' ?>>S1</option>
                    <option value="S2" <?= old('semestre') === 'S2' ? 'selected' : '' ?>>S2</option>
                    <option value="S3" <?= old('semestre') === 'S3' ? 'selected' : '' ?>>S3</option>
                    <option value="S4" <?= old('semestre') === 'S4' ? 'selected' : '' ?>>S4</option>
                    <option value="S5" <?= old('semestre') === 'S5' ? 'selected' : '' ?>>S5</option>
                    <option value="S6" <?= old('semestre') === 'S6' ? 'selected' : '' ?>>S6</option>
                </select>
                <?php if (session('errors.semestre')): ?>
                    <p class="text-xs text-red-600"><?= session('errors.semestre') ?></p>
                <?php endif; ?>
            </div>

            <div class="bg-blue-50 border border-blue-100 rounded-md p-3 text-sm text-blue-800">
                <p>Tous les champs marqués d'un <span class="text-red-500">*</span> sont obligatoires.</p>
            </div>

            <div class="flex gap-3 pt-4">
                <button type="button" onclick="closeModal()" class="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors">
                    Annuler
                </button>
                <button type="submit" class="flex-1 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors">
                    Ajouter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal de profil étudiant -->
<div id="profileModal" class="hidden fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50" onclick="closeModalOnBackdrop(event, 'profileModal')">
    <div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4" onclick="event.stopPropagation()">
        <div class="flex justify-between items-center p-6 border-b border-gray-200">
            <h3 class="text-xl font-bold text-gray-900">Profil de l'étudiant</h3>
            <button onclick="closeProfileModal()" class="text-gray-400 hover:text-gray-600 transition-colors">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <div class="p-6 space-y-4">
            <div class="flex items-center justify-center mb-4">
                <div class="p-6 bg-blue-50 rounded-full">
                    <i data-lucide="user" class="w-12 h-12 text-blue-500"></i>
                </div>
            </div>

            <div class="space-y-3">
                <div>
                    <label class="text-xs font-medium text-gray-500 uppercase">Nom complet</label>
                    <p id="profile_nom" class="text-lg font-semibold text-gray-900"></p>
                </div>

                <div>
                    <label class="text-xs font-medium text-gray-500 uppercase">Email</label>
                    <p id="profile_email" class="text-sm text-gray-700"></p>
                </div>

                <div>
                    <label class="text-xs font-medium text-gray-500 uppercase">Semestre</label>
                    <p id="profile_semestre" class="text-sm text-gray-700"></p>
                </div>
            </div>

            <div class="pt-4">
                <button onclick="closeProfileModal()" class="w-full px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors">
                    Fermer
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Modal de modification d'étudiant -->
<div id="editStudentModal" class="hidden fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50" onclick="closeModalOnBackdrop(event, 'editStudentModal')">
    <div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4" onclick="event.stopPropagation()">
        <div class="flex justify-between items-center p-6 border-b border-gray-200">
            <h3 class="text-xl font-bold text-gray-900">Modifier l'étudiant</h3>
            <button onclick="closeEditModal()" class="text-gray-400 hover:text-gray-600 transition-colors">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <form action="<?= site_url('etudiants/update') ?>" method="POST" class="p-6 space-y-4">
            <?= csrf_field() ?>
            <input type="hidden" id="edit_original_email" name="original_email">

            <div class="space-y-2">
                <label for="edit_email" class="text-sm font-medium text-gray-700">Email <span class="text-red-500">*</span></label>
                <input type="email" id="edit_email" name="email" required
                    class="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#003d7a] focus:border-transparent">
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div class="space-y-2">
                    <label for="edit_nom" class="text-sm font-medium text-gray-700">Nom <span class="text-red-500">*</span></label>
                    <input type="text" id="edit_nom" name="nom" required
                        class="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#003d7a] focus:border-transparent">
                </div>

                <div class="space-y-2">
                    <label for="edit_prenom" class="text-sm font-medium text-gray-700">Prénom <span class="text-red-500">*</span></label>
                    <input type="text" id="edit_prenom" name="prenom" required
                        class="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#003d7a] focus:border-transparent">
                </div>
            </div>

            <div class="space-y-2">
                <label for="edit_semestre" class="text-sm font-medium text-gray-700">Semestre <span class="text-red-500">*</span></label>
                <select id="edit_semestre" name="semestre" required
                    class="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#003d7a] focus:border-transparent">
                    <option value="">Sélectionner...</option>
                    <option value="S1">S1</option>
                    <option value="S2">S2</option>
                    <option value="S3">S3</option>
                    <option value="S4">S4</option>
                    <option value="S5">S5</option>
                    <option value="S6">S6</option>
                </select>
            </div>

            <div class="flex gap-3 pt-4">
                <button type="button" onclick="closeEditModal()" class="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors">
                    Annuler
                </button>
                <button type="submit" class="flex-1 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors">
                    Enregistrer
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Debounce pour la recherche (attend 500ms après la dernière frappe)
let searchTimeout;
const searchInput = document.getElementById('searchInput');

if (searchInput) {
    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            this.form.submit();
        }, 500);
    });
}

function openModal() {
    document.getElementById('addStudentModal').classList.remove('hidden');
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

function closeModal() {
    document.getElementById('addStudentModal').classList.add('hidden');
}

function closeModalOnBackdrop(event, modalId) {
    if (!modalId) modalId = 'addStudentModal';
    if (event.target.id === modalId) {
        document.getElementById(modalId).classList.add('hidden');
    }
}

// Modal Profil
function openProfileModal(student) {
    document.getElementById('profile_nom').textContent = student.nom + ' ' + student.prenom;
    document.getElementById('profile_email').textContent = student.email;
    document.getElementById('profile_semestre').textContent = student.semestre ? 'S' + student.semestre : 'N/A';
    
    document.getElementById('profileModal').classList.remove('hidden');
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

function closeProfileModal() {
    document.getElementById('profileModal').classList.add('hidden');
}

// Modal Modification
function openEditModal(student) {
    document.getElementById('edit_original_email').value = student.email;
    document.getElementById('edit_email').value = student.email;
    document.getElementById('edit_nom').value = student.nom;
    document.getElementById('edit_prenom').value = student.prenom;
    document.getElementById('edit_semestre').value = student.semestre ? 'S' + student.semestre : '';
    
    document.getElementById('editStudentModal').classList.remove('hidden');
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

function closeEditModal() {
    document.getElementById('editStudentModal').classList.add('hidden');
}

// Suppression avec confirmation
function confirmDelete(email) {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet étudiant ? Cette action est irréversible.')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '<?= site_url('etudiants/delete') ?>';
        
        const csrfInput = document.createElement('input');
        csrfInput.type = 'hidden';
        csrfInput.name = '<?= csrf_token() ?>';
        csrfInput.value = '<?= csrf_hash() ?>';
        form.appendChild(csrfInput);
        
        const emailInput = document.createElement('input');
        emailInput.type = 'hidden';
        emailInput.name = 'email';
        emailInput.value = email;
        form.appendChild(emailInput);
        
        document.body.appendChild(form);
        form.submit();
    }
}

// Ouvrir le modal automatiquement s'il y a des erreurs de validation
<?php if (session('errors') && !session('edit_email')): ?>
window.addEventListener('DOMContentLoaded', function() {
    openModal();
});
<?php endif; ?>

// Ouvrir le modal de modification s'il y a des erreurs de modification
<?php if (session('errors') && session('edit_email')): ?>
window.addEventListener('DOMContentLoaded', function() {
    const student = {
        email: '<?= old('email', session('edit_email')) ?>',
        nom: '<?= old('nom') ?>',
        prenom: '<?= old('prenom') ?>',
        semestre: '<?= old('semestre') ?>'
    };
    openEditModal(student);
});
<?php endif; ?>

// Gérer la touche Escape pour fermer le modal
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeModal();
    }
});
</script>

<?= $this->endSection() ?>
