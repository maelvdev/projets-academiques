<?= $this->extend('layouts/dashboard_layout') ?>

<?= $this->section('content') ?>
    <h2 class="text-xl font-semibold underline">Bienvenue sur la page d'accueil</h2>
    <p class="mt-2">Ceci est du contenu avec Tailwind CSS.</p>
<?= $this->endSection() ?>
