<?= $this->extend('layouts/dashboard_layout') ?>
<?= $this->section('main_content') ?>

<div class="max-w-4xl mx-auto py-8">
    <div class="mb-8">
        <h1 class="text-4xl font-bold text-[#003d7a]">Paramètres</h1>
        <p class="text-gray-700 mt-1">Gérez votre compte et vos préférences</p>
    </div>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-md mb-6">
            <?= session()->getFlashdata('success') ?>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-md mb-6">
            <?= session()->getFlashdata('error') ?>
        </div>
    <?php endif; ?>

    <div class="border-b border-gray-200 mb-8">
        <nav class="-mb-px flex space-x-8" aria-label="Tabs">
            <a href="<?= site_url('parametres/profil') ?>" class="<?= ($active_tab ?? 'profil') === 'profil'
    ? 'border-[#003d7a] text-[#003d7a]'
    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' ?> whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                Profil
            </a>

            <a href="<?= site_url('parametres/mot-de-passe') ?>" class="<?= ($active_tab ?? 'profil') === 'mot-de-passe'
    ? 'border-[#003d7a] text-[#003d7a]'
    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' ?> whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                Mot de passe
            </a>

            <a href="<?= site_url('parametres/notifications') ?>" class="<?= ($active_tab ?? 'profil') ===
'notifications'
    ? 'border-[#003d7a] text-[#003d7a]'
    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' ?> whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                Notifications
            </a>
        </nav>
    </div>

    <div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mb-8">
        <form action="<?= site_url('parametres/notifications') ?>" method="POST" class="p-6 space-y-6">
            <?= csrf_field() ?>
            
            <div class="space-y-6">
                <div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Préférences de notifications</h3>
                    <p class="text-sm text-gray-600 mb-4">Choisissez les notifications que vous souhaitez recevoir par email.</p>
                </div>

                <div class="space-y-4">
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input type="checkbox" id="notif_rattrapages" name="notif_rattrapages" value="1" 
                                <?= !empty($preferences['notif_rattrapages']) ? 'checked' : '' ?>
                                class="w-4 h-4 text-[#003d7a] bg-gray-100 border-gray-300 rounded focus:ring-[#003d7a] focus:ring-2">
                        </div>
                        <div class="ml-3">
                            <label for="notif_rattrapages" class="text-sm font-medium text-gray-700">Notifications de rattrapages</label>
                            <p class="text-xs text-gray-500">Recevez une notification lorsqu'un rattrapage est planifié</p>
                        </div>
                    </div>

                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input type="checkbox" id="notif_modifications" name="notif_modifications" value="1"
                                <?= !empty($preferences['notif_modifications']) ? 'checked' : '' ?>
                                class="w-4 h-4 text-[#003d7a] bg-gray-100 border-gray-300 rounded focus:ring-[#003d7a] focus:ring-2">
                        </div>
                        <div class="ml-3">
                            <label for="notif_modifications" class="text-sm font-medium text-gray-700">Modifications de rattrapages</label>
                            <p class="text-xs text-gray-500">Soyez informé des changements d'horaires ou de salles pour les rattrapages</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-blue-50 border border-blue-100 rounded-md p-4 text-sm text-blue-800">
                Les notifications seront envoyées à votre adresse email universitaire.
            </div>

            <button type="submit" class="w-full bg-primary hover:bg-accent text-white font-medium py-2.5 px-4 rounded-md transition-colors shadow-sm text-sm">
                Enregistrer les préférences
            </button>

        </form>
    </div>

    <div class="bg-red-50 border border-red-100 rounded-lg p-6 space-y-4">
        <div class="flex items-center gap-2 mb-2">
            <i data-lucide="alert-triangle" class="h-5 w-5 text-red-700"></i>
            <h3 class="text-lg font-semibold text-red-900">Zone de danger</h3>
        </div>
        
        <div class="space-y-2">
            <p class="text-sm text-red-700">
                Déconnectez-vous de tous les appareils et sessions actives.
            </p>
            <form action="<?= site_url('parametres/deconnecter-sessions') ?>" method="POST">
                <?= csrf_field() ?>
                <button type="submit" class="w-full bg-red-600 hover:bg-red-700 text-white font-medium py-2.5 px-4 rounded-md transition-colors text-sm">
                    Déconnecter tous les appareils
                </button>
            </form>
        </div>

        <div class="border-t border-red-200 my-4"></div>

        <div class="space-y-2">
             <p class="text-sm text-red-700">
                Supprimer définitivement votre compte et toutes ses données.
            </p>
            <form action="<?= site_url(
                'parametres/supprimer-compte',
            ) ?>" method="POST" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer définitivement votre compte ? Cette action est irréversible.');">
                <?= csrf_field() ?>
                <button type="submit" class="w-full bg-red-600 hover:bg-red-700 text-white font-medium py-2.5 px-4 rounded-md transition-colors text-sm">
                    Supprimer le compte
                </button>
            </form>
        </div>
    </div>

</div>

<script>
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
</script>

<?= $this->endSection() ?>
