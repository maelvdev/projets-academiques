<?php
// HTML view pour erreur 500 avec Tailwind classes
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link href="<?= base_url('css/styles.css') ?>" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>500 - Erreur interne</title>
</head>
<body class="min-h-screen bg-gray-50 flex items-center justify-center p-6">
    <div class="max-w-2xl w-full bg-white rounded-lg shadow-sm border border-gray-100 p-8">
        <div class="flex items-start gap-6">
            <div class="flex-shrink-0">
                <div class="h-14 w-14 rounded-full bg-[#d1433b] text-white flex items-center justify-center text-lg font-semibold">
                    !
                </div>
            </div>

            <div class="flex-1">
                <h1 class="text-2xl md:text-3xl font-semibold text-gray-900">500 — Erreur interne du serveur</h1>
                <p class="mt-2 text-sm text-gray-500"><?php if (isset($message)) {
                    echo nl2br(esc($message));
                } else {
                    echo 'Une erreur est survenue côté serveur.';
                } ?></p>

                <div class="mt-6 flex items-center gap-3">
                    <a href="/" class="inline-flex items-center px-4 py-2 bg-[#1769AA] text-white rounded-md text-sm font-medium hover:bg-[#145f93]">Retour à l'accueil</a>
                    <a href="javascript:location.reload()" class="text-sm text-[#1769AA] hover:underline">Réessayer</a>
                </div>

                <p class="mt-6 text-xs text-gray-400">Si l'erreur persiste, contacte l'administrateur en indiquant l'heure et l'action effectuée.</p>
            </div>
        </div>
    </div>
</body>
</html>
