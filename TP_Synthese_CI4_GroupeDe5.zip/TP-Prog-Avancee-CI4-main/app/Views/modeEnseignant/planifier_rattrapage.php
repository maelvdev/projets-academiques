<?= $this->extend('layouts/dashboard_layout') ?>

<?= $this->section('main_content') ?>

    <section class="container mx-auto p-6 max-w-7xl space-y-6">

        <!-- En-tête -->
        <div class="space-y-4">
            <a href="<?= site_url('mes_rattrapages') ?>" class="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline transition-colors">
                <i data-lucide="arrow-left" class="w-4 h-4"></i>
                Retour à mes rattrapages
            </a>

            <div class="flex items-end justify-between">
                <div class="flex flex-col gap-2">
                    <h1 class="text-4xl font-bold text-primary"><?= esc($rattrapage['ressource']) ?></h1>
                    <p class="text-slate-500 mt-1">Gestion du rattrapage</p>
                </div>
            </div>
        </div>

        <!-- Grid Layout -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">

            <!-- COLONNE GAUCHE -->
            <div class="lg:col-span-8 space-y-6">

                <!-- Carte 1 : Informations du DS Original (Toujours visible) -->
                <div class="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
                    <h2 class="text-xl font-bold text-[#003366] mb-6">Informations du DS original</h2>
                    <div class="grid grid-cols-2 gap-y-6 gap-x-4">
                        <div>
                            <span class="block text-sm text-slate-500 mb-1">Ressource</span>
                            <span class="font-bold text-slate-800"><?= esc($rattrapage['ressource']) ?></span>
                        </div>
                        <div>
                            <span class="block text-sm text-slate-500 mb-1">Semestre</span>
                            <span class="font-bold text-slate-800"><?= esc($rattrapage['semestre']) ?></span>
                        </div>
                        <div>
                            <span class="block text-sm text-slate-500 mb-1">Date du DS</span>
                            <span class="font-bold text-slate-800"><?= date('d/m/Y', strtotime($rattrapage['date_ds_original'])) ?></span>
                        </div>
                        <div>
                            <span class="block text-sm text-slate-500 mb-1">Type</span>
                            <span class="font-bold text-slate-800"><?= esc($rattrapage['type_ds'] ?? 'Non spécifié') ?></span>
                        </div>
                    </div>
                </div>

                <!-- LOGIQUE D'AFFICHAGE -->

                <!-- CAS 1 : Rattrapage DÉJÀ PLANIFIÉ (Validé) -->
                <?php if ($rattrapage['etat'] === 'Programmé'): ?>

                    <div class="bg-green-50 border border-green-200 rounded-xl p-6 shadow-sm">
                        <div class="flex items-start gap-4">
                            <div class="p-2 bg-green-100 rounded-full text-green-700 flex-shrink-0">
                                <i data-lucide="check-circle" class="w-6 h-6"></i>
                            </div>
                            <div class="flex-1">
                                <h2 class="text-xl font-bold text-green-800 mb-2">Rattrapage planifié</h2>
                                <p class="text-green-700 mb-6">Ce rattrapage est correctement enregistré.</p>

                                <div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-6">
                                    <div>
                                        <span class="text-xs font-bold text-green-600 uppercase tracking-wider">Date</span>
                                        <p class="font-semibold text-green-900"><?= date('d/m/Y', strtotime($rattrapage['date_rattrapage'])) ?></p>
                                    </div>
                                    <div>
                                        <span class="text-xs font-bold text-green-600 uppercase tracking-wider">Horaire</span>
                                        <p class="font-semibold text-green-900">
                                            <!-- Utilise la plage horaire si dispo, sinon placeholder -->
                                            <?= esc($rattrapage['plage_horraire'] ?? 'Non spécifié') ?>
                                        </p>
                                    </div>
                                    <div>
                                        <span class="text-xs font-bold text-green-600 uppercase tracking-wider">Salle</span>
                                        <p class="font-semibold text-green-900"><?= esc($rattrapage['salle']) ?></p>
                                    </div>
                                </div>

                                <!-- BOUTON D'ANNULATION (Suppression de la planification) -->
                                <!-- Assurez-vous d'avoir une route 'supprimer' ou 'delete' dans votre contrôleur -->
                                <form action="<?= site_url('planifier_rattrapage/annuler/' . $rattrapage['id']) ?>" method="post" onsubmit="return confirm('Êtes-vous sûr de vouloir annuler cette planification ? Le rattrapage repassera en statut En attente.');">
                                    <button type="submit" class="inline-flex items-center gap-2 px-4 py-2 bg-white border border-red-200 text-red-600 font-semibold rounded-lg hover:bg-red-50 hover:border-red-300 transition-colors shadow-sm">
                                        <i data-lucide="x-circle" class="w-4 h-4"></i>
                                        Annuler la planification
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- CAS 2 : NON PLANIFIÉ (En attente) - Affiche les formulaires -->
                <?php else: ?>

                    <!-- Carte Choix Action -->
                    <div class="bg-slate-100/50 border border-slate-200 rounded-xl p-6 shadow-sm">
                        <p class="text-slate-600 mb-4 font-medium">Que souhaitez-vous faire?</p>
                        <div class="flex flex-col sm:flex-row gap-4">
                            <button type="button" id="btnPlanifier" onclick="switchMode('planifier')"
                                    class="flex-1 font-bold py-3 px-6 rounded-lg shadow-md transition-all active:scale-[0.99] border bg-primary text-white border-primary/80">
                                Planifier un rattrapage
                            </button>

                            <button type="button" id="btnPasRattrapage" onclick="switchMode('pas_rattrapage')"
                                    class="flex-1 font-bold py-3 px-6 rounded-lg shadow-sm border bg-white text-slate-700 border-slate-200 hover:primary/80 transition-colors">
                                Pas de rattrapage
                            </button>
                        </div>
                    </div>

                    <!-- FORMULAIRE A : Planification -->
                    <div id="sectionPlanifier" class="bg-white border border-slate-200 rounded-xl p-6 shadow-sm transition-all duration-300">
                        <h2 class="text-xl font-bold text-[#003366] mb-6">Planifier le rattrapage</h2>

                        <form action="<?= site_url('planifier_rattrapage/planifier/' . $rattrapage['id']) ?>" method="post" class="space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div class="space-y-2">
                                    <label for="date_rattrapage" class="text-sm font-bold text-slate-700">Date du rattrapage *</label>
                                    <input type="date" id="date_rattrapage" name="date_rattrapage" class="flex h-11 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#003366]">
                                </div>
                                <div class="space-y-2">
                                    <label for="horaire" class="text-sm font-bold text-slate-700">Horaire *</label>
                                    <input type="text" id="horaire" name="horaire" placeholder="14:00-17:00" class="flex h-11 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#003366]">
                                </div>
                                <div class="space-y-2">
                                    <label for="salle" class="text-sm font-bold text-slate-700">Salle *</label>
                                    <input type="text" id="salle" name="salle" placeholder="Ex: 718" class="flex h-11 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#003366]">
                                </div>
                                <div class="space-y-2">
                                    <label for="type_rattrapage" class="text-sm font-bold text-slate-700">Type de rattrapage *</label>
                                    <select id="type_rattrapage" name="type_rattrapage" class="flex h-11 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#003366]">
                                        <option value="">Sélectionnez</option>
                                        <option value="DS Table">DS Table</option>
                                        <option value="DS Machine">DS Machine</option>
                                        <option value="Oral">Oral</option>
                                    </select>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <label for="commentaire" class="text-sm font-bold text-slate-700">Commentaires (optionnel)</label>
                                <textarea id="commentaire" name="commentaire" rows="4" placeholder="Ajoutez des informations importantes..." class="flex w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#003366] resize-none"></textarea>
                            </div>
                            <div class="pt-2">
                                <button type="submit" class="w-full bg-primary hover:bg-primary/80 text-white font-bold py-3 rounded-lg shadow-md transition-all active:scale-[0.99]">Planifier</button>
                            </div>
                        </form>
                    </div>

                    <!-- FORMULAIRE B : Pas de Rattrapage (Validation/Justification) -->
                    <div id="sectionPasRattrapage" class="hidden bg-[#FFF5F5] border border-red-200 rounded-xl p-6 shadow-sm transition-all duration-300">

                        <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex gap-3 mb-8">
                            <i data-lucide="alert-circle" class="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5"></i>
                            <div>
                                <h3 class="font-bold text-yellow-800 text-sm">Attention</h3>
                                <p class="text-sm text-yellow-700 mt-1 leading-relaxed">
                                    Vous avez choisi de ne pas organiser de rattrapage. Les étudiants seront notifiés par email de cette décision.
                                </p>
                            </div>
                        </div>

                        <h2 class="text-xl font-bold text-[#003366] mb-6">Justification du non-rattrapage</h2>

                        <form action="<?= site_url('planifier_rattrapage/annuler/' . $rattrapage['id']) ?>" method="post" class="space-y-6">
                            <div class="space-y-2">
                                <label for="raison_annulation" class="text-sm font-bold text-slate-700">Raison du non-rattrapage (optionnel)</label>
                                <textarea id="raison_annulation" name="raison_annulation" rows="5"
                                          placeholder="Expliquez pourquoi vous n'organisez pas de rattrapage (optionnel)..."
                                          class="flex w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#003366] resize-none"></textarea>
                            </div>

                            <div class="pt-2 flex items-center justify-between">
                                <button type="button" onclick="switchMode('planifier')" class="text-slate-500 hover:text-slate-700 text-sm font-medium underline">
                                    Annuler et revenir à la planification
                                </button>
                                <button type="submit" class="bg-primary hover:bg-primary/80 text-white font-bold py-3 px-8 rounded-lg shadow-md transition-all active:scale-[0.99]">
                                    Valider le non-rattrapage
                                </button>
                            </div>
                        </form>
                    </div>

                <?php endif; ?>

            </div>

            <!-- COLONNE DROITE (Étudiants) -->
            <div class="lg:col-span-4 space-y-6">
                <div class="bg-white border border-slate-200 rounded-xl p-6 shadow-sm h-fit sticky top-6">
                    <h2 class="text-xl font-bold text-[#003366] mb-6">Étudiants concernés</h2>
                    <?php if (!empty($rattrapage['etudiants'])): ?>
                        <div class="space-y-3 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
                            <?php foreach ($rattrapage['etudiants'] as $etudiant): ?>
                                <div class="bg-slate-50 rounded-lg p-3 border border-slate-100 flex flex-col gap-1">
                                    <div class="font-bold text-slate-800 text-sm"><?= esc($etudiant['prenom']) ?> <?= esc($etudiant['nom']) ?></div>
                                    <div class="text-xs text-slate-500"><?= strtolower(esc($etudiant['prenom']) . '.' . esc($etudiant['nom'])) ?>@univ.fr</div>
                                    <?php if(isset($etudiant['justifie']) && $etudiant['justifie']): ?>
                                        <div class="mt-1"><span class="inline-flex items-center text-[10px] font-bold text-green-700 bg-green-50 px-2 py-0.5 rounded border border-green-100">Absent justifié</span></div>
                                    <?php else: ?>
                                        <div class="mt-1"><span class="inline-flex items-center text-[10px] font-bold text-red-700 bg-red-50 px-2 py-0.5 rounded border border-red-100">Non justifié</span></div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="mt-6 pt-4 border-t border-slate-100 text-sm text-slate-500 font-medium">Total: <?= count($rattrapage['etudiants']) ?> étudiants</div>
                    <?php else: ?>
                        <div class="text-center py-8 text-slate-400 text-sm italic">Aucun étudiant concerné.</div>
                    <?php endif; ?>
                </div>
            </div>

        </div>

    </section>

<?php if ($rattrapage['etat'] !== 'Programmé'): ?>
    <script>
        function switchMode(mode) {
            const btnPlanifier = document.getElementById('btnPlanifier');
            const btnPasRattrapage = document.getElementById('btnPasRattrapage');
            const sectionPlanifier = document.getElementById('sectionPlanifier');
            const sectionPasRattrapage = document.getElementById('sectionPasRattrapage');

            const activeClass = ['bg-primary', 'text-white', 'border-primary'];
            const inactiveClass = ['bg-white', 'text-slate-700', 'border-slate-200'];

            if (mode === 'planifier') {
                sectionPlanifier.classList.remove('hidden');
                sectionPasRattrapage.classList.add('hidden');

                btnPlanifier.classList.add(...activeClass);
                btnPlanifier.classList.remove(...inactiveClass);

                btnPasRattrapage.classList.add(...inactiveClass);
                btnPasRattrapage.classList.remove(...activeClass);
            } else {
                sectionPlanifier.classList.add('hidden');
                sectionPasRattrapage.classList.remove('hidden');

                btnPasRattrapage.classList.add(...activeClass);
                btnPasRattrapage.classList.remove(...inactiveClass);

                btnPlanifier.classList.add(...inactiveClass);
                btnPlanifier.classList.remove(...activeClass);
            }
        }
    </script>
<?php endif; ?>

<?= $this->endSection() ?>