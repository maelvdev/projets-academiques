<?= $this->extend('layouts/dashboard_layout') ?>

<?= $this->section('main_content') ?>

    <section class="items-center w-full flex flex-col gap-8">
        <div class="flex flex-lig justify-between w-full items-center">
            <div class="flex flex-col gap-2">
                <h2 class="font-bold text-4xl text-primary">Mes rattrapages</h2>
                <span class="text-muted-foreground text-md">
                Consultez et planifiez les rattrapages de vos devoirs surveillés
            </span>
            </div>
        </div>

        <!-- Formulaire de filtre -->
        <form id="filterForm" onsubmit="return false;" class="flex flex-lig justify-between gap-4 items-end w-full bg-white shadow-sm rounded-md px-8 py-8 ">
            <div class="flex flex-col gap-4">
                <label for="statut" class="text-sm font-semibold leading-none">Filtrer par statut</label>
                <select id="statut" name="statut"
                        class="flex h-10 w-full rounded-md border border-input bg-white pl-3 pr-10 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 cursor-pointer">
                    <option value="all">Tous</option>
                    <option value="en_attente">En attente</option>
                    <option value="planifies">Planifiés</option>
                    <option value="annules">Annulés</option>
                </select>
            </div>

            <div class="flex flex-col gap-2">
                <button id="btnReset" type="reset" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-semibold ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-white hover:bg-accent hover:text-accent-foreground h-10 px-6 py-2 w-full hover:cursor-pointer">
                    Réinitialiser
                </button>
            </div>
        </form>

        <div class="space-y-4 w-full">

            <?php if (empty($rattrapages)): ?>
                <div class="text-center py-12 text-muted-foreground">
                    <i data-lucide="inbox" class="w-12 h-12 mx-auto mb-3 opacity-20"></i>
                    <p>Aucun rattrapage à afficher pour le moment.</p>
                </div>
            <?php else: ?>

                <?php foreach ($rattrapages as $rattrapage): ?>

                    <?php
                    // Mapping pour le filtre JS
                    $dataStatut = match ($rattrapage['etat']) {
                        'En attente' => 'en_attente',
                        'Programmé' => 'planifies',
                        'Neutralisé' => 'annules',
                        default => 'all',
                    };
                    ?>

                    <div class="rattrapage-item bg-card border border-border rounded-lg p-6 shadow-sm hover:shadow-md transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-6 <?= $rattrapage['etat'] === 'Neutralisé' ? 'opacity-75 bg-muted/30' : '' ?>"
                         data-statut="<?= $dataStatut ?>">

                        <!-- Partie Gauche : Informations -->
                        <div class="min-w-[200px] flex flex-col gap-2 w-full">
                            <h3 class="text-lg font-bold text-foreground leading-tight">
                                <?= esc($rattrapage['ressource']) ?>
                            </h3>

                            <!-- Badges Semestre & Date Originale -->
                            <div class="flex items-center gap-2 mb-2">
                            <span class="inline-flex items-center rounded-md border border-border bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
                                <?= esc($rattrapage['semestre']) ?>
                            </span>
                                <span class="flex items-center gap-1 text-xs text-muted-foreground">
                                <i data-lucide="calendar" class="w-3 h-3"></i>
                                DS du <?= date('d/m/Y', strtotime($rattrapage['date_ds_original'])) ?>
                            </span>
                            </div>

                            <!-- Contenu Contextuel selon l'état -->
                            <?php if ($rattrapage['etat'] === 'En attente'): ?>

                                <div class="flex flex-col items-start md:items-center gap-1 h-full w-full">
                                <span class="text-sm font-medium text-yellow-700 bg-yellow-100 rounded-lg flex items-center gap-1.5 w-full h-full p-4 border-2 border-yellow-600">
                                    <i data-lucide="alert-circle" class="w-3 h-3"></i>
                                    En attente de votre planification •
                                    <span class="font-semibold"><?= $rattrapage['etudiants_count'] ?> étudiants concernés</span>
                                </span>
                                </div>

                            <?php elseif ($rattrapage['etat'] === 'Programmé'): ?>

                                <div class="flex flex-col items-start gap-1.5 text-sm font-semibold">
                                    <div class="flex items-center gap-2 text-foreground">
                                        <i data-lucide="calendar-check" class="w-4 h-4 text-primary"></i>
                                        <!-- Date du rattrapage -->
                                        <?= date('d/m/Y', strtotime($rattrapage['date_rattrapage'])) ?>
                                    </div>
                                    <div class="flex items-center gap-2 text-muted-foreground">
                                        <i data-lucide="clock" class="w-3 h-3"></i>
                                        <!-- Affichage de la plage horaire -->
                                        <?= esc($rattrapage['plage_horraire'] ?? 'Horaire non défini') ?>
                                    </div>
                                    <div class="flex items-center gap-2 text-muted-foreground">
                                        <i data-lucide="map-pin" class="w-3 h-3"></i>
                                        Salle <?= esc($rattrapage['salle']) ?>
                                    </div>
                                </div>

                            <?php else: ?> <!-- Neutralisé -->

                                <div class="flex flex-col items-start md:items-center text-muted-foreground text-sm italic">
                                    <i data-lucide="ban" class="w-5 h-5 mb-1 opacity-50"></i>
                                    Rattrapage annulé
                                </div>

                            <?php endif; ?>
                        </div>

                        <!-- Partie Droite : Boutons & Badge -->
                        <div class="flex flex-row md:flex-col items-center md:items-end justify-between w-full md:w-auto gap-3">

                            <?php
                            $badgeStyle = match ($rattrapage['etat']) {
                                'En attente' => 'bg-yellow-100 text-yellow-800 border-yellow-200 w-full',
                                'Programmé' => 'bg-green-100 text-green-800 border-green-200 w-full',
                                default => 'bg-gray-100 text-gray-600 border-gray-200 w-full',
                            };
                            ?>

                            <span class="inline-flex justify-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 <?= $badgeStyle ?>">
                            <?= esc($rattrapage['etat']) ?>
                        </span>

                            <?php if ($rattrapage['etat'] === 'En attente'): ?>

                                <a href="<?= site_url('planifier_rattrapage/' . $rattrapage['id']) ?>" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-9 px-4 py-2 shadow-sm animate-pulse-slow w-full">
                                    Planifier
                                    <i data-lucide="arrow-right" class="w-4 h-4 ml-2"></i>
                                </a>

                            <?php elseif ($rattrapage['etat'] === 'Programmé'): ?>

                                <a href="<?= site_url('planifier_rattrapage/' . $rattrapage['id']) ?>" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-9 px-4 py-2 w-full">
                                    Détails
                                </a>

                            <?php else: ?>

                                <button disabled class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium border border-input bg-muted text-muted-foreground h-9 px-4 py-2 opacity-50 cursor-not-allowed w-full">
                                    Archivé
                                </button>

                            <?php endif; ?>

                        </div>

                    </div>

                <?php endforeach; ?>

            <?php endif; ?>

        </div>

    </section>

    <!-- SCRIPT DE FILTRE (Client Side) -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const selectStatut = document.getElementById('statut');
            const btnReset = document.getElementById('btnReset');
            const items = document.querySelectorAll('.rattrapage-item');

            function filterItems() {
                const filterValue = selectStatut.value;

                items.forEach(item => {
                    const itemStatut = item.getAttribute('data-statut');
                    if (filterValue === '' || filterValue === 'all' || itemStatut === filterValue) {
                        item.classList.remove('hidden');
                    } else {
                        item.classList.add('hidden');
                    }
                });
            }

            selectStatut.addEventListener('change', filterItems);

            btnReset.addEventListener('click', () => {
                setTimeout(() => {
                    filterItems();
                }, 10);
            });
        });
    </script>

<?= $this->endSection() ?>