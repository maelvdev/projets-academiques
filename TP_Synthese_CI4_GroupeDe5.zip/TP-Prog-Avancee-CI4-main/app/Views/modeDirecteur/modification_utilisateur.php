<?= $this->extend('layouts/dashboard_layout') ?>

<?= $this->section('root_content') ?>

<section class="pr-40 pl-100 py-8 items-center w-full flex flex-col gap-8">
    <div class="flex flex-col gap-2 w-full">
        <h2 class="font-bold text-4xl text-primary">Modifier l'utilisateur</h2>
        <span class="text-muted-foreground text-md">Modification des informations de <?= esc($user['prenom']) . ' ' . esc($user['nom']) ?></span>
    </div>

    <div class="bg-card border border-border shadow-sm rounded-lg p-6 w-full max-w-2xl">
        <form action="<?= site_url('gestion_utilisateur/update') ?>" method="post" class="space-y-6" id="form-modification">
            <input type="hidden" name="email" value="<?= esc($user['email']) ?>">
            <input type="hidden" id="role_actuel" value="<?= esc($user['role']) ?>">

            <div class="grid grid-cols-2 gap-4">
                <div class="space-y-2">
                    <label for="nom" class="text-sm font-medium">Nom</label>
                    <input type="text" id="nom" name="nom" value="<?= esc($user['nom']) ?>" class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2" required>
                </div>
                <div class="space-y-2">
                    <label for="prenom" class="text-sm font-medium">Prénom</label>
                    <input type="text" id="prenom" name="prenom" value="<?= esc($user['prenom']) ?>" class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2" required>
                </div>
            </div>

            <div class="space-y-2">
                <label for="email_display" class="text-sm font-medium">Email</label>
                <input type="email" id="email_display" value="<?= esc($user['email']) ?>" class="flex h-10 w-full rounded-md border border-input bg-muted px-3 py-2 text-sm text-muted-foreground cursor-not-allowed" disabled>
                <p class="text-xs text-muted-foreground">L'email ne peut pas être modifié car il sert d'identifiant.</p>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div class="space-y-2">
                    <label for="role" class="text-sm font-medium">Rôle</label>
                    <select id="role" name="role" class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
                        <option value="enseignant" <?= strcasecmp($user['role'], 'enseignant') === 0 ? 'selected' : '' ?>>Enseignant</option>
                        <option value="directeur" <?= strcasecmp($user['role'], 'directeur') === 0 ? 'selected' : '' ?>>Directeur</option>
                    </select>
                </div>
            </div>

            <div cla²s="flex justify-end gap-4 pt-4">
                <a href="<?= site_url('gestion_utilisateur') ?>" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2">
                    Annuler
                </a>
                <button type="submit" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2">
                    Enregistrer les modifications
                </button>
            </div>
        </form>
    </div>
</section>

<script>
    document.getElementById('form-modification').addEventListener('submit', function(e) {
        const roleSelect = document.getElementById('role');
        const roleActuel = document.getElementById('role_actuel').value;
        const nouveauRole = roleSelect.value;
        
        let message = "Êtes-vous sûr de vouloir enregistrer les modifications ?";

        if (nouveauRole.toLowerCase() === 'directeur' && roleActuel.toLowerCase() !== 'directeur') {
            message = "Attention : Vous êtes sur le point de nommer un nouveau directeur.\n\nL'ancien directeur sera automatiquement rétrogradé au rang d'enseignant.\n\nVoulez-vous continuer ?";
        }

        if (!confirm(message)) {
            e.preventDefault();
        }
    });
</script>

<?= $this->endSection() ?>
