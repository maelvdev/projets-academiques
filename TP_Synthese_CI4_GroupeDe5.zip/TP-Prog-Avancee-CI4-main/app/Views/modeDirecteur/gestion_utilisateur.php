<?= $this->extend('layouts/dashboard_layout') ?>

<?= $this->section('root_content') ?>

    <section class="pr-40 pl-100 py-8 items-center w-full flex flex-col gap-8">

        <div class="flex flex-lig justify-between w-full items-center">
            <div class="flex flex-col gap-2">
                <h2 class="font-bold text-4xl text-primary">Gestion des utilisateurs</h2>
                <span class="text-muted-foreground text-md">
                Gérez les comptes et les permissions
            </span>
            </div>
        </div>

        <div class="bg-card border border-border shadow-sm rounded-lg p-6 w-full">
            <form id="filterForm" onsubmit="return false;" class="flex flex-col md:flex-row gap-6 items-end justify-between">

                <div class="flex flex-col gap-2 w-full md:max-w-md">
                    <label for="rechercher" class="text-sm font-medium leading-none">Rechercher</label>
                    <div class="relative">
                        <i data-lucide="search" class="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground"></i>
                        <input id="rechercher" name="rechercher" type="text"
                               class="flex h-10 w-full rounded-md border border-input bg-background pl-9 pr-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                               placeholder="Nom, prénom ou email..."/>
                    </div>
                </div>

                <div class="w-full md:w-auto">
                    <button type="reset" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-8 py-2 w-full md:w-auto shadow-sm">
                        Réinitialiser
                    </button>
                </div>
            </form>
        </div>

        <div class="bg-card overflow-hidden w-full rounded-lg border border-border shadow-sm">
            <div class="relative w-full overflow-auto">
                <table class="w-full caption-bottom text-sm text-left">
                    <thead class="bg-muted/50">
                    <tr class="border-b border-b-gray-300 transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                        <th class="h-12 px-4 align-middle font-semibold text-foreground">Utilisateur</th>
                        <th class="h-12 px-4 align-middle font-semibold text-foreground">Rôle</th>
                        <th class="h-12 px-4 align-middle font-semibold text-foreground">Statut</th>
                        <th class="h-12 px-4 align-middle font-semibold text-foreground text-right">Actions</th>
                    </tr>
                    </thead>

                    <tbody class="[&_tr:last-child]:border-0" id="usersTableBody">
                    <?php foreach ($utilisateurs as $user): ?>
                        <tr class="user-row border-b border-b-gray-300 transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted"
                            data-search="<?= strtolower($user['nom'] . ' ' . $user['prenom'] . ' ' . $user['email']) ?>">

                            <td class="p-4 align-middle font-medium">
                                <div class="flex flex-col">
                                    <span class="text-foreground font-semibold"><?= esc($user['prenom']) . ' ' . esc($user['nom']) ?></span>
                                    <span class="text-muted-foreground text-xs font-normal"><?= esc($user['email']) ?></span>
                                </div>
                            </td>

                            <td class="p-4 align-middle">
                            <span class="inline-flex items-center rounded-md border border-transparent bg-blue-100 text-blue-700 px-2.5 py-0.5 text-xs font-semibold shadow-sm">
                                <?= esc($user['role']) ?>
                            </span>
                            </td>

                            <td class="p-4 align-middle">
                                <?php if ($user['compte_valide']): ?>
                                    <span class="inline-flex items-center rounded-md border border-transparent bg-green-100 text-green-700 px-2.5 py-0.5 text-xs font-semibold shadow-sm">
                                    Actif
                                </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center rounded-md border border-transparent bg-gray-100 text-gray-700 px-2.5 py-0.5 text-xs font-semibold shadow-sm">
                                    Inactif
                                </span>
                                <?php endif; ?>
                            </td>

                            <td class="p-4 align-middle text-right">
                                <div class="flex items-center justify-end gap-3">
                                    <a href="<?= site_url('gestion_utilisateur/voir/' . $user['email']) ?>" class="inline-flex items-center gap-1 text-sm font-medium text-foreground hover:text-primary transition-colors">
                                        <i data-lucide="eye" class="w-4 h-4"></i>
                                        Voir
                                    </a>
                                    <?php if (strcasecmp(trim($user['role']), 'directeur') !== 0): ?>
                                        <a href="<?= site_url('gestion_utilisateur/modifier/' . $user['email']) ?>" class="inline-flex items-center gap-1 text-sm font-medium text-foreground hover:text-primary transition-colors">
                                            <i data-lucide="square-pen" class="w-4 h-4"></i>
                                            Éditer
                                        </a>
                                        <a href="<?= site_url('gestion_utilisateur/supprimer/' . $user['email']) ?>" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?');" class="inline-flex items-center gap-1 text-sm font-medium text-destructive hover:text-destructive/80 transition-colors">
                                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

                <!-- Message si aucun résultat -->
                <div id="no-results" class="hidden p-8 text-center text-muted-foreground">
                    Aucun utilisateur trouvé pour cette recherche.
                </div>
            </div>
        </div>
    </section>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const searchInput = document.getElementById('rechercher');
            const rows = document.querySelectorAll('.user-row');
            const noResultsMessage = document.getElementById('no-results');
            const resetButton = document.querySelector('button[type="reset"]');

            function filterTable() {
                const searchValue = searchInput.value.toLowerCase().trim();
                let visibleCount = 0;

                rows.forEach(row => {
                    const searchData = row.getAttribute('data-search');

                    if (searchData.includes(searchValue)) {
                        row.style.display = '';
                        visibleCount++;
                    } else {
                        row.style.display = 'none';
                    }
                });

                if (visibleCount === 0) {
                    noResultsMessage.classList.remove('hidden');
                } else {
                    noResultsMessage.classList.add('hidden');
                }
            }

            searchInput.addEventListener('input', filterTable);

            resetButton.addEventListener('click', () => {
                setTimeout(() => {
                    filterTable();
                }, 10);
            });
        });
    </script>

<?= $this->endSection() ?>