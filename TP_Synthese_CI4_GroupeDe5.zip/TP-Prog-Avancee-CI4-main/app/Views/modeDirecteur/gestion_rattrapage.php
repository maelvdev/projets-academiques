<?= $this->extend('layouts/dashboard_layout') ?>

<?= $this->section('root_content') ?>

<?php $count = count($rattrapages); ?>

<div class="pr-40 pl-100 py-8 items-center w-full flex flex-col gap-8">
    <div class="flex flex-lig justify-between w-full items-center">
        <div class="flex flex-col gap-2">
            <h2 class="font-bold text-4xl text-primary">Gestion des rattrapages</h2>
            <span class="text-muted-foreground text-md">
                <?= $count > 0 ? $count : 'Aucun rattrapage.' ?> <?= $count > 1 ? 'Rattrapages' : 'Rattrapage' ?>
            </span>
        </div>
        <div>
            <a href="<?= site_url(
                'rattrapage/creation',
            ) ?>" class="bg-primary text-primary-foreground px-4 py-2 rounded-md flex items-center gap-2 hover:bg-primary/90 transition-colors justify-center">
                <i data-lucide="plus" class="w-4 h-4"></i>
                Nouveau rattrapage
            </a>
        </div>
    </div>

    <div class="bg-card border border-border rounded-lg p-5 mb-6 shadow-sm w-full">

        <div class="flex items-center gap-2 mb-4 text-foreground">
            <i data-lucide="filter" class="w-5 h-5 text-primary"></i>
            <span class="font-semibold text-lg">Filtres</span>
        </div>

        <form action="<?= site_url('gestion_rattrapage') ?>" method="get" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">

            <div class="flex flex-col gap-2 w-full">
                <label for="search" class="text-sm text-muted-foreground leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                    Rechercher
                </label>
                <div class="relative">
                    <i data-lucide="search" class="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground"></i>
                    <input id="search" name="search" type="text"
                           value="<?= esc($filters['search'] ?? '') ?>"
                           class="flex h-10 w-full rounded-md border border-input bg-white pl-9 pr-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                           placeholder="Ressource, enseignant, étudiant..."/>
                </div>
            </div>

            <div class="flex flex-col gap-2 w-full">
                <label for="semestre" class="text-sm text-muted-foreground leading-none">Semestre</label>
                <select id="semestre" name="semestre" onchange="this.form.submit()"
                        class="flex h-10 w-full rounded-md border border-input bg-white pl-3 pr-10 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 cursor-pointer">
                    <option value="">Tous les semestres</option>
                    <option value="S1" <?= ($filters['semestre'] ?? '') === 'S1' ? 'selected' : '' ?>>Semestre 1</option>
                    <option value="S2" <?= ($filters['semestre'] ?? '') === 'S2' ? 'selected' : '' ?>>Semestre 2</option>
                    <option value="S3" <?= ($filters['semestre'] ?? '') === 'S3' ? 'selected' : '' ?>>Semestre 3</option>
                    <option value="S4" <?= ($filters['semestre'] ?? '') === 'S4' ? 'selected' : '' ?>>Semestre 4</option>
                    <option value="S5" <?= ($filters['semestre'] ?? '') === 'S5' ? 'selected' : '' ?>>Semestre 5</option>
                    <option value="S6" <?= ($filters['semestre'] ?? '') === 'S6' ? 'selected' : '' ?>>Semestre 6</option>
                </select>
            </div>

            <div class="flex flex-col gap-2 w-full">
                <label for="annee" class="text-sm text-muted-foreground leading-none">Année BUT</label>
                <select id="annee" name="annee" onchange="this.form.submit()"
                        class="flex h-10 w-full rounded-md border border-input bg-white pl-3 pr-10 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 cursor-pointer">
                    <option value="">Toutes les années</option>
                    <option value="BUT1" <?= ($filters['annee'] ?? '') === 'BUT1' ? 'selected' : '' ?>>BUT 1</option>
                    <option value="BUT2" <?= ($filters['annee'] ?? '') === 'BUT2' ? 'selected' : '' ?>>BUT 2</option>
                    <option value="BUT3" <?= ($filters['annee'] ?? '') === 'BUT3' ? 'selected' : '' ?>>BUT 3</option>
                </select>
            </div>

            <div class="flex flex-col gap-2 w-full">
                <a href="<?= site_url('gestion_rattrapage') ?>" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-semibold ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-white hover:bg-accent hover:text-accent-foreground h-10 px-6 py-2 w-full hover:cursor-pointer">
                    Réinitialiser
                </a>
            </div>
            <button type="submit" class="hidden"></button>
        </form>
</div>

    <div class="space-y-4 w-full">

        <?php if (empty($rattrapages)): ?>
            <!-- Cas où il n'y a aucun rattrapage -->
            <div class="text-center py-12 bg-card border border-dashed border-border rounded-lg">
                <i data-lucide="folder-open" class="mx-auto h-12 w-12 text-muted-foreground/50"></i>
                <h3 class="mt-2 text-sm font-semibold text-foreground">Aucun rattrapage</h3>
                <p class="mt-1 text-sm text-muted-foreground">Commencez par en créer un nouveau.</p>
            </div>
        <?php else: ?>

            <?php foreach ($rattrapages as $rattrapage): ?>

                <div class="bg-card border border-border rounded-lg shadow-sm hover:shadow-md transition-shadow p-6">
                    <div class="flex flex-col md:flex-row justify-between gap-6 items-center">

                        <!-- Partie Gauche : Infos (Ressource, Enseignant, Badges) -->
                        <div class="flex-1 space-y-4 w-full md:w-auto">
                            <div>
                                <div class="flex items-center gap-3 mb-1">
                                    <?php $etatClass = match ($rattrapage['etat']) {
                                        'Programmé' => 'bg-green-100 text-green-700 border-green-200',
                                        'En attente' => 'bg-yellow-100 text-yellow-700 border-yellow-200',
                                        'annulé', 'Neutralisé' => 'bg-gray-100 text-gray-700 border-gray-200',
                                        default => 'bg-blue-100 text-blue-700 border-blue-200',
                                    }; ?>
                                    <span class="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 <?= $etatClass ?>">
                                        <?= esc($rattrapage['etat']) ?>
                                    </span>

                                    <span class="text-xs text-muted-foreground font-medium border border-border px-2 py-0.5 rounded">
                                        <?= esc($rattrapage['type']) ?> • <?= esc($rattrapage['duree']) ?> min
                                    </span>
                                </div>

                                <h3 class="text-xl font-bold text-foreground">
                                    <?= esc($rattrapage['ressource']) ?>
                                </h3>

                                <div class="flex gap-3 text-md py-1 text-muted-foreground">
                                    <span>Pr. <?= esc($rattrapage['enseignant']['prenom']) ?> <?= esc(
     $rattrapage['enseignant']['nom'],
 ) ?></span>
                                </div>

                                <div class="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                                    <span>BUT <?= esc($rattrapage['annee_but']) ?></span>
                                    <span>•</span>
                                    <span>Semestre <?= esc($rattrapage['semestre']) ?></span>
                                </div>
                            </div>
                        </div>

                        <!-- Partie Droite : Dates, Etudiants ET Boutons -->
                        <div class="flex items-center gap-6 w-full md:w-auto justify-between md:justify-end border-t md:border-t-0 pt-4 md:pt-0 border-border">

                            <!-- Dates et Etudiants -->
                            <div class="text-right space-y-1 text-sm">
                                <div class="flex items-center justify-end gap-2">
                                    <span class="text-muted-foreground">DS Original :</span>
                                    <span class="font-medium flex items-center gap-1">
                                        <i data-lucide="calendar" class="w-3 h-3 text-muted-foreground"></i>
                                        <?= date('d/m/Y', strtotime($rattrapage['date_ds_original'])) ?>
                                    </span>
                                </div>
                                <div class="flex items-center justify-end gap-2">
                                    <span class="text-muted-foreground">Rattrapage :</span>
                                    <?php if ($rattrapage['date_rattrapage']): ?>
                                        <span class="font-semibold text-primary flex items-center gap-1">
                                            <i data-lucide="calendar-clock" class="w-3 h-3"></i>
                                            <?= date('d/m/Y', strtotime($rattrapage['date_rattrapage'])) ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-orange-500 italic text-xs">À définir</span>
                                    <?php endif; ?>
                                </div>
                                <div class="pt-1">
                                    <p class="text-xs font-semibold text-muted-foreground">
                                        <?= count($rattrapage['etudiants']) ?> étudiant(s) concerné(s)
                                    </p>
                                </div>
                            </div>

                            <!-- Séparateur Vertical (visible sur desktop) -->
                            <div class="h-10 w-px bg-border hidden md:block"></div>

                            <!-- Boutons Actions -->
                            <div class="flex flex-lig gap-4">
                                <a href="<?= site_url('visualisation_rattrapage/' . $rattrapage['id_rattrapage']) ?>" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-8 px-5 w-full">
                                    Détails
                                </a>

                                <a href="<?= site_url('modifier_rattrapage/' . $rattrapage['id_rattrapage']) ?>"
                                   class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-8 px-5 w-full">
                                    Modifier
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

        <?php endif; ?>

    </div>

</div>

<?= $this->endSection() ?>

