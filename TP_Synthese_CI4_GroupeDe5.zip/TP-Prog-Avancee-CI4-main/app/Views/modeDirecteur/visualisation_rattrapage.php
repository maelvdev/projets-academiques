<?= $this->extend('layouts/dashboard_layout') ?>


<?= $this->section('main_content') ?>



<section class="container w-full">


    <div class="space-y-4">

        <a href="<?= site_url('gestion_rattrapage') ?>" class="inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline transition-colors">

            <i data-lucide="arrow-left" class="w-4 h-4"></i>

            Retour aux rattrapages

        </a>


        <div class="flex items-end justify-between">

            <div>

                <h1 class="text-4xl font-bold text-primary"><?= esc($rattrapage['ressource']) ?></h1>

                <p class="text-slate-500 mt-1">Détails du rattrapage</p>

            </div>

            <div class="flex gap-2">

                <a href="<?= site_url('modifier_rattrapage/' . $rattrapage['id']) ?>">

                    <button class="shadow-md font-semibold text-md flex gap-2 px-3 py-2 items-center rounded-md hover:cursor-pointer">

                        <i data-lucide="square-pen" class="w-4 h-4"></i>

                        <span>Modifier</span>

                    </button>

                </a>

                <form action="<?= site_url('rattrapage/supprimer/' . $rattrapage['id']) ?>" method="post" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer définitivement ce rattrapage ? Cette action est irréversible.');">

                    <!-- Protection CSRF de CodeIgniter -->
                    <?= csrf_field() ?>

                    <button type="submit" class="shadow-md text-md font-semibold text-white bg-red-600 flex gap-2 px-3 py-2 items-center rounded-md hover:bg-red-700 transition-colors cursor-pointer">
                        <i data-lucide="trash" class="w-4 h-4"></i>
                        <span>Supprimer</span>
                    </button>
                </form>

            </div>

        </div>


        <div class="grid grid-cols-3 gap-8 w-full pt-8">

            <div class="justify-between flex flex-col p-6 h-[200px] border border-gray-300 rounded-md bg-white">

                <span class="text-muted-foreground">Ressource</span>

                <span class="text-xl font-semibold"><?= esc($rattrapage['ressource']) ?></span>

                <span class="text-sm text-muted-foreground"><?= esc($rattrapage['semestre']) ?> - BUT <?= ceil((int)str_replace('S', '', $rattrapage['semestre']) / 2) ?></span>

            </div>

            <div class="justify-between flex flex-col p-6 h-[200px] border border-gray-300 rounded-md bg-white">

                <span class="text-muted-foreground">Enseignant</span>

                <span class="text-xl font-semibold"><?= esc($rattrapage['enseignant']['nom']) . ' ' . esc($rattrapage['enseignant']['prenom']) ?></span>

                <span></span>

            </div>

            <div class="justify-between flex flex-col p-6 h-[200px] border border-gray-300 rounded-md bg-white">

                <span class="text-muted-foreground">Statut</span>

                <span class="text-xl font-semibold"><?= esc($rattrapage['etat']) ?></span>

                <span></span>

            </div>

        </div>


        <div class="grid grid-cols-2 w-full gap-8">

            <div class="justify-between flex flex-col p-6 h-[300px] border border-gray-300 rounded-md w-full bg-white">

                <h2 class="text-xl text-primary font-bold">Informations du DS original</h2>

                <div class="flex flex-col gap-4">

                    <div class="flex flex-col gap-1">

                        <span class="text-muted-foreground text-sm">Date</span>

                        <span class="font-semibold text-md"><?= esc($rattrapage['date_ds_original']) ?></span>

                    </div>

                    <div class="flex flex-col gap-1">

                        <span class="text-muted-foreground text-sm">Type</span>

                        <span class="font-semibold text-md"><?= esc($rattrapage['type']) ?></span>

                    </div>

                    <div class="flex flex-col gap-1">

                        <span class="text-muted-foreground text-sm">Durée</span>

                        <span class="font-semibold text-md"><?= esc($rattrapage['duree']) ?> minutes</span>

                    </div>

                </div>

            </div>

            <div class="justify-between flex flex-col p-6 h-[300px] border border-gray-300 rounded-md w-full bg-white">

                <h2 class="text-xl text-primary font-bold">Planification du rattrapage</h2>

                <div class="flex flex-col gap-4">

                    <div class="flex flex-col gap-1">

                        <span class="text-muted-foreground text-sm">Date</span>

                        <span class="font-semibold text-md"><?= esc($rattrapage['date_rattrapage']) ?? "Aucune date n'est prévue" ?></span>

                    </div>

                    <div class="flex flex-col gap-1">

                        <span class="text-muted-foreground text-sm">Horraire</span>

                        <span class="font-semibold text-md"><?= esc($rattrapage['heure_debut']) ?> - <?= esc($rattrapage['heure_fin']) ?></span>

                    </div>

                    <div class="flex flex-col gap-1">

                        <span class="text-muted-foreground text-sm">Salle</span>

                        <span class="font-semibold text-md"><?= esc($rattrapage['salle']) ?? "Aucune salle n'est prévue" ?></span>

                    </div>

                </div>

            </div>

        </div>


        <div class="space-y-4 pt-4">
            <?php if (!empty($rattrapage['etudiants'])): ?>
                <div class="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden p-8">
                    <h2 class="font-bold text-primary text-xl">Étudiants concernés</h2>


                    <div class="overflow-x-auto pt-8">
                        <table class="w-full text-sm text-left">
                            <thead class="bg-white border-b border-gray-100 text-foreground">
                            <tr>
                                <th class="px-6 py-4 font-bold w-1/4">Étudiant</th>
                                <th class="px-6 py-4 font-bold w-1/4">Email</th>
                                <th class="px-6 py-4 font-bold w-1/6">Justifié</th>
                            </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100 bg-white">
                            <?php foreach ($rattrapage['etudiants'] as $index => $etudiant): ?>
                                <tr class="hover:bg-slate-50 transition-colors">
                                    <td class="px-6 py-4 font-medium text-foreground align-middle">
                                        <?= esc($etudiant['prenom']) ?> <?= esc($etudiant['nom']) ?>
                                    </td>
                                    <td class="px-6 py-4 text-muted-foreground align-middle">
                                        <?= strtolower(esc($etudiant['prenom']) . '.' . esc($etudiant['nom'])) ?>@univ.fr
                                    </td>
                                    <td class="px-6 py-4 align-middle">
                                        <?php if(isset($etudiant['justifie']) && $etudiant['justifie'] == 1): ?>
                                            <span class="font-medium text-green-600">Oui</span>
                                        <?php else: ?>
                                            <span class="font-medium text-slate-500">Non</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php else: ?>
                <div class="bg-white border border-gray-200 rounded-lg shadow-sm p-12 text-center text-muted-foreground italic">
                    <i data-lucide="users" class="w-12 h-12 mx-auto mb-3 opacity-20"></i>
                    <p>Aucun étudiant concerné pour le moment.</p>
                </div>
            <?php endif; ?>
        </div>
</section>



<?= $this->endSection() ?> 