<?= $this->extend('layouts/dashboard_layout') ?>

<?= $this->section('root_content') ?>

<section class="pr-40 pl-100 py-8 items-center w-full flex flex-col gap-8">
    <div class="flex flex-col gap-2 w-full">
        <h2 class="font-bold text-4xl text-primary">Détails de l'utilisateur</h2>
        <span class="text-muted-foreground text-md">Informations complètes</span>
    </div>

    <div class="bg-card border border-border shadow-sm rounded-lg p-6 w-full max-w-2xl">
        <div class="space-y-6">
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <h3 class="text-sm font-medium text-muted-foreground">Nom</h3>
                    <p class="text-lg font-semibold"><?= esc($user['nom']) ?></p>
                </div>
                <div>
                    <h3 class="text-sm font-medium text-muted-foreground">Prénom</h3>
                    <p class="text-lg font-semibold"><?= esc($user['prenom']) ?></p>
                </div>
            </div>

            <div>
                <h3 class="text-sm font-medium text-muted-foreground">Email</h3>
                <p class="text-lg"><?= esc($user['email']) ?></p>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div>
                    <h3 class="text-sm font-medium text-muted-foreground">Rôle</h3>
                    <span class="inline-flex items-center rounded-md border border-transparent bg-blue-100 text-blue-700 px-2.5 py-0.5 text-sm font-semibold shadow-sm mt-1">
                        <?= esc($user['role']) ?>
                    </span>
                </div>
                <div>
                    <h3 class="text-sm font-medium text-muted-foreground">Statut du compte</h3>
                    <?php if ($user['compte_valide']): ?>
                        <span class="inline-flex items-center rounded-md border border-transparent bg-green-100 text-green-700 px-2.5 py-0.5 text-sm font-semibold shadow-sm mt-1">
                            Actif
                        </span>
                    <?php else: ?>
                        <span class="inline-flex items-center rounded-md border border-transparent bg-gray-100 text-gray-700 px-2.5 py-0.5 text-sm font-semibold shadow-sm mt-1">
                            Inactif
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="flex justify-end gap-4 pt-4 border-t border-border mt-6">
                <a href="<?= site_url('gestion_utilisateur') ?>" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2">
                    Retour à la liste
                </a>
                <?php if (strcasecmp(trim($user['role']), 'directeur') !== 0): ?>
                    <a href="<?= site_url('gestion_utilisateur/modifier/' . $user['email']) ?>" class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2">
                        <i data-lucide="square-pen" class="w-4 h-4 mr-2"></i>
                        Éditer
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?= $this->endSection() ?>
