<?= $this->extend('layouts/dashboard_layout') ?>

<?= $this->section('main_content') ?>

<section class="container mx-auto p-6 max-w-4xl space-y-6">

    <div class="space-y-4">
        <a href="<?= site_url('gestion_rattrapage') ?>" class="inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline transition-colors">
            <i data-lucide="arrow-left" class="w-4 h-4"></i>
            Retour aux rattrapages
        </a>

        <div class="flex items-end justify-between">
            <div>
                <h1 class="text-4xl font-bold text-primary">Modifier un rattrapage</h1>
                <p class="text-slate-500 mt-1">Édition de <?= esc($rattrapage['ressource']) ?></p>
            </div>
            <span class="text-sm text-slate-400 hidden md:block">Mode Édition</span>
        </div>
    </div>

    <form action="<?= site_url('modifier_rattrapage/' . $rattrapage['id']) ?>" method="post" class="space-y-6">
        <?= csrf_field() ?>
        <input type="hidden" name="id_ressource" value="<?= esc($rattrapage['id_ressource']) ?>">

        <div class="bg-white border-2 border-[#003366] rounded-xl p-6 shadow-sm">
            <div class="flex items-center gap-3 mb-6">
                <div class="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-white font-bold text-sm">1</div>
                <h2 class="text-lg font-bold text-primary">Sélectionner le semestre et la ressource</h2>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-2">
                    <label for="semestre" class="text-sm font-bold text-slate-700">Semestre *</label>
                    <select id="semestre" name="semestre" class="flex h-11 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2">
                        <?php for($i = 1; $i <= 6; $i++): ?>
                            <option value="<?= $i ?>" <?= $rattrapage['semestre'] == $i ? 'selected' : '' ?>>Semestre <?= $i ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="space-y-2">
                    <label for="ressource" class="text-sm font-bold text-slate-700">Ressource (Matière) *</label>
                    <input type="text" id="ressource" name="ressource" value="<?= esc($rattrapage['ressource']) ?>"
                           class="flex h-11 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 placeholder:text-slate-400">
                </div>
            </div>
        </div>

        <!-- ÉTAPE 2 : Informations DS (Carte Standard - Déverrouillée) -->
        <div class="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <div class="flex items-center gap-3 mb-6">
                <div class="flex items-center justify-center w-8 h-8 rounded-full bg-slate-200 text-slate-600 font-bold text-sm">2</div>
                <h2 class="text-lg font-bold text-slate-700">Informations du DS original</h2>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-2">
                    <label for="date_ds" class="text-sm font-medium text-slate-600">Date du DS original *</label>
                    <!-- Conversion de la date pour l'input type="date" -->
                    <input type="date" id="date_ds" name="date_ds_original" value="<?= date('Y-m-d', strtotime($rattrapage['date_ds_original'])) ?>"
                           class="flex h-11 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary">
                </div>

                <div class="space-y-2">
                    <label for="type_ds" class="text-sm font-medium text-slate-600">Type de DS *</label>
                    <select id="type_ds" name="type_ds" class="flex h-11 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#003366]">
                        <option value="DS Table" <?= (isset($rattrapage['type_ds']) && $rattrapage['type_ds'] == 'DS Table') ? 'selected' : '' ?>>DS Table</option>
                        <option value="DS Machine" <?= (isset($rattrapage['type_ds']) && $rattrapage['type_ds'] == 'DS Machine') ? 'selected' : '' ?>>DS Machine</option>
                    </select>
                </div>

                <div class="space-y-2">
                    <label for="duree" class="text-sm font-medium text-slate-600">Durée (minutes) *</label>
                    <input type="number" id="duree" name="duree" placeholder="Ex: 120" value="<?= esc($rattrapage['duree'] ?? '') ?>"
                           class="flex h-11 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#003366]">
                </div>

                <div class="space-y-2">
                    <label for="enseignant" class="text-sm font-medium text-slate-600">Enseignant responsable *</label>
                    <select id="enseignant" name="mail_enseignant" class="flex h-11 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#003366]">
                        <?php foreach ($enseignants as $enseignant): ?>
                            <option value="<?= esc($enseignant['email']) ?>" <?= ($rattrapage['mail_enseignant'] == $enseignant['email']) ? 'selected' : '' ?>>
                                <?= esc($enseignant['prenom']) ?> <?= esc($enseignant['nom']) ?><?= (strtolower($role) !== 'directeur') ? ' (Moi-même)' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <div class="flex items-center gap-3 mb-6">
                <div class="flex items-center justify-center w-8 h-8 rounded-full bg-slate-200 text-slate-600 font-bold text-sm">3</div>
                <h2 class="text-lg font-bold text-slate-700">Étudiants absents</h2>
            </div>

            <div class="space-y-4">
                <!-- Conteneur du tableau -->
                <div class="border rounded-md overflow-hidden <?= empty($rattrapage['etudiants']) ? 'hidden' : '' ?>" id="studentTableContainer">
                    <table class="w-full text-sm text-left">
                        <thead class="bg-slate-50 text-slate-500 border-b border-slate-100">
                        <tr>
                            <th class="px-4 py-2 font-medium">Nom Prénom</th>
                            <th class="px-4 py-2 font-medium">Email</th>
                            <th class="px-4 py-2 font-medium">Groupe</th>
                            <th class="px-4 py-2 font-medium text-center">Justifié</th>
                            <th class="px-4 py-2 font-medium text-right">Action</th>
                        </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100" id="studentTableBody">
                        <?php if (!empty($rattrapage['etudiants'])): ?>
                            <?php foreach ($rattrapage['etudiants'] as $index => $etudiant): ?>
                                <tr class="student-row hover:bg-slate-50" id="row-<?= $index ?>">
                                    <td class="px-4 py-3 font-medium text-slate-700">
                                        <input type="hidden" name="etudiants[<?= $index ?>][email]" value="<?= esc($etudiant['email']) ?>">
                                        <input type="hidden" name="etudiants[<?= $index ?>][nom]" value="<?= esc($etudiant['nom']) ?>">
                                        <input type="hidden" name="etudiants[<?= $index ?>][prenom]" value="<?= esc($etudiant['prenom']) ?>">
                                        <input type="hidden" name="etudiants[<?= $index ?>][groupe]" value="<?= esc($etudiant['groupe'] ?? '') ?>">
                                        <input type="hidden" class="justifie-input" name="etudiants[<?= $index ?>][justifie]" value="<?= isset($etudiant['justifie']) && $etudiant['justifie'] == 1 ? '1' : '0' ?>">
                                        
                                        <?= esc($etudiant['nom']) ?> <?= esc($etudiant['prenom']) ?>
                                    </td>
                                    <td class="px-4 py-3 text-slate-500 text-xs">
                                        <?= esc($etudiant['email']) ?>
                                    </td>
                                    <td class="px-4 py-3 text-slate-500">
                                        <?= esc($etudiant['groupe'] ?? '-') ?>
                                    </td>
                                    <td class="px-4 py-3 text-center">
                                        <label class="inline-flex items-center cursor-pointer">
                                            <input type="checkbox" 
                                                   class="justifie-checkbox h-5 w-5 rounded border-slate-300 text-green-600 focus:ring-green-500"
                                                   data-row="row-<?= $index ?>"
                                                   <?= isset($etudiant['justifie']) && $etudiant['justifie'] == 1 ? 'checked' : '' ?>
                                                   onchange="toggleJustifie(this, 'row-<?= $index ?>')">
                                            <span class="ml-2 text-xs text-slate-600">Justifié</span>
                                        </label>
                                    </td>
                                    <td class="px-4 py-3 text-right">
                                        <button type="button" onclick="removeStudent('row-<?= $index ?>')" class="text-red-500 hover:text-red-700 p-1 hover:bg-red-50 rounded transition-colors">
                                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Message vide -->
                <div id="emptyMessage" class="text-center py-8 text-slate-400 text-sm italic border border-dashed border-slate-200 rounded-md <?= !empty($rattrapage['etudiants']) ? 'hidden' : '' ?>">
                    <i data-lucide="users" class="w-8 h-8 mx-auto mb-2 opacity-50"></i>
                    Aucun étudiant absent pour ce rattrapage.
                </div>
            </div>
        </div>

        <!-- ÉTAPE 4 : Actions (Carte Résumé) -->
        <div class="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="flex items-center justify-center w-8 h-8 rounded-full bg-slate-200 text-slate-600 font-bold text-sm">4</div>
                <div>
                    <h2 class="text-lg font-bold text-slate-700">Validation</h2>
                    <p class="text-xs text-slate-500">Enregistrez les modifications</p>
                </div>
            </div>

            <div class="flex gap-4">
                <a href="<?= site_url('gestion_rattrapage') ?>" class="px-6 py-2 rounded-lg border border-slate-300 text-slate-700 font-medium hover:bg-slate-50 transition-colors">
                    Annuler
                </a>
                <button type="submit" class="px-6 py-2 rounded-lg bg-primary text-white font-bold hover:bg-[#002244] transition-colors shadow-sm">
                    Enregistrer les modifications
                </button>
            </div>
        </div>

    </form>
</section>

<script>
    // Fonction pour basculer le statut justifié
    window.toggleJustifie = function(checkbox, rowId) {
        const row = document.getElementById(rowId);
        const hiddenInput = row.querySelector('.justifie-input');
        hiddenInput.value = checkbox.checked ? '1' : '0';
    };

    // Fonction pour supprimer un étudiant
    window.removeStudent = function(rowId) {
        if (confirm('Êtes-vous sûr de vouloir retirer cet étudiant de la liste ?')) {
            const row = document.getElementById(rowId);
            if (row) {
                row.remove();
                toggleEmptyState();
            }
        }
    };

    function toggleEmptyState() {
        const tableBody = document.getElementById('studentTableBody');
        const tableContainer = document.getElementById('studentTableContainer');
        const emptyMessage = document.getElementById('emptyMessage');
        
        const rowCount = tableBody.children.length;
        if (rowCount > 0) {
            tableContainer.classList.remove('hidden');
            emptyMessage.classList.add('hidden');
        } else {
            tableContainer.classList.add('hidden');
            emptyMessage.classList.remove('hidden');
        }
    }
</script>

<?= $this->endSection() ?>