<?= $this->extend('layouts/dashboard_layout') ?>

<?= $this->section('main_content') ?>

<?php 
    $isDirecteur = (strcasecmp(trim($role), 'directeur') === 0);
?>

<?php if ($isDirecteur): ?>
    <div class="space-y-6 max-w-7xl mx-auto">
        <div class="flex justify-between items-center">
            <div>
                <h2 class="text-4xl font-bold text-primary">Tableau de bord</h2>
                <p class="text-muted-foreground mt-1">Bienvenue, <?= esc($prenom) ?> <?= esc($nom) ?></p>
            </div>
            <a href="<?= site_url('rattrapage/creation',) ?>" class="bg-primary text-primary-foreground px-4 py-2 rounded-md flex items-center gap-2 hover:bg-primary/90 transition-colors">
                <i data-lucide="plus" class="w-4 h-4"></i>
                Nouveau rattrapage
            </a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-card text-card-foreground p-6 rounded-xl shadow-sm border border-border flex justify-between items-start">
                <div>
                    <p class="text-sm font-medium text-muted-foreground">Rattrapages en attente</p>
                    <h3 class="text-3xl font-bold mt-2"><?= $stats['en_cours'] ?? 0 ?></h3>
                </div>
                <div class="p-3 bg-blue-50 rounded-full">
                    <i data-lucide="clock" class="w-6 h-6 text-blue-500"></i>
                </div>
            </div>

            <div class="bg-card text-card-foreground p-6 rounded-xl shadow-sm border border-border flex justify-between items-start">
                <div>
                    <p class="text-sm font-medium text-muted-foreground">Programmés</p>
                    <h3 class="text-3xl font-bold mt-2"><?= $stats['programmes'] ?? 0 ?></h3>
                </div>
                <div class="p-3 bg-orange-50 rounded-full">
                    <i data-lucide="alert-circle" class="w-6 h-6 text-orange-500"></i>
                </div>
            </div>

            <div class="bg-card text-card-foreground p-6 rounded-xl shadow-sm border border-border flex justify-between items-start">
                <div>
                    <p class="text-sm font-medium text-muted-foreground">Neutralisés</p>
                    <h3 class="text-3xl font-bold mt-2"><?= $stats['neutralises'] ?? 0 ?></h3>
                </div>
                <div class="p-3 bg-green-50 rounded-full">
                    <i data-lucide="check-circle-2" class="w-6 h-6 text-green-500"></i>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-3 space-y-6">
                <div class="bg-card text-card-foreground rounded-xl shadow-sm border border-border p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-lg font-bold text-primary">Rattrapages récents</h3>
                        <a href="/gestion_rattrapage" class="text-sm text-primary hover:underline">Voir tout</a>
                    </div>

                    <div class="space-y-4">
                        <?php if (!empty($rattrapages_recents)): ?>
                            <?php foreach ($rattrapages_recents as $r): ?>
                                <?php
                                    $statut = $r['statut'] ?? 'En attente';
                                    $statutClass = match($statut) {
                                        'planifié', 'Planifié' => 'bg-green-100 text-green-700',
                                        'En attente' => 'bg-yellow-100 text-yellow-700',
                                        'annulé', 'Neutralisé' => 'bg-gray-100 text-gray-700',
                                        default => 'bg-orange-100 text-orange-700'
                                    };
                                    $dateAffichage = $r['date_planification'] ?? $r['date_rattrapage'] ?? 'Non prévue';
                                ?>
                                <div class="border border-border rounded-lg p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                                    <div>
                                        <h4 class="font-bold text-foreground"><?= esc($r['ressource']) ?></h4>
                                        <p class="text-sm text-muted-foreground mt-1">
                                            <?= esc($r['enseignant_prenom'] ?? '') ?> <?= esc($r['enseignant_nom'] ?? 'Enseignant inconnu') ?> • S<?= esc($r['semestre']) ?>
                                        </p>
                                        <p class="text-sm text-muted-foreground">
                                            Prévu le <?= date('d/m/Y', strtotime($dateAffichage)) ?> • <?= esc($r['nb_etudiants']) ?> étudiant<?= $r['nb_etudiants'] > 1 ? 's' : '' ?>
                                            <?php if (!empty($r['salle'])): ?>
                                                • Salle <?= esc($r['salle']) ?>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <div class="flex items-center gap-3">
                                        <span class="px-3 py-1 rounded-full text-xs font-medium <?= $statutClass ?>"><?= esc($statut) ?></span>
                                        <a href="<?= site_url('visualisation_rattrapage/' . $r['id_rattrapage']) ?>" class="px-4 py-2 border border-border rounded-md text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-colors">Détails</a>
                                    </div>

                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-8 text-muted-foreground">
                                <p>Aucun rattrapage récent</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="space-y-6">
        <div>
            <h2 class="text-3xl font-bold text-primary">Tableau de bord</h2>
            <p class="text-muted-foreground mt-1">Bienvenue, <?= esc($prenom) ?> <?= esc($nom) ?></p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div class="bg-card text-card-foreground p-6 rounded-xl shadow-sm border border-border flex justify-between items-center">
                <div>
                    <p class="text-sm font-medium text-muted-foreground">En attente</p>
                    <h3 class="text-3xl font-bold mt-1"><?= $stats['en_attente'] ?? 0 ?></h3>
                </div>
                <div class="p-3 bg-orange-50 rounded-full">
                    <i data-lucide="clock" class="w-6 h-6 text-orange-300"></i>
                </div>
            </div>

            <div class="bg-card text-card-foreground p-6 rounded-xl shadow-sm border border-border flex justify-between items-center">
                <div>
                    <p class="text-sm font-medium text-muted-foreground">Planifiés</p>
                    <h3 class="text-3xl font-bold mt-1"><?= $stats['planifies'] ?? 0 ?></h3>
                </div>
                <div class="p-3 bg-blue-50 rounded-full">
                    <i data-lucide="calendar" class="w-6 h-6 text-blue-300"></i>
                </div>
            </div>

            <div class="bg-card text-card-foreground p-6 rounded-xl shadow-sm border border-border flex justify-between items-center">
                <div>
                    <p class="text-sm font-medium text-muted-foreground">Total étudiants</p>
                    <h3 class="text-3xl font-bold mt-1"><?= $stats['total_etudiants'] ?? 0 ?></h3>
                </div>
                <div class="p-3 bg-green-50 rounded-full">
                    <i data-lucide="users" class="w-6 h-6 text-green-300"></i>
                </div>
            </div>

            <div class="bg-card text-card-foreground p-6 rounded-xl shadow-sm border border-border flex justify-between items-center">
                <div>
                    <p class="text-sm font-medium text-muted-foreground">Mes ressources</p>
                    <h3 class="text-3xl font-bold mt-1"><?= $stats['mes_ressources'] ?? 0 ?></h3>
                </div>
                <div class="p-3 bg-purple-50 rounded-full">
                    <i data-lucide="file-text" class="w-6 h-6 text-purple-300"></i>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2 space-y-6">
                <div class="bg-card text-card-foreground rounded-xl shadow-sm border border-border p-6">
                    <h3 class="text-lg font-bold text-primary mb-6">Mes rattrapages</h3>

                    <div class="space-y-4">
                        <?php if (!empty($mes_rattrapages)): ?>
                            <?php foreach ($mes_rattrapages as $r): ?>
                                <?php
                                    $statut = $r['statut'] ?? 'En attente';
                                    $statutClass = match($statut) {
                                        'planifié', 'Planifié' => 'bg-green-100 text-green-700',
                                        'En attente' => 'bg-yellow-100 text-yellow-700',
                                        'annulé', 'Neutralisé' => 'bg-gray-100 text-gray-700',
                                        default => 'bg-orange-100 text-orange-700'
                                    };
                                    $dateAffichage = $r['date_planification'] ?? $r['date_rattrapage'] ?? 'Non prévue';
                                    $info = '';
                                    if ($statut === 'En attente') {
                                        $info = 'En attente de planification';
                                    } elseif (!empty($r['date_planification'])) {
                                        $info = 'Prévu le ' . date('d F', strtotime($r['date_planification']));
                                        if (!empty($r['salle'])) {
                                            $info .= ' - Salle ' . $r['salle'];
                                        }
                                    } else {
                                        $info = $r['commentaire'] ?? 'Aucune information';
                                    }
                                ?>
                                <div class="border border-border rounded-lg p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                                    <div>
                                        <h4 class="font-bold text-foreground"><?= esc($r['ressource']) ?></h4>
                                        <p class="text-sm text-muted-foreground mt-1"><?= esc($info) ?></p>
                                        <p class="text-sm text-muted-foreground">
                                            DS original: <?= !empty($r['date_ds_original']) ? date('d/m/Y', strtotime($r['date_ds_original'])) : 'Non renseigné' ?> • 
                                            <?= esc($r['nb_etudiants']) ?> étudiant<?= $r['nb_etudiants'] > 1 ? 's' : '' ?>
                                        </p>
                                    </div>
                                    <div class="flex items-center gap-3">
                                        <span class="px-3 py-1 rounded-full text-xs font-medium <?= $statutClass ?>"><?= esc($statut) ?></span>
                                        <?php if ($statut !== 'annulé') { ?>
                                            <a href="<?= site_url('planifier_rattrapage/' . $r['id_rattrapage']) ?>" class="px-4 py-2 border border-border rounded-md text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-colors">Détails</a>
                                        <?php } ?>                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-8 text-muted-foreground">
                                <p>Aucun rattrapage</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mt-6">
                        <a href="/mes_rattrapages" class="text-sm text-primary hover:underline">Voir tous mes rattrapages</a>
                    </div>
                </div>
            </div>

            <div class="space-y-6">
                <div class="bg-card text-card-foreground rounded-xl shadow-sm border border-border p-6">
                    <h3 class="text-lg font-bold text-primary mb-4">Prochains événements</h3>
                    <div class="space-y-4">
                        <?php if (!empty($prochains_evenements)): ?>
                            <?php foreach ($prochains_evenements as $event): ?>
                                <div class="border-b border-border pb-3 last:border-0 last:pb-0">
                                    <h4 class="font-bold text-sm">
                                        Rattrapage <?= esc($event['ressource']) ?> - Salle <?= esc($event['salle'] ?? 'TBD') ?>
                                    </h4>
                                    <p class="text-xs text-muted-foreground mt-1">
                                        <?= date('d/m/Y', strtotime($event['date'])) ?>
                                    </p>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-sm text-muted-foreground">Aucun événement à venir</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?= $this->endSection() ?>
