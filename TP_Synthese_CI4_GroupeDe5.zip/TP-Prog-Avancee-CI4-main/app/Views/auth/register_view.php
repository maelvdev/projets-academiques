<?= $this->extend('layouts/root_layout') ?>

<?= $this->section('root_content') ?>

<div class="bg-gradient-to-br from-primary via-white to-cyan-400 flex items-center justify-center min-h-screen w-full font-sans antialiased">
    <main class="bg-white py-12 px-8 flex flex-col gap-8 rounded-lg shadow-sm w-[500px] h-full" role="main">
        <header class="flex flex-col gap-2">
            <h1 class="text-primary font-bold text-4xl">SGRDS</h1>
            <p class="text-muted-foreground">Créez votre compte</p>
        </header>

        <form class="flex flex-col gap-8" method="post" action="<?= site_url('auth/inscription') ?>" novalidate>
            <div class="flex flex-lig gap-2">
                <div class="flex flex-col gap-2 flex-1">
					<label for="prenom" class="text-bold text-lg">Prénom</label>
					<input id="prenom" name="prenom" type="text" class="border border-muted rounded-md py-2 px-3 w-full" placeholder="Jean" required aria-required="true" />
				</div>
				<div class="flex flex-col gap-2 flex-1">
					<label for="nom" class="text-bold text-lg">Nom</label>
					<input id="nom" name="nom" type="text" class="border border-muted rounded-md py-2 px-3 w-full" placeholder="Dupont" required aria-required="true" />
				</div>
            </div>
            <div class="flex flex-col gap-2">
                <label for="email" class="text-bold text-lg">Adresse Email</label>
                <input id="email" name="email" type="email" class="border-1 border-muted rounded-md py-2 px-3" placeholder="prenom.nom@univ-lehavre.fr" required aria-required="true" />
            </div>

            <div class="flex flex-col gap-2">
                <label for="mot_de_passe" class="text-bold text-lg">Mot de passe</label>
                <input id="mot_de_passe" name="mot_de_passe" type="password" class="border-1 border-muted rounded-md py-2 px-3" placeholder="••••••••" required aria-required="true" />
            </div>

            <div class="flex flex-col gap-2">
                <label for="confirmmdp" class="text-bold text-lg">Confirmez le mot de passe</label>
                <input id="confirmmdp" name="confirmmdp" type="password" class="border-1 border-muted rounded-md py-2 px-3" placeholder="••••••••" required aria-required="true" />
            </div>

            <div class="flex flex-col gap-2 mt-2">
                <button type="submit" class="inline-flex items-center w-full justify-center bg-primary text-white text-md font-semibold hover:bg-primary/90 rounded-lg py-2">S'inscrire</button>
            </div>

            <div class="w-full border-t border-border"></div>

            <div class="flex items-center justify-center">
                <p class="text-muted-foreground items-center">Déjà inscrit ? <a class="text-primary hover:underline" href="/auth/connexion">Se connecter</a></p>

            </div>
        </form>
    </main>
</div>
<?= $this->endSection() ?>

