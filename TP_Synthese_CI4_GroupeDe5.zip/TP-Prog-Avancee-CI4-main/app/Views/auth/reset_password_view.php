<?= $this->extend('layouts/root_layout') ?>
<?= $this->section('root_content') ?>

<div class="bg-gradient-to-br from-primary via-white to-cyan-400 flex items-center justify-center min-h-screen w-full font-sans antialiased">
    <main class="bg-white py-12 px-8 flex flex-col gap-8 rounded-lg shadow-sm w-[500px] h-full" role="main">
        <header class="flex flex-col gap-2">
            <h1 class="text-primary font-bold text-4xl">SGRDS</h1>
            <p class="text-muted-foreground">Définir un nouveau mot de passe</p>
        </header>

        <?php if (session()->getFlashdata('error')) : ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif; ?>

        <form class="flex flex-col gap-6" method="post" action="<?= site_url('auth/mdpchangement') ?>" novalidate>
            
            <input type="hidden" name="token" value="<?= esc($token) ?>">

            <div class="flex flex-col gap-2">
                <label for="mot_de_passe" class="text-bold text-lg">Nouveau mot de passe</label>
                <input id="mot_de_passe" name="mot_de_passe" type="password" class="border-1 border-muted rounded-md py-2 px-3" placeholder="******" required />
            </div>

            <div class="flex flex-col gap-2">
                <label for="confirmmdp" class="text-bold text-lg">Confirmer le mot de passe</label>
                <input id="confirmmdp" name="confirmmdp" type="password" class="border-1 border-muted rounded-md py-2 px-3" placeholder="******" required />
            </div>

            <div class="flex flex-col gap-2 mt-4">
                <button type="submit" class="inline-flex items-center w-full justify-center bg-primary text-white text-md font-semibold hover:bg-primary/90 rounded-lg py-2">
                    Sauvegarder
                </button>
            </div>
        </form>
    </main>
</div>

<?= $this->endSection() ?>