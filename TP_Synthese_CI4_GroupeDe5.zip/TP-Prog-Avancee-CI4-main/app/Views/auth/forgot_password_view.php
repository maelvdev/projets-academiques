<?= $this->extend('layouts/root_layout') ?>
<?= $this->section('root_content') ?>

<div class="bg-gradient-to-br from-primary via-white to-cyan-400 flex items-center justify-center min-h-screen w-full font-sans antialiased">
    <main class="bg-white py-12 px-8 flex flex-col gap-8 rounded-lg shadow-sm w-[500px] h-full" role="main">
        <header class="flex flex-col gap-2">
            <h1 class="text-primary font-bold text-4xl">SGRDS</h1>
            <p class="text-muted-foreground">Mot de passe oublié</p>
        </header>
            <form class="flex flex-col gap-6" method="post" action="<?= site_url('auth/mdpoublie') ?>" novalidate>
                <div class="flex flex-col gap-2">
                    <label for="email" class="text-bold text-lg">Adresse Email</label>
                    <input id="email" name="email" type="email" class="border-1 border-muted rounded-md py-2 px-3" placeholder="votre.email@universite.fr" required aria-required="true" />
                    <p class="text-sm text-muted-foreground">Nous vous enverrons un code de vérification</p>
                </div>

                <div class="flex flex-col gap-2 mt-2">
                    <button type="submit" class="inline-flex items-center w-full justify-center bg-primary text-white text-md font-semibold hover:bg-primary/90 rounded-lg py-2">Envoyer le code</button>
                </div>

                <div class="flex flex-col gap-4 items-center">
                    <a class="text-primary hover:underline" href="/auth/connexion">Retour à la connexion</a>
                </div>
            </form>
        </main>
    </div>

<?= $this->endSection() ?>
