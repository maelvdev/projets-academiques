<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/accueil', 'TableaudebordControlleur::index', ['filter' => 'authGuard']);

// Route de test de connexion à la base de données
$routes->get('/test-connexion', 'TestConnexion::index');

// Routes pour la gestion (vues)
$routes->get('/gestion_rattrapage', 'RattrapageController::index');
$routes->get('/gestion_utilisateur', 'GestionUtilisateurController::index');
$routes->get('/etudiants', 'EtudiantsController::index');
$routes->get('/rattrapage/creation', 'RattrapageController::creer');
$routes->post('planifier_rattrapage/supprimer/(:num)', 'RattrapageController::supprime/$1');
$routes->post('/rattrapage/create', 'RattrapageController::create');
$routes->get('/rattrapage/get-ressources', 'RattrapageController::getRessources');
$routes->post('/rattrapage/create-ressource', 'RattrapageController::createRessource');
$routes->get('/rattrapage/get-enseignants', 'RattrapageController::getEnseignants');
$routes->get('/rattrapage/get-etudiants', 'RattrapageController::getEtudiants');
$routes->get('/mes_rattrapages', 'MesRattrapagesController::index');
$routes->get('/planifier_rattrapage/(:num)', 'PlanifierRattrapageController::index/$1');
$routes->get('/gestion_utilisateur', 'GestionUtilisateurController::index');
$routes->get('/gestion_utilisateur/voir/(:segment)', 'GestionUtilisateurController::voir/$1');
$routes->get('/gestion_utilisateur/modifier/(:segment)', 'GestionUtilisateurController::modifier/$1');
$routes->post('/gestion_utilisateur/update', 'GestionUtilisateurController::update');
$routes->get('/gestion_utilisateur/supprimer/(:segment)', 'GestionUtilisateurController::supprimer/$1');
$routes->post('rattrapage/supprimer/(:num)', 'RattrapageController::supprimer/$1');
$routes->get('/visualisation_rattrapage/(:num)', 'VisualisationRattrapageController::index/$1');

$routes->post('/planifier_rattrapage/annuler/(:num)', 'PlanifierRattrapageController::annuler/$1');
$routes->post('/planifier_rattrapage/planifier/(:num)', 'PlanifierRattrapageController::planifier/$1');
$routes->post('/planifier_rattrapage/supprimer/(:num)', 'PlanifierRattrapageController::supprimer/$1');

$routes->get('/', 'Connexion\ConnexionController::index');




$routes->get('/modifier_rattrapage/(:num)', 'ModifierRattrapageController::index/$1');
$routes->post('/modifier_rattrapage/(:num)', 'ModifierRattrapageController::update/$1');

// Routes pour les paramètres
$routes->get('/parametres', 'ParametresController::profil');
$routes->get('/parametres/profil', 'ParametresController::profil');
$routes->post('/parametres/profil', 'ParametresController::updateProfil');
$routes->get('/parametres/mot-de-passe', 'ParametresController::motDePasse');
$routes->post('/parametres/mot-de-passe', 'ParametresController::updateMotDePasse');
$routes->get('/parametres/notifications', 'ParametresController::notifications');
$routes->post('/parametres/notifications', 'ParametresController::updateNotifications');
$routes->post('/parametres/deconnecter-sessions', 'ParametresController::deconnecterSessions');
$routes->post('/parametres/supprimer-compte', 'ParametresController::supprimerCompte');

$routes->get('auth/connexion', 'Connexion\ConnexionController::index');
$routes->get('auth/inscription', 'Connexion\InscriptionController::index');
$routes->get('auth/auth/inscription', 'Connexion\InscriptionController::index');
$routes->get('auth/verif', 'Connexion\VerificationController::index');
$routes->get('auth/mdpoublie', 'Connexion\MdpOublieController::index');

// Routes avec token dans l'URL
$routes->get('auth/inscription/(:segment)', 'Connexion\InscriptionController::activerCompte/$1');
$routes->get('auth/mdpchangement/(:segment)', 'Connexion\MdpOublieController::afficherFormulaireReset/$1');

// Routes pour afficher explicitement les pages d'erreur (pratique pour redirections depuis des catch)
$routes->get('error/404', 'ErreurPageControlleur::show404');
$routes->get('error/500', 'ErreurPageControlleur::show500');

// Routes pour l'authentification / inscription
$routes->post('auth/connexion', 'Connexion\ConnexionController::connexionAuth');
$routes->post('auth/inscription', 'Connexion\InscriptionController::inscritUtilisateur');
$routes->post('auth/mdpoublie', 'Connexion\MdpOublieController::envoieToken');
$routes->post('auth/mdpchangement', 'Connexion\MdpOublieController::sauvegarderNouveauMdp');

// Routes pour la gestion (vues)
$routes->post('/etudiants/create', 'EtudiantsController::create');
$routes->post('/etudiants/update', 'EtudiantsController::update');
$routes->post('/etudiants/delete', 'EtudiantsController::delete');
$routes->get('auth/logout', 'Connexion\ConnexionController::logout');
