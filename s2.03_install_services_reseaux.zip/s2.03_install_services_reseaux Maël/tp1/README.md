**Nom :** Vauthier Maël

**Groupe :** C2

**Année :**2023-2024

**IUT Le Havre - Cours GIT**

### Compte-rendu TP1 Introduction GIT

Le TP couvre plusieurs aspects essentiels de l'utilisation de Git, notamment la configuration initiale, la création d'un dépôt local, la gestion des fichiers et des modifications, ainsi que l'ignorance des fichiers générés. 
Voici un résumé de ce qu'on peut y apprendre :

1. Configuration de Git

	Utilisation de git config pour définir les paramètres de configuration tels que le nom d'utilisateur, l'adresse e-mail et l'éditeur de texte par défaut.
	Commandes pour vérifier les paramètres de configuration actuels (git config --list).
	Importance de définir l'identité, car chaque commit utilise ces informations.

2. Création d'un dépôt Git sur une machine locale

	Initialisation d'un nouveau dépôt Git dans un répertoire existant avec git init.
	Utilisation de git status pour afficher les modifications dans la copie de travail.
	Compréhension des états des fichiers dans Git (modifié, sélectionné, validé) et des zones correspondantes (copie de travail, zone de sélection, dépôt).
	Sélection des fichiers pour le suivi avec git add et validation des modifications avec git commit.
	Mise en place d'un fichier .gitignore pour exclure certains fichiers du suivi de Git, comme les fichiers .class générés lors de la compilation Java.

3. Création d'un fichier texte README.md

	Utilisation d'un éditeur de texte pour créer et éditer un fichier README.md.
	Ajout et validation du fichier README.md dans le dépôt Git.
	Compréhension de la séquence de suivi des modifications d'un fichier dans Git (modification, ajout, validation).
	Différenciation des trois états, zones et actions dans Git (modifié, sélectionné, validé).

4. Gestion de version d'un programme Java

	Création d'un répertoire src pour contenir les sources Java.
	Création d'un fichier Java Cryptomonnaie.java avec des attributs simples.
	Ajout et validation du fichier Java dans le dépôt Git.
	Utilisation d'un fichier .gitignore pour exclure les fichiers générés, tels que les fichiers .class, des suivis de Git.
