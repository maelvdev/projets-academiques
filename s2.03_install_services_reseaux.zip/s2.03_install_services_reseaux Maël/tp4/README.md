**Nom :** Vauthier Maël

**Groupe :** C2

**Année :**2023-2024

**IUT Le Havre - Cours GIT**

### Compte-rendu TP4 Introduction GIT

Pendant ce TP, nous avons appris deux aspects fondamentaux de la gestion collaborative avec Git : la résolution des conflits et l'utilisation des pull requests. Voici un résumé des points principaux abordés :

1. Créer un conflit :
	Nous avons appris que lorsqu'un même fichier est modifié par plusieurs utilisateurs de manière concurrente, des conflits peuvent survenir.
	Pour simuler un tel conflit, nous avons créé un dépôt GitHub appelé "test-conflict" avec un fichier README.md contenant des fautes de frappe intentionnelles.
	Athos et Porthos ont chacun corrigé une faute de frappe localement et ont tenté de pousser leurs modifications vers le dépôt distant, provoquant ainsi un conflit.
	Nous avons vu comment Git signale un conflit lors d'une tentative de fusion des branches.

2. Résoudre un conflit :
	Nous avons appris à identifier et à résoudre les conflits à l'aide de la commande git diff pour visualiser les différences entre les branches.
	En éditant manuellement le fichier en conflit, nous avons choisi quelle version des modifications conserver en supprimant les marqueurs de conflit.
	Après avoir résolu le conflit, nous avons ajouté et validé les modifications avant de pousser vers le dépôt distant.

3. Un exemple simple de pull request :
	Nous nous sommes informés sur le concept de pull request, une fonctionnalité souvent utilisée sur des plateformes comme GitHub pour proposer des modifications à un référentiel.
	L'exercice proposé nous a guidés pour créer une pull request sur un dépôt GitHub spécifique en suivant les instructions fournies dans le fichier README.md.
