**Nom :** Vauthier Maël

**Groupe :** C2

**Année :**2023-2024

**IUT Le Havre - Cours GIT**

### Compte-rendu TP2 Introduction GIT

Le TP couvre plusieurs aspects de l'utilisation de GitHub, y compris la création d'un compte, l'ajout de clés SSH, la gestion des dépôts locaux et distants, ainsi que le clonage de dépôts existants. 
Parmis ce qu'on y apprend, on retrouve :

1. Créer un compte sur GitHub

	Inscription sur GitHub en fournissant les informations nécessaires via le formulaire d'inscription.
	Création d'un compte utilisateur sur GitHub.

2. Ajouter une nouvelle clé SSH à votre compte GitHub

	Génération d'une paire de clés publique/privée SSH si nécessaire avec ssh-keygen.
	Copie de la clé publique SSH (id_rsa.pub ou similaire).
	Ajout de la clé publique SSH à votre compte GitHub via les paramètres du compte.

3. Pousser un dépôt existant depuis la ligne de commande

	Création d'un nouveau dépôt vide sur GitHub.
	Liaison du dépôt local avec le dépôt distant sur GitHub à l'aide de git remote add.
	Push du dépôt local vers le dépôt distant avec git push.
	Synchronisation des dépôts local et distant avec git pull et git push.

4. Séquence de travail avec un dépôt distant

	Utilisation de git pull pour récupérer les dernières modifications du dépôt distant.
	Modification des fichiers locaux.
	Utilisation de git status, git add, et git commit pour valider les modifications.
	Utilisation de git push pour mettre à jour le dépôt distant avec les modifications locales.

5. Cloner un dépôt distant sur notre machine locale

	Création d'un nouveau dépôt sur GitHub.
	Clonage du dépôt distant sur la machine locale avec git clone.
	Mise à jour des fichiers locaux avec les fichiers du dépôt cloné.
	Synchronisation des dépôts local et distant avec git push.

