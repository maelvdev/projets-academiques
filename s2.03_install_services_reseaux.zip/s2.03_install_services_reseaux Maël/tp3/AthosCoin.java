public class AthosCoin extends Cryptomonnaie{
    public AthosCoin(){
        super("ATH", 2);
    }
}