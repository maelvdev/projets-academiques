public class PorthosCoin extends Cryptomonnaie{
    public AramisCoin(){
        super("PRT", 100_000);
    }
}