**Nom :** Vauthier Maël

**Groupe :** C2

**Année :**2023-2024

**IUT Le Havre - Cours GIT**

### Compte-rendu TP3 Introduction GIT

Pendant le TP, nous apprenons plusieurs concepts et techniques liés à la gestion d'un projet collaboratif avec Git.
Voici un compte rendu des principaux points abordés :

1. Inviter des collaborateurs dans un dépôt personnel :
	Athos crée un nouveau dépôt sur GitHub appelé "tp3".
	Athos invite Porthos à collaborer sur ce dépôt en utilisant l'option "Manage access" dans les paramètres du dépôt.
	Porthos accepte l'invitation reçue par e-mail.
	Chacun clone le dépôt sur son propre ordinateur et s'assure que les répertoires locaux correspondent à la structure du dépôt distant.

2. Développement d'un projet Java en équipe :
	Les collaborateurs se concentrent sur l'amélioration d'un projet de marché de crypto-monnaie.
	Athos travaille sur l'implémentation de la classe CryptoMarche.java.
	Porthos travaille sur l'implémentation de la classe Portefeuille.java.
	Chacun complète les fonctions spécifiées dans leur classe respective en suivant les commentaires.
	Une fois les implémentations terminées, les collaborateurs synchronisent leurs modifications avec le dépôt local et distant.
	Les tests sont exécutés pour s'assurer que les fonctionnalités ajoutées fonctionnent comme prévu.

3. Gérer des nouvelles fonctionnalités à l’aide des branches :
	Les collaborateurs explorent le concept de branches Git pour isoler le développement de nouvelles fonctionnalités.
	Ils créent une nouvelle branche appelée "test" pour tester une fonctionnalité supplémentaire.
	Des modifications sont apportées dans cette branche de test, puis fusionnées dans la branche principale après validation.
	Les collaborateurs expérimentent également la création de branches pour leurs propres crypto-monnaies (AthosCoin et PorthosCoin), avant de les fusionner dans la branche principale.

En résumé, ce TP nous enseigne les bonnes pratiques pour travailler efficacement sur un projet collaboratif avec Git, en utilisant des invitations de collaborateurs, des branches pour le développement de nouvelles fonctionnalités, et la synchronisation régulière des modifications entre les dépôts locaux et distants.
