import iut.algo.Clavier;

public class TestByte
{
 
    public static void main(String[] args)
    {
      
        /* Variables */
      
        long timeStart;
        long timeEnd;
        byte cpt1;
        byte cpt2;
        byte cpt3;
        byte cpt4;
      
        /* Instructions */
        
        System.out.println(System.nanoTime());
        timeStart = System.nanoTime();
      
        cpt1 = 0;
        while (cpt1 < 100)
        {
            cpt2 = 0;
            while (cpt2 < 100)
            {
                cpt3 = 0;
                while (cpt3 < 100)
                {
                    cpt4 = 0;
                    while (cpt4 < 100)
                    {
                        cpt4++;
                    }
                    cpt3++;
                }
                cpt2++;
            }
            cpt1++;
        }
        
        timeEnd = System.nanoTime();
        System.out.println("La différence de temps vaut : "+ ( (timeEnd-timeStart) / 1e9 ) + " secondes");

    }

}



