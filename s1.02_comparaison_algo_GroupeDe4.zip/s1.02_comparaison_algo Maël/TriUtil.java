import iut.algo.Clavier;

public class TriUtil
{

	public static void main(String[] arg)
	{
		/* Constantes */
        
		final int TAILLE = 50000;
		final int VAL_MIN = 0;
		final int VAL_MAX = 100000;
        
		/* Variables */
        
		int [] tableauTest;
		int [] tableauCopie;
		long timeStart, timeEnd
		
        
		/* Instructions */
        
        tableauTest = TriUtil.genererTableau (TAILLE, VAL_MIN, VAL_MAX);
        tableauCopie = TriUtil.copierTableau (tableauTest);
        
		System.out.println(System.nanoTime());
		timeStart = System.nanoTime();
        
		timeEnd = System.nanoTime();
        System.out.println("La différence de temps vaut : "+ ( (timeEnd-timeStart) / 1e9 ) + " secondes");
		
		
    public static void triSelection ( int[] tab )
    {
   	 	// Variables
   	 
   	 	int cpt1, cpt2;
   	 	int maxVal, indVal;
   	 
   	 	// Instructions
   	 
   	 	cpt1 = 0;
   	 	while (cpt1 < tab.length)
   	 	{
			maxVal = indVal = 0;
   		 
   		 	cpt2 = 0;
   		 	while (cpt2 < tab.length - cpt1)
   		 	{
   			 	if (maxVal < tab[cpt2])
   			 	{
   				 	maxVal = tab[cpt2];
   				 	indVal = cpt2;
   			 	}
				cpt2++;
   		 	}
   			TriUtil.permuter (tab, tab.length-1-cpt1, indVal);

		cpt1++;
   	 	}   	 
	}

  private static void permuter ( int[] tab, int ind1, int ind2 )
	{
		/*   Données     */
		
		/* Variables     */
		
		int temp ;
		
		/* Instructions  */
		
		if ( tab[ind1] != tab[ind2] )
		{
			temp = tab[ind1]      ;
			tab[ind1] = tab[ind2] ;
			tab[ind2] = temp      ;
		}
	}

	public static int[] triBulle(int[] tab)
	{
   	 
		/* Instructions */
	
		for (int cpt1 = 0; cpt1 < tab.length - 1; cpt1++)
		{
			for (int cpt2 = 0; cpt2 < tab.length - 1 - cpt1; cpt2++)
			{
				if (tab[cpt2] > tab[cpt2 + 1])
				{
					TriUtil.permuter( tab, cpt2, (cpt2 + 1) );
				}
			}
		}
	}

	return tab;

	public static void triInsertion( int[] tab)
	{
		// Variables
   	 
		int cpt1, cpt2 ;
		int tmp ;
   	 
		// Instructions
   	 
		cpt1 = 1 ;
		while (cpt1 <= tab.length)
		{
			tmp = tab[cpt1];

			cpt2 = cpt1 - 1 ;
			while (cpt2 >= 0)
			{
				if (cpt2 >= 0 && tmp < tab[cpt2])
				{
					tab[cpt2 + 1] = tab[cpt2] ;
					cpt2-- ;
				}
				else
				{
					tab[cpt2 + 1] = tmp ;
				}
			}

		cpt1++ ;
		}
	}


	public static boolean estTrie ( int[] tab )
	{     
        for (int cpt=0; cpt<=tab.length; cpt++)
        {
            if (tab[cpt] > tab[cpt+1])
            {
                return false;
            }
        }
        return true;
    }

    public static int[] genererTableau ( int nbCases, int valMin, int valMax )
    {
        int [] tab;
        tab = new int [nbCases];

        for (int cpt=0; cpt<tab.length; cpt++)
        {
            tab [cpt] = (int)(Math.random()*(valMax-valMin)+valMin);
        }
        return tab;

    }

	public static int[] copierTableau ( int[] tab )
	{
		int [] newTab;
		newTab = new int [tab.length]
        
		for (int cpt=0; cpt<tab.length;cpt++)
		{
			newTab[cpt] = tab[cpt]
 		}
		return newTab
	}

    public static String toString ( int[] tab )
	{
		/* Variables     */
		String res  ;
		
		/* Instructions  */
		
		res = "+--------+--------+--------+--------+ . . . . +--------+--------+--------+--------+\n";
		for (int cpt1 = 0; cpt1 < 4; cpt1++)
		{
			res = res + "|" + String.format( "%8s" , String.valueOf( tab[cpt1] ) );
		}
		res = res + "|         ";
		for (int cpt2 = 0; cpt2 < 4; cpt2++)
		{
			res = res + "|" + String.format( "%8s" , String.valueOf( tab[tab.length - 1 - cpt2] ) );
		}
		res = res + "|\n+--------+--------+--------+--------+ . . . . +--------+--------+--------+--------+\n";

		for (int cpt = 0; cpt < 4; cpt++)
		{
			res = res + "        " + String.valueOf( cpt );
		}
		res = res + "          ";
		for (int cpt = 0; cpt < 4; cpt++)
		{
			
			res = res + "        " + String.valueOf( tab.length - 4 + cpt );
		}
		
		return res;
	}

    private static void permuter ( int[] tab, int ind1, int ind2 )
	{
		/*   Données     */
		
		/* Variables     */
		
		int temp ;
		
		/* Instructions  */
		
		if ( tab[ind1] != tab[ind2] )
		{
			temp = tab[ind1]      ;
			tab[ind1] = tab[ind2] ;
			tab[ind2] = temp      ;
		}
	}


    }
}

